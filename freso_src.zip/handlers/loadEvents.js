const menuEvents = (event) => require(`../events/interactions/${event}`)
const Discord = require("discord.js");
const guildEvent = (event) => require(`../events/guild/${event}`);
function loadEvents(client) {
  const cooldowns = new Discord.Collection();

const buttonEvent = (event) => require(`../events/buttonns/${event}`);
const otherEvent = (event) => require(`../events/functions/${event}`);
const clientEvent = (event) => require(`../events/client/${event}`);
  // guild 
   // client.on("interactionCreate", (m) => menuEvents("antilink")(m, client));
  //lient.on("interactionCreate", (m) => menuEvents("autorole")(m, client));
  //client.on("interactionCreate", (m) => menuEvents("automod")(m, client));
  //client.on("messageCreate", (m) => otherEvent("antilinks")(m));
   // client.on("messageCreate", (m) => guildEvent("command")(m, cooldowns));

    //client.on("messageCreate", (m) => guildEvent("messageCreate")(m, cooldowns));
  client.on("interactionCreate", (m) => menuEvents("boost")(m, client));
client.on('guildMemberBoost', (m) => guildEvent("guildMemberboost")(m));

  client.on('interactionCreate', (m) => guildEvent("interactionCreate")(m, client, cooldowns));

    client.on("ready", () => clientEvent("ready")(client));
 
  //client.on("interactionCreate", (m) => menuEvents("loggings")(m, client));
  //client.on('interactionCreate', (m) => menuEvents('messageUpdates')(m, client));
  // client.on("interactionCreate", (m) => menuEvents("roleUpdates")(m, client));
  client.on("messageCreate", (m) => otherEvent("antiwords")(m));
  client.on("guildMemberAdd", (m) => otherEvent("autorole")(m));
  // warnings and errors
  client.on("warn", (info) => console.log(info));
  client.on("error", console.error);
}
module.exports = {
  loadEvents,
};