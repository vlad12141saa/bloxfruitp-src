
function loadModal(client) {
    const fs = require("fs");
    const ascii = require("ascii-table");

    let modal = []

    const table = new ascii().setHeading("Modal Commands", "Load Status");

  
    const commandFolders = fs.readdirSync("./Modal");
    for (const folder of commandFolders) {
      const commandFiles = fs
        .readdirSync(`./SlashCommands/${folder}`)
        .filter((file) => file.endsWith(".js"));
      for (const file of commandFiles) {
        const command = require(`../Moodal/${folder}/${file}`);
        if (command.name) {
          client.modals.set(command.name, command)
          slash.push(command)
          table.addRow(file, "✔️");
        } else {
          table.addRow(
            file,
            "❌ => Missing a help.name or help.name is not in string"
          );
          continue;
        }
      }
      console.log(table.toString());
    }
}
 
  module.exports = {
    loadModal,
  };
  