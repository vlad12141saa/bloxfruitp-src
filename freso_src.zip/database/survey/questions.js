const mongoose = require("mongoose");

const antiwordsSchema = new mongoose.Schema({
  GuildID: String,
  userID: String,

 });

const model = mongoose.model('survey', antiwordsSchema);

module.exports = model;