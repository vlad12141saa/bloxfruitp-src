const mongoose = require("mongoose");

const antiwordsSchema = new mongoose.Schema({
  GuildID: String,
  userId: String,
  whitelisted: Boolean,
  trustedowner: Boolean,
  Count: { type: Number, default: 0 },
  BansCount: { type: Number, default: 0 },
  KicksCount: { type: Number, default: 0 },
  DeleteRoleCount: { type: Number, default: 0 },
  CreateRoleCount: { type: Number, default: 0 },
  ChannelCreateCounts: { type: Number, default: 0 },
  ChannelDeleteCounts: { type: Number, default: 0 },
  Banswhitelisted: Boolean,
  Kickswhitelisted: Boolean,
  RoleDeletewhitelisted: Boolean,
  RoleCreatewhitelisted: Boolean,
  ChannelDeletewhitelisted: Boolean,
  ChannelCreatewhitelisted: Boolean,
  GuildUpdatewhitelisted: Boolean,
  BotAddwhitelisted: Boolean,
  
  
});

const model = mongoose.model('antinukewhitelist', antiwordsSchema);

module.exports = model;