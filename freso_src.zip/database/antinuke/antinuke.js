const mongoose = require("mongoose");

const antiwordsSchema = new mongoose.Schema({
  GuildID: String,
  Count: { type: Number, default: 0},
  Threshold: { type: Number, default: 5 },
  Bansthreshold: { type: Number, default: 3 },
  Bans: { type: Boolean, default: true },
  Kicksthreshold: { type: Number, default: 3 },
  Kicks: { type: Boolean, default: true },
  ChannelCreatethreshold: { type: Number, default: 3 },
  ChannelDeletethreshold: { type: Number, default: 3 },
 Channels: { type: Boolean, default: true },
 RoleCreatethreshold: { type: Number, default: 3 },
 RoleDeletehreshold: { type: Number, default: 3 },
 RoleCreate: { type: Boolean, default: true },
 ChannelCreate: { type: Boolean, default: true },
 RoleDelete: { type: Boolean, default: true },
 ChannelDelete: { type: Boolean, default: true },
 Antivanity: { type: Boolean, default: true },
 BotAdd: { type: Boolean, default: false },
 Logs: String,
 punishment: { type: String, default: 'strip' },
});

const model = mongoose.model('antinukesettings', antiwordsSchema);

module.exports = model;