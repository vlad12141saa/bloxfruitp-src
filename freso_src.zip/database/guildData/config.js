const mongoose = require("mongoose")
module.exports = new mongoose.model(
  "config",
  new mongoose.Schema({
guild: {
type: String,
required: true
},
leveling: Boolean,
roles: Array,
})
)