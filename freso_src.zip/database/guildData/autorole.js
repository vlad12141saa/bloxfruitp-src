const mongoose = require("mongoose");

const messagesSchema = new mongoose.Schema ({
    Author: String,
GuildID: String,
   Role: String,
})

module.exports = mongoose.model("pls", messagesSchema);