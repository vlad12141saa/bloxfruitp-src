const mongoose = require('mongoose');
const guildSchema = new mongoose.Schema({
    GuildID: String,
})
const guildModel = module.exports = mongoose.model(`ani`, guildSchema);