const mongoose = require('mongoose');
module.exports = new mongoose.model(
  "leave",
  new mongoose.Schema({ 
    GuildID: String,
  Message: String,
    Channel: String,
})
);