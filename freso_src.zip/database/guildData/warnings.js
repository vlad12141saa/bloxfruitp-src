const mongoose = require('mongoose');
module.exports = new mongoose.model(
  "warnings",
  new mongoose.Schema({ 
    action: String,
  userId: String,
    guildId: String,
    moderatorId: String,
    reason: String,
    timestamp: String
})
);