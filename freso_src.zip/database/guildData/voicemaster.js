const mongoose = require('mongoose');

const guildConfigSchema = mongoose.Schema({
GuildID: String,
UserID: String,
ChannelID: String,
Owner: Boolean,  


  

});

module.exports = mongoose.model('voicemasterDB', guildConfigSchema);