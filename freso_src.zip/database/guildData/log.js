const mongoose = require("mongoose");
const Schema = new mongoose.Schema({
  Guild: String,
 ch: String,
});

const logs = mongoose.model("logs", Schema);

module.exports = logs;