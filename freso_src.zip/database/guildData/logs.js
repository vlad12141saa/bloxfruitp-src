const mongoose = require("mongoose")

const roleSchema = new mongoose.Schema({
  GuildID: String,
  All: Boolean,
Channel: String,
  channelCreate: Boolean,
  channelDelete: Boolean,
  channelUpdate: Boolean,
   emoji: Boolean,
  guildBanAdd: Boolean,
  guildBanRemove: Boolean,
  guildMemberAdd: Boolean,
guildMemberRemove: Boolean,
  guildMemberUpdate: Boolean,
  guildUpdate: Boolean, 
  roleAdd: Boolean,
  roleRemove: Boolean,
  messageDelete: Boolean,
  messageDeleteBulk: Boolean,
  messageUpdate: Boolean,
  roleCreate: Boolean,
  roleUpdate: Boolean,
  roleDelete: Boolean,
  voiceJoin: Boolean,
  voiceRemove: Boolean,
  voiceUpdate: Boolean,
});

const roleModel = module.exports = mongoose.model("logs", roleSchema)