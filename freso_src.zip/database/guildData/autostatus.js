const { Schema, Types, model } = require("mongoose");

const setupSchema = new Schema({
    // Guild id
    id:
    {
        type: String
    },
    role: {
        type: String
    },
    statusmessage: {
        type: String
    },
  log: {
        type: String
    },

}, { timestamps: true });

const autostatus = model("autostatus", setupSchema);


module.exports = autostatus;