const mongoose = require('mongoose');

const guildConfigSchema = mongoose.Schema({
GuildID: String,
time: String,
Customer: String,
expires: Date,
Date: String,
Lifetime: Boolean,
Transfered: Number,


  

});

module.exports = mongoose.model('premium-guild', guildConfigSchema);