const { model, Schema } = require('mongoose');
 
let confessschema = new Schema ({
    Guild: String,
    Channel: String,
    Timeout: Number,
    Confessions: { type: Number, default: 0 },
    Reply: { type: Number, default: 0 },
})
 
module.exports = model('confessions', confessschema);