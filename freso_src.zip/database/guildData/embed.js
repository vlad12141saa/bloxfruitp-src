const mongoose = require("mongoose")

const roleSchema = new mongoose.Schema({
    description: {
       type: String,
   
     },
    footer: {
       type: String,
 
      
     },
       image: {
       type: String,
 
      
     },
      msg: {
       type: String,
 
      
     },
       timestamp: {
       type: String,
 
      
     },
       color: {
       type: String,
 
      
     },
       url: {
       type: String,
 
      
     },
      footericon: {
       type: String,
 
      
     },
        author: {
       type: String,
   
     },
     
        authoricon: {
       type: String,
   
     },
       title: {
       type: String,
   

     },
     thumbnail: {
       type: String,
   

     },
     GuildID: String,
});

const roleModel = module.exports = mongoose.model("embed", roleSchema)