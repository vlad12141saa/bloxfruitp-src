const mongoose = require('mongoose');
const voiceSchema = new mongoose.Schema({
    userId: String,
    Date: String,
    
})
const voiceModel = module.exports = mongoose.model('donator', voiceSchema);