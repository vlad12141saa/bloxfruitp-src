const mongoose = require("mongoose");

const messagesSchema = new mongoose.Schema ({
    ChannelID: String,
    GuildID: String,
   Message: String,
})

module.exports = mongoose.model("autorefreshing", messagesSchema);