const mongoose = require('mongoose');
const command = new mongoose.Schema({
    GuildID: String,
     Clear_roles: Boolean,
   Banning_members: Boolean,
      Kicking_members: Boolean,
      Creating_roles: Boolean,
     Deleting_roles: Boolean,
     Deleting_channels: Boolean,
  Creating_channels: Boolean,
   Adding_bots: Boolean,
     Giving_dangerous_perms: Boolean,
     Giving_admin_perms: Boolean,
     Pruning_members: Boolean,
       Mentions: Boolean,
})
const cmdModal = module.exports = mongoose.model('punish', command);