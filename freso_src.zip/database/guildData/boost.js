
const mongoose = require('mongoose');

const boostSchema = new mongoose.Schema({
  Boost: {
    type: String,
  },
  GuildID: String
});

const MessageModel = module.exports = mongoose.model('boost', boostSchema);