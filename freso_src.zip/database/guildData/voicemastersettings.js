const mongoose = require('mongoose');

const guildConfigSchema = mongoose.Schema({
GuildID: String,
Create: String,
Category: String,


  

});

module.exports = mongoose.model('voicemastersetting', guildConfigSchema);