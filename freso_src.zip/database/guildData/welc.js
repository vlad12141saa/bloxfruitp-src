const mongoose = require('mongoose');
module.exports = new mongoose.model(
  "welcome",
  new mongoose.Schema({ 
    GuildID: String,
  Message: String,
    Channel: String,
})
);