const { model, Schema } = require("mongoose");

module.exports = model(
  "boosters",
  new Schema({
    GuildID: String,
    UserID: String,
    Boosting: Boolean,
    Date: String,
     })
);