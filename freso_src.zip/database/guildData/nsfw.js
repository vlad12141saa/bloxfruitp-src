const { model, Schema } = require("mongoose");

module.exports = model(
  "Nsfw",
  new Schema({
    GuildID: String,
    ChannelID: String,

  })
);