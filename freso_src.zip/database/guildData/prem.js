const mongoose = require('mongoose');
module.exports = new mongoose.model(
  "perm",
  new mongoose.Schema({ 
 
    guildID: String,

})
);