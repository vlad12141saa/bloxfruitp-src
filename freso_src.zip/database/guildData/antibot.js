const mongoose = require("mongoose");

const antiwordsSchema = new mongoose.Schema({
    GuildID: String,
    Whitelisted: String,
    Enabled: Boolean,
});

const model = mongoose.model('antibot', antiwordsSchema);

module.exports = model;