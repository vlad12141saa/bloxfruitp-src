const mongoose = require('mongoose');
const command = new mongoose.Schema({
    GuildID: String,
    Bans: Boolean,
      Kicks: Boolean,
      Pings: Boolean,
     Channels: Boolean,
     Roles: Boolean,
Channel: String,
})
const cmdModal = module.exports = mongoose.model('anti-nuke1', command);