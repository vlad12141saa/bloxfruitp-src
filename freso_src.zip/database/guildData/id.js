const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  userID: { type: String, },
  server: { type: String,  },
  date: { type: String,  },
  reason: { type: String,  },
});

const User = mongoose.model("ids", UserSchema);

module.exports = User;