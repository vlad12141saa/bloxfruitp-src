const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
  GuildID: String,
  ChannelID: String,
  Toggled: Boolean,
});

module.exports = mongoose.model("nsfwdata", Schema);