const mongoose = require('mongoose');
const guildSchema = new mongoose.Schema({
    GuildID: String,
    Command: String,
  Moderator: String,
  Date: String,
})
const guildModel = module.exports = mongoose.model('cmd', guildSchema);