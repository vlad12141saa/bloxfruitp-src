const mongoose = require('mongoose');
const voiceSchema = new mongoose.Schema({
    GuildID: String,
    ChannelID: String,
    Message: String,
})
const voiceModel = module.exports = mongoose.model('welcomeconfig', voiceSchema);