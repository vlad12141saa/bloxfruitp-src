const discord = require("discord.js")
const { ActionRowBuilder, SelectMenuBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');

let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const db = require("quick.db");
const emoji = require("../../emoji.json") 
const { Color } = require("../../config.json");
const wait = require('util').promisify(setTimeout);
module.exports = {
  name: "members",
type: ApplicationCommandType.ChatInput,
  aliases: ["membercount"],
  category: "info",
  description: "Get member count of this server.",
  run: async (client, interaction, args) => {
    let message = interaction;
        const guild = message.guild;

    await interaction.deferReply();
      await guild.fetch()
    await guild.members.fetch()
    
 let presence = interaction.guild.approximatePresenceCount;
    let Bots = await guild.members.cache.filter(member => member.user.bot).size;
 let count = interaction.guild.memberCount; 
    let embed = new MessageEmbed()

.setColor(Color)
     .setFooter({ text: `Total Members: ${count}`, })
         .setDescription(`Member(s): \`${count}\`
Bot(s): \`${Bots}\`
Online: \`${presence}\``)
    .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user.displayAvatarURL({ dynamic: true })}` })
       const o2w = new MessageActionRow()
			.addComponents(
         new MessageButton()
	.setCustomId("e2")
					.setLabel(`Refresh`)
					.setStyle(ButtonStyle.Secondary))
    interaction.followUp({ components: [o2w], embeds: [embed] });
    let msg = await interaction.fetchReply()
					let filter = (m) => m.user.id === interaction.user.id
					let collector = msg.createMessageComponentCollector({
						filter,
            type: `BUTTON`,
						time: 125000,
					})
        
	collector.on('collect', async (button) => {
    let b = button;
      if (button.customId === "e2") {
        await b.guild.members.fetch()
          presence = interaction.guild.approximatePresenceCount;
     Bots = await guild.members.cache.filter(member => member.user.bot).size;
  count = interaction.guild.memberCount; 
           let embed = new MessageEmbed()

.setColor(Color)
     .setFooter({ text: `Total Members: ${count}`, })
         .setDescription(`**Member(s)**・\`${count}\`
**Bot(s)**・\`${Bots}\`
**Online**・\`${presence}\``)
    .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user.displayAvatarURL({ dynamic: true })}` })
     
b.update({ content: `**Refreshed Data**.`, embeds: [embed]})
      }
  })
  }
       
  } 
