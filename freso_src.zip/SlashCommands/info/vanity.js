const discord = require("discord.js")
const { ActionRowBuilder, SelectMenuBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');

let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const db = require("quick.db");
const emoji = require("../../emoji.json") 
const { Color } = require("../../config.json");
const wait = require('util').promisify(setTimeout);
module.exports = {
  name: "vanity",
type: ApplicationCommandType.ChatInput,
  aliases: ["membercount"],
  category: "info",
  description: "Get info on this server's vanity.",
  run: async (client, interaction, args) => {
    let message = interaction;
   

    await interaction.deferReply();
     if(!interaction.guild.features.includes(`VANITY_URL`)) return interaction.followUp(`This server does not have a vanity url.`)
 interaction.guild.fetchVanityData()
  .then(res => {
 interaction.followUp({ embeds: [new EmbedBuilder()
.setColor(Color)
.setAuthor({ name: `${interaction.guild.name}`, iconURL: interaction.guild?.iconURL({dynamic:true}) })
.setDescription(`**Vanity URL**: https://discord.gg/${res.code} with ${res.uses} uses.`)], });
  }).catch(e => {
    interaction.followUp(`This server does not have a vanity url.`)
  })
  }
       
  } 
