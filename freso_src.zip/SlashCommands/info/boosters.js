const moment = require('moment')
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const booost = require("../../database/guildData/boosters")
module.exports = {
    name: "boosters",
    description: "View all server boosters",
type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: "list",
            description: "View a list of all the server boosters",
          type: ApplicationCommandOptionType.Subcommand,         
        },
        {
            name: "lost",
            description: "View a list people who stopped boosting",
          type: ApplicationCommandOptionType.Subcommand,         
        },  
        
    ],
    run: async(client, interaction, args) => {
await interaction.deferReply();
const backId = 'back'
const forwardId = 'forward'
const backButton = new MessageButton({
  style: ButtonStyle.Primary,
  label: 'Back',

  customId: backId
})
const forwardButton = new MessageButton({
  style: ButtonStyle.Primary,
  label: 'Forward',

  customId: forwardId
});
        if (interaction.options.getSubcommand() === "list") {
          //  const boosters = await booost.find({ GuildID: interaction.guildId });
            const members = await interaction.guild.members.fetch();
            
      let array = [];
      let count = 0;
      if(!interaction.guild.roles.premiumSubscriberRole) {
        return interaction.followUp({ content: `${emoji.error} No server boosters were found.`})
      }
      const membersWithRole =  members.filter(m => m.premiumSinceTimestamp);
      for await (const member of Array.from(membersWithRole.values())) { 
        count++;
        console.log(member)
        array.push(`\`${count}\`. ${member} (${member.user.tag}) • <t:${parseInt(member.premiumSinceTimestamp / 1000)}:F>`);
       await delay(60)
      }
      function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
      }
      
  // Check if there are boosters
  if (array.length === 0) {
    return interaction.followUp({ content: `${emoji.error} No server boosters were found.`})
  }

  // Paginate the boosters using buttons
 

const interval = 10;


 
const range = (array.length == 1) ? '[1]' : `[1 - ${array.length}]`;
let guilds = array;
  const generateEmbed = async start => {
const current = array.slice(start, start + 10)

// You can of course customise this embed however you want
return new EmbedBuilder({
author: { 
 name: `${interaction.user.username}`,
iconURL: interaction.user?.displayAvatarURL({}),
},
thumbnail: {
   url: interaction.guild?.iconURL({ size: 4096, dyanmic: true}),

},
title: `Boosters of ${interaction.guild.name}`,
description: `${current.join(`\n`)}`,
footer: {
  text: `${array.length || 0} users are boosting.`,
  icon_url: interaction.guild?.iconURL({}) || null,
},
color: 0x2c2d31,
})
  };

// Send the embed with the first 10 guilds
const canFitOnOnePage = guilds.length <= 10
const embedMessage = await interaction.followUp({
embeds: [await generateEmbed(0)],
components: canFitOnOnePage
? []
: [new MessageActionRow({components: [forwardButton]})]
})
// Exit if there is only one page of guilds (no need for all of this)
if (canFitOnOnePage) return;

// Collect button interactions (when a user clicks a button),
// but only when the button as clicked by the original message author
const collector = embedMessage.createMessageComponentCollector({
filter: ({user}) => user.id === interaction.user.id
})

let currentIndex = 0
collector.on('collect', async interaction => {
// Increase/decrease index
interaction.customId === backId ? (currentIndex -= 10) : (currentIndex += 10)
// Respond to interaction by updating message with new embed
await interaction.update({
embeds: [await generateEmbed(currentIndex)],
components: [
  new MessageActionRow({
    components: [
      // back button if it isn't the start
      ...(currentIndex ? [backButton] : []),
      // forward button if it isn't the end
      ...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
    ]
  })
]
})

   })
                          
}

            if (interaction.options.getSubcommand() === "lost") {
          let array = [];
          let count = 0;
          if(!interaction.guild.roles.premiumSubscriberRole) {
            return interaction.followUp({ content: `${emoji.error} No server boosters were found.`})
          }
          let Database = await booost.find({ 
            GuildID: interaction.guild.id }).exec(async (err, res) => {
            let g = interaction.guild;
         //if database not found
         if (!res || !res.length) { 
           
           
            return interaction.followUp({ content: `${emoji.error} No server boosters were found.`})
   
         } 
       
         let array = [];
   
         
         for (i = 0; i < res.length; i++) {
        // array.push(`\`${top(i + 1)}. \` <@${res[i].userID}> • **${res[i].messageCount}** messages sent.`);
         array.push(`\`${i + 1}.\` <@${res[i].UserID}> • ${res[i].Date}`);
        
         }

          
      // Check if there are boosters
      if (array.length === 0) {
        return interaction.followUp({ content: `${emoji.error} No server boosters were found.`})
      }
    
      // Paginate the boosters using buttons
     
    
    const interval = 10;
    
    
     
    const range = (array.length == 1) ? '[1]' : `[1 - ${array.length}]`;
    let guilds = array;
      const generateEmbed = async start => {
    const current = array.slice(start, start + 10)
    
    // You can of course customise this embed however you want
    return new EmbedBuilder({
    author: { 
     name: `${interaction.user.username}`,
    iconURL: interaction.user?.displayAvatarURL({}),
    },
    thumbnail: {
       url: interaction.guild?.iconURL({ size: 4096, dyanmic: true}),
    
    },
    title: `Old boosters ${interaction.guild.name}`,
    description: `${current.join(`\n`)}`,
    footer: {
      text: `${array.length || 0} users stopped boosting.`,
      icon_url: interaction.guild?.iconURL({}) || null,
    },
    color: 0x2c2d31,
    })
      };
    
    // Send the embed with the first 10 guilds
    const canFitOnOnePage = guilds.length <= 10
    const embedMessage = await interaction.followUp({
    embeds: [await generateEmbed(0)],
    components: canFitOnOnePage
    ? []
    : [new MessageActionRow({components: [forwardButton]})]
    })
    // Exit if there is only one page of guilds (no need for all of this)
    if (canFitOnOnePage) return;
    
    // Collect button interactions (when a user clicks a button),
    // but only when the button as clicked by the original message author
    const collector = embedMessage.createMessageComponentCollector({
    filter: ({user}) => user.id === interaction.user.id
    })
    
    let currentIndex = 0
    collector.on('collect', async interaction => {
    // Increase/decrease index
    interaction.customId === backId ? (currentIndex -= 10) : (currentIndex += 10)
    // Respond to interaction by updating message with new embed
    await interaction.update({
    embeds: [await generateEmbed(currentIndex)],
    components: [
      new MessageActionRow({
        components: [
          // back button if it isn't the start
          ...(currentIndex ? [backButton] : []),
          // forward button if it isn't the end
          ...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
        ]
      })
    ]
    })
    
       })
    })
        }
    }
}
