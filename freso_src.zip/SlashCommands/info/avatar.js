const { ActionRowBuilder, SelectMenuBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
const { Color } = require(`../../config.json`)
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const db = require(`quick.db`)

module.exports = {
	name: 'avatar',
type: ApplicationCommandType.ChatInput,
	description: "Get the avatar/banner of a user",

   options: [
                {
                    name: 'user',
                    description: 'User..',
                    type: ApplicationCommandOptionType.User,
                }
            ],
    
	run: async (client, interaction) => {
await interaction.deferReply();
    let user = interaction.options.getUser(`user`) || interaction.user;
    const backId = 'back'
const forwardId = 'forward'
const backButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Back',

  customId: backId
})
const forwardButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Forward',

  customId: forwardId
});
  await user.fetch();
     
       const f = user.bannerURL({  size: 4096 });
    let g = interaction.guild;

   const embed = new EmbedBuilder()
.setColor(Color)
//.setDescription(`[**PNG**](${user?.displayAvatarURL({ extension: 'png'})}) | [**JPG**](${user?.displayAvatarURL({ extension: 'jpg'})}) `)
.setImage(user?.displayAvatarURL({ size: 4096 }))
.setAuthor({ name: `${user.tag}`, iconURL: user?.displayAvatarURL({dynamic:true}) })                              
let emb = new EmbedBuilder()

if(f) {
emb.setColor(Color)
emb.setImage(f)
}
if(!f) {
  emb.setColor(Color)
emb.setDescription(`No banner was found`)
}
          
      const o2w = new MessageActionRow()
			.addComponents(
         new MessageButton()
	.setCustomId("banner")
					.setLabel(`User Banner`)
					.setStyle(ButtonStyle.Secondary))


interaction.followUp({ embeds: [embed], components: [o2w] });
let msg = await interaction.fetchReply()
       					let filter = (m) => m.user.id === interaction.user.id
					let collector = msg.createMessageComponentCollector({
						filter,
		idle: 60000,
					})
        
	collector.on('collect', async (button) => {
    let b = button;
await button.deferUpdate();
      if (button.customId === "banner") {

interaction.editReply({ embeds: [emb], components: [new MessageActionRow()
			.addComponents(
         new MessageButton()
	.setCustomId("e2")
					.setLabel(`Avatar`)
					.setStyle(ButtonStyle.Secondary))
] })
}
      if (button.customId === "e2") {
interaction.editReply({ embeds: [embed], components: [new MessageActionRow()
			.addComponents(
         new MessageButton()
	.setCustomId("e")
					.setLabel(`Banner`)
					.setStyle(ButtonStyle.Secondary))
] })
}

})
    function top(index) {
      return index === 1 ? '??' : index === 2 ? '??' : index === 3 ? '??' : index < 10 ? String(`0${index}`) : index;
    }
  }
};