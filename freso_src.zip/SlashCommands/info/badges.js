const Discord = require("discord.js");
const { Color } = require("../../config.json");
const figlet = require("figlet");
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const { promisify } = require("util");
const figletAsync = promisify(figlet);
const wait = require('util').promisify(setTimeout);
const ms = require("ms")
const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ComponentType } = require("discord.js")

module.exports = {
    name: "badges",
    description: "Display stats on users in this server with certain badges",
    run: async (client, interaction) => {
await interaction.deferReply();
        let badges = []
        let counts = {}

        for (const member of interaction.guild.members.cache.values()) {
            const user = await client.users.fetch(member.user.id)
            badges = badges.concat(user.flags?.toArray())
        }

        for (const badge of badges) {
            if (counts[badge]) {
                counts[badge]++
            } else {
                counts[badge] = 1
            }
        }
let staff = `<:Staff:1128872788774617182>`;
let partner = `<:1835iconpartneredserverowner:1128193955767533628>`;
let dev = `<:BadgeEarlyVerifiedBotDeveloper:1128872810949918891>`;
let mod = `<:OfficialModerator:1128872790817247323>`;
let events =  `<:DiscordHypeSquad:1128872795271594014>`;
        let embed1 = new EmbedBuilder()
            .setColor(Color)
            .setAuthor({ name: `Badges - ${interaction.guild.name}`, iconURL: client.user.displayAvatarURL() })
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true })}`)
            .setDescription(`${staff} Discord Staff: \`${counts['Staff'] || 0}\`
            ${partner} Partner: \`${counts['Partner'] || 0}\`
            ${mod} Certified Moderator: \`${counts['CertifiedModerator'] || 0}\`
            ${events} HypeSquad Events: \`${counts['Hypesquad'] || 0}\`
            <:DiscordHypeSquadBravery:1128872797255508059> HypeSquad Bravery: \`${counts['HypeSquadOnlineHouse1'] || 0}\`
            <:DiscordHypeSquadBrilliance:1128872799562375180> HypeSquad Brilliance: \`${counts['HypeSquadOnlineHouse2'] || 0}\`
            <:DiscordHypeSquadBalance:1128872802028630036> HypeSquad Balance: \`${counts['HypeSquadOnlineHouse3'] || 0}\`
            <:DiscordBugHunter:1128872804150935643> Bug Hunter: \`${counts['BugHunterLevel1'] || 0}\`
            <:bug_hunter_2:1128872806579445780> Bug Hunter Gold: \`${counts['BugHunterLevel2'] || 0}\`
            <:activedev:1128872808672399450> Active Developer: \`${counts['ActiveDeveloper'] || 0}\`
            ${dev} Early Verified Bot Developer: \`${counts['VerifiedDeveloper'] || 0}\`
            <:EarlySupporter:1128872813273547013> Early Supporter: \`${counts['PremiumEarlySupporter'] || 0}\``);

        const row = new ActionRowBuilder()

        const menu = new StringSelectMenuBuilder()
            .setCustomId("badges")
            .setPlaceholder("Badges")
            .setOptions(
                {
                    label: `Discord Staff (${counts['Staff'] || 0})`,
                    emoji: "<:Discord_Staff:1116618574929342526>",
                    value: "Staff",
                },
                {
                    label: `Partner (${counts['Partner'] || 0})`,
                    emoji: "<:Partner:1116633016454893638>",
                    value: "Partner",
                },
                {
                    label: `Certified Moderator (${counts['CertifiedModerator'] || 0})`,
                    emoji: "<:Certified_Moderator:1116618322952331276>",
                    value: "CertifiedModerator",
                },
                {
                    label: `HypeSquad Events (${counts['Hypesquad'] || 0})`,
                    emoji: "<:HypeSquad_Events:1116618816680624159>",
                    value: "Hypesquad",
                },
                {
                    label: `HypeSquad Bravery (${counts['HypeSquadOnlineHouse1'] || 0})`,
                    emoji: "<:HypeSquad_Bravery:1116618771084345384>",
                    value: "HypeSquadOnlineHouse1",
                },
                {
                    label: `HypeSquad Brilliance (${counts['HypeSquadOnline2'] || 0})`,
                    emoji: "<:HypeSquad_Brilliance:1116618789962907668>",
                    value: "HypeSquadOnlineHouse2",
                },
                {
                    label: `HypeSquad Balance (${counts['HypeSquadOnlineHouse3'] || 0})`,
                    emoji: "<:HypeSquad_Balance:1116618747919216640>",
                    value: "HypeSquadOnlineHouse3"
                },
                {
                    label: `Bug Hunter (${counts['BugHunterLevel1'] || 0})`,
                    emoji: "<:Bug_Hunter:1116618281835581450>",
                    value: "BugHunterLevel1",
                },
                {
                    label: `Bug Hunter Gold (${counts['BugHunterLevel2'] || 0})`,
                    emoji: "<:Bug_Hunter_Gold:1116618300600889404>",
                    value: "BugHunterLevel2",
                },
                {
                    label: `Active Developer (${counts['ActiveDeveloper'] || 0})`,
                    emoji: "<:Active_Developer:1116618034287751241>",
                    value: "ActiveDeveloper",
                },
                {
                    label: `Early Verified Bot Developer (${counts['VerifiedDeveloper'] || 0})`,
                    emoji: "<:Early_Verified_Bot_Developer:1116618702826242088>",
                    value: `VerifiedDeveloper`,
                },
                {
                    label: `Early Supporter (${counts['PremiumEarlySupporter'] || 0})`,
                    emoji: `<:Early_Supporter:1116618595271704606>`,
                    value: `PremiumEarlySupporter`,
                }
            );

        row.addComponents(menu)

     return await interaction.followUp({ embeds: [embed1], });
        let msg = null;
        let collector = msg.createMessageComponentCollector({ componentType: ComponentType.StringSelect });

        collector.on('collect', async (interaction) => {
            let check = interaction.values[0];
            interaction.message.edit()

            let members = []
            await interaction.guild.members.cache.forEach(async member => {
                if (member.user.flags.toArray().includes(check)) members.push(member)
            });

            if (members.length == 0) members.push('No members found')

            if (check === "Staff") {

                let embed_staff = new EmbedBuilder()
                    .setColor("Blurple")
                    .setTitle(`<:Discord_Staff:1116618574929342526> Discord Staff (${counts['Staff'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                return interaction.reply({ embeds: [embed_staff], ephemeral: true })

            }
            if (check === "Partner") {

                let embed_partner = new EmbedBuilder()
                    .setColor("Blurple")
                    .setTitle(`<:Partner:1116633016454893638> Partner (${counts['Partner'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                return interaction.reply({ embeds: [embed_partner], ephemeral: true })

            }
            if (check === "CertifiedModerator") {

                let embed_moderator = new EmbedBuilder()
                    .setColor("Orange")
                    .setTitle(`<:Certified_Moderator:1116618322952331276> Certified Moderator (${counts['CertifiedModerator'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                return interaction.reply({ embeds: [embed_moderator], ephemeral: true })
            }
            if (check === "Hypesquad") {

                let embed_hypesquad = new EmbedBuilder()
                    .setColor("Gold")
                    .setTitle(`<:HypeSquad_Events:1116618816680624159> HypeSquad Events (${counts['Hypesquad'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                return interaction.reply({ embeds: [embed_hypesquad], ephemeral: true })
            }
            if (check === "HypeSquadOnlineHouse1") {

                let embed_bravery = new EmbedBuilder()
                    .setColor("Purple")
                    .setTitle(`<:HypeSquad_Bravery:1116618771084345384> HypeSquad Bravery (${counts['HypeSquadOnlineHouse1'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                return interaction.reply({ embeds: [embed_bravery], ephemeral: true })
            }
            if (check === "HypeSquadOnlineHouse2") {

                let embed_brilliance = new EmbedBuilder()
                    .setColor("#f17a65")
                    .setTitle(`<:HypeSquad_Brilliance:1116618789962907668> HypeSquad Brilliance (${counts['HypeSquadOnlineHouse2'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                return interaction.reply({ embeds: [embed_brilliance], ephemeral: true })
            }
            if (check === "HypeSquadOnlineHouse3") {

                let embed_balance = new EmbedBuilder()
                .setColor("#42d0b9")
                    .setTitle(`<:HypeSquad_Balance:1116618747919216640> HypeSquad Balance (${counts['HypeSquadOnlineHouse3'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                return interaction.reply({ embeds: [embed_balance], ephemeral: true })
            }
            if (check === "BugHunterLevel1") {

                let embed_bug1 = new EmbedBuilder()
                .setColor("Green")
                    .setTitle(`<:Bug_Hunter:1116618281835581450> Bug Hunter (${counts['BugHunterLevel1'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                    return interaction.reply({ embeds: [embed_bug1], ephemeral: true })
            }
            if (check === "BugHunterLevel2") {

                let embed_bug2 = new EmbedBuilder()
                .setColor("Gold")
                    .setTitle(`<:Bug_Hunter_Gold:1116618300600889404> Bug Hunter Gold (${counts['BugHunterLevel2'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                    return interaction.reply({ embeds: [embed_bug2], ephemeral: true })
            }
            if (check === "ActiveDeveloper") {

                let embed_active_dev = new EmbedBuilder()
                .setColor("#2da864")
                    .setTitle(`<:Active_Developer:1116618034287751241> Active Developer (${counts['ActiveDeveloper'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                    return interaction.reply({ embeds: [embed_active_dev], ephemeral: true })
            }
            if (check === "VerifiedDeveloper") {

                let embed_verified_developer = new EmbedBuilder()
                .setColor("Blurple")
                    .setTitle(`<:Early_Verified_Bot_Developer:1116618702826242088> Early Verified Bot Developer (${counts['VerifiedDeveloper'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                    return interaction.reply({ embeds: [embed_verified_developer], ephemeral: true })
            }
            if (check === "PremiumEarlySupporter") {

                let embed_verified_developer = new EmbedBuilder()
                .setColor("Blurple")
                    .setTitle(`<:Early_Supporter:1116618595271704606> Early Supporter (${counts['PremiumEarlySupporter'] || 0})`)
                    .setDescription(`The people with this badge within the server: \n\n> ${members.join('\n> ')}`);

                    return interaction.reply({ embeds: [embed_verified_developer], ephemeral: true })
            }
        })

    }
}