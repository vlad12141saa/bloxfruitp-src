const { ActionRowBuilder, SelectMenuBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
const { Color } = require(`../../config.json`)
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const Discord = require ("discord.js")
const moment = require('moment');
const emoji = require("../../emoji.json") 

module.exports = {

  name: "serverinfo",

  category: "info",

  aliases: ["server"],

  description: "Get information about your server.",

  usage: "serverinfo ",
 options: [
        {
            name: 'invite',
            description: 'Server invite link.',
        
       type: ApplicationCommandOptionType.String,
          
        },
 ],
    run: async(client, interaction, args) => {
      const inv = interaction.options.getString(`invite`);
      if(inv) {
        await interaction.deferReply()
        const { time } = require('@discordjs/builders');
const moment = require('moment');

         let invite = await client.fetchInvite(inv);
       let i = invite;
        let guild = i.guild;
                let p = {
            "true": `<:1835iconpartneredserverowner:1128193955767533628>`,
            "false": "No"
        };
        let ve = {
            "true": "<:ServerVerifiedIcon:1128193766323388506>",
            "false": "No"
        };
          let v = {
      NONE: "None",
      LOW: "Low",
      MEDIUM: "Medium",
      HIGH: "High",
      VERY_HIGH: `Very High`,
    };
      const row = new MessageActionRow()
			.addComponents(
          new MessageButton()
	.setCustomId("features")

					.setLabel(`Next Page`)
					.setStyle(ButtonStyle.Secondary))
  const emb = new MessageEmbed()
  .setTitle(`${guild.name}`)
  
   .setImage(guild.bannerURL({ dynamic: true, size: 4096 }))
         .addFields({ name: `Created At`, value: `<t:${parseInt(guild.createdTimestamp / 1000 )}:F>`})
  
  .setDescription(`Members \`${i.memberCount}\`\nOnline \`${i.presenceCount}\` `)
  .addFields({ name: `Name`, value: `\`${i.guild.name}\``})
      .addFields({ name: `Description`, value: `\`${i.guild.description || 'None'}\``})
      .addFields({ name: `Invite Channel`, value: `[\`${i.channel.name}\`](https://discord.gg/${i.code})`})
      
       .addFields({ name: `Partnered`, value: `${p[i.guild.partnered]}`})

       .addFields({ name: `Verifed`, value: `${ve[i.guild.verified]}` })
    
       .addFields({ name: `Vanity`, value: `${i.guild.vanityURLCode || `None`}` })
     
      .setFooter({ text: `${i.guild.name} | ${i.guild.id}`, iconURL: guild.iconURL({ dynamic: true })})
     .setColor(Color)
      .setThumbnail(guild.iconURL({ dynamic: true,}));
       interaction.followUp({ components: [row], embeds: [emb], fetchReply: true})
let msg = await interaction.fetchReply()
					let filter = (m) => m.user.id === interaction.user.id
					let collector = msg.createMessageComponentCollector({
						filter,
         
						time: 60000
					})
	collector.on('collect', async (button) => {
    let b = button;
      if (button.customId === "main") {
b.deferUpdate();
     
msg.edit({ embeds: [emb], components: [row]})
      }
      if (button.customId === "features") {
b.deferUpdate();
const ee = new MessageEmbed()
 .setTitle(`${guild.name}`)
 
   .setImage(guild.bannerURL({ dynamic: true, size: 4096 }))
         .addFields({ name: `Created At`, value: `<t:${parseInt(guild.createdTimestamp / 1000 )}:F>`})
  .addFields({ name: `Name`, value: `\`${guild.name}\``})

  .addFields({ name: `Inviter`, value: `\`${i.inviter || 'Unknown'}\``})
  .setDescription(`Feature(s): \n\`${guild.features.join(" ") || 'None'}\``, true)
      .setFooter({ name: `${i.guild.name}`, iconURL: i.guild.iconURL({ dynamic: true })})
     .setColor(Color)
      .setThumbnail(guild.iconURL({ dynamic: true,}));
       const row1 = new MessageActionRow()
			.addComponents(
          new MessageButton()
	.setCustomId("main")

					.setLabel(`Flip Page`)
				.setStyle(ButtonStyle.Secondary))
msg.edit({ embeds: [ee], components: [row1]})
      }

  })
          
      }
await interaction.reply(`Please wait as I get information...`)
let member = await interaction.guild.members.fetch();
let channel = await interaction.guild.channels.fetch();
let roleg = await interaction.guild.roles.fetch();
let emoji = await interaction.guild.emojis.fetch();
let sticker = await interaction.guild.stickers.fetch();
    const Members = {
      Total: interaction.guild.memberCount,
      Humans: member.filter(m => !m.user.bot).size,
      Bots: member.filter(m => m.user.bot).size,
    }

    const Channels = {
      Cate: channel.filter(c => c.type === "GUILD_CATEGORY").size,
      Text: channel.filter(c => c.type === "GUILD_TEXT").size,
      Voice: channel.filter(c => c.type === "GUILD_VOICE").size,
      
    };
    const Roles = {
      Total: roleg.size,
      Hoisted: roleg.filter(r => r.hoist).size,
      Managed: roleg.filter(r => r.managed).size,
    };

    const Emojis = {
      Total: emoji.size,
      Static: emoji.filter(e => !e.name.startsWith("a_")).size,
      Animated: emoji.filter(e => e.name.startsWith("a_")).size
    }

    const Stickers = {
      Total: sticker.size,
      Static: sticker.filter(e => !e.name.startsWith("a_")).size,
      Animated: sticker.filter(e => e.name.startsWith("a_")).size
    }

    const Tiers = {
      NONE: "No Level",
      TIER_1: "Level 1",
      TIER_2: "Level 2",
      TIER_3: "Level 3"
    }

    let Features = [];

    if(interaction.guild.features.includes(`COMMUNITY`)) Features.push(`Community`);
    if(interaction.guild.features.includes(`INVITE_SPLASH`)) Features.push(`[Splash](${interaction.guild.splashURL()})`);
    if(interaction.guild.features.includes(`VANITY_URL`)) Features.push(`[Vanity](https://discord.gg/${interaction.guild.vanityURLCode})`);
    if(interaction.guild.features.includes(`PARTNERED`)) Features.push(`Partner`);
    if(interaction.guild.features.includes(`VERIFIED`)) Features.push(`Verified`);
  
    
		const embed = new MessageEmbed()
    .setAuthor({
      name: interaction.guild.name,
      iconURL: interaction.guild.iconURL({ dynamic: true })
    })
.setColor(`${Color}`)
    .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
    .setImage(interaction.guild.bannerURL({ dynamic: true, size: 512 }) ?? null)
    .addFields({ name: `Owner`, value: `${(await interaction.guild.fetchOwner()).user}\n(${(await interaction.guild.fetchOwner()).user.tag})`})
    .addFields({ name: `Members`, value:
              `Total: **${Members.Total}**\n` +
              `Humans: **${Members.Humans}**\n` +
              `Bots: **${Members.Bots}**`})
    .addFields({ name: `Created`, value: `<t:${parseInt(interaction.guild.createdTimestamp / 1000)}:R>\n(<t:${parseInt(interaction.guild.createdTimestamp / 1000)}:D>)`})

    .addFields({ name: `Boosts`, value: `**${interaction.guild.premiumSubscriptionCount}** boosts\n(${Tiers[interaction.guild.premiumTier]})`})
    .addFields({ name: `Roles`, value:
              `Total: **${Roles.Total}**\n` +
              `Hoisted: **${Roles.Hoisted}**\n` +
              `Managed: **${Roles.Managed}**` 
             , })
    .addFields({ name: `Channels`, value:
              `Categories: **${Channels.Cate}**\n` +
              `Text: **${Channels.Text}**\n` +
              `Voice: **${Channels.Voice}**`
              , })

    .addFields({ name: `Emojis`, value:
              `Total: **${Emojis.Total}**\n` +
              `Static: **${Emojis.Static}**\n` +
              `Animated: **${Emojis.Animated}**`
              , })
    .addFields({ name: `Stickers`, value:
              `Total: **${Stickers.Total}**\n` +
              `Static: **${Stickers.Static}**\n` +
              `Animated: **${Stickers.Animated}**`
              ,})
    .addFields({ name: `Features`, value: `${Features.join(" ") || 'None'}`})
    

    interaction.editReply({
      embeds: [embed],
      content: ` `,
    }).catch((e) => {
interaction.editReply({ content: `${emoji.error} there was a error..\n\`\`\`${e}\`\`\`\`` })
})
}
}