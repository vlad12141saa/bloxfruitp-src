const { ActionRowBuilder, SelectMenuBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');

let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const { QuickDB } = require("quick.db");
const db = new QuickDB();
module.exports = {
	name: 'names',
type: ApplicationCommandType.ChatInput,
	description: "View username and nickname history of members or yourself.",

   options: [
                {
                    name: 'user',
                    description: 'User',
                    type: ApplicationCommandOptionType.User,
                }
            ],
    
	run: async (client, interaction) => {
await interaction.deferReply();
    const backId = 'back'
const forwardId = 'forward'
const backButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Back',

  customId: backId
})
const forwardButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Forward',

  customId: forwardId
});
    let g = interaction.guild;
    let user = interaction.options.getUser(`user`) || interaction.user;
    let data = await db.get(`usernames${user.id}`)
if(!data) return interaction.followUp(`No logged data was found.`)
   let guilds = data;
    let array = data;
     const generateEmbed = async start => {
  const current = array.slice(start, start + 10)

  // You can of course customise this embed however you want
  return new MessageEmbed({

   title: `Names of ${user.tag}`,
    description: `${current.join(`\n`)}`,
    color: 0x2f3136
   })
      };
    
// Send the embed with the first 10 guilds
const canFitOnOnePage = guilds.length <= 10
const embedMessage = await interaction.followUp({
  embeds: [await generateEmbed(0)],
  components: canFitOnOnePage
    ? []
    : [new MesssageActionRow ({components: [forwardButton]})]
})
// Exit if there is only one page of guilds (no need for all of this)
if (canFitOnOnePage) return;

// Collect button interactions (when a user clicks a button),
// but only when the button as clicked by the original message author
const collector = embedMessage.createMessageComponentCollector({
  filter: ({user}) => user.id === interaction.user.id
})

let currentIndex = 0
collector.on('collect', async interaction => {
  // Increase/decrease index
  interaction.customId === backId ? (currentIndex -= 10) : (currentIndex += 10)
  // Respond to interaction by updating message with new embed
  await interaction.update({
    embeds: [await generateEmbed(currentIndex)],
    components: [
      new MessageActionRow({
        components: [
          // back button if it isn't the start
          ...(currentIndex ? [backButton] : []),
          // forward button if it isn't the end
          ...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
        ]
      })
    ]
  })
  
       })
                              
  
              
    
    function top(index) {
      return index === 1 ? '??' : index === 2 ? '??' : index === 3 ? '??' : index < 10 ? String(`0${index}`) : index;
    }
  }
};