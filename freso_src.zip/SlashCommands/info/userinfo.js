const { ActionRowBuilder, SelectMenuBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
const { Color } = require(`../../config.json`)
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
let emoji = require(`../../emoji.json`)
const db = require(`quick.db`)

module.exports = {
	name: 'user',
type: ApplicationCommandType.ChatInput,
	description: "Most detailed user info command ever.",

   options: [
                {
                    name: 'user',
                    description: 'User',
                    type: ApplicationCommandOptionType.User,
                }
            ],
    
	run: async (client, interaction) => {
await interaction.deferReply();
const formatter = new Intl.ListFormat(`en-US`, { style: `narrow`, type: `conjunction` });
    let user = interaction.options.getUser(`user`) || interaction.user;
    const userFlags = user.flags.toArray();
    const backId = 'back'
const forwardId = 'forward'
const backButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Back',

  customId: backId
})
const forwardButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Forward',

  customId: forwardId
});
  await user.fetch();
  const badges = {
    BugHunterLevel1: "<:DiscordBugHunter:1128872804150935643>",
    BugHunterLevel2: "<:bug_hunter_2:1128872806579445780>",
    HypeSquadOnlineHouse1: "<:DiscordHypeSquadBravery:1128872797255508059>",
    HypeSquadOnlineHouse2: "<:DiscordHypeSquadBrilliance:1128872799562375180>",
    HypeSquadOnlineHouse3: "<:DiscordHypeSquadBalance:1128872802028630036>",
    Hypesquad: "<:DiscordHypeSquad:1128872795271594014>",
    Partner: "<:1835iconpartneredserverowner:1128193955767533628>",
    PremiumEarlySupporter: "<:EarlySupporter:1128872813273547013>",
    Staff: "<:Staff:1128872788774617182>",
    VerifiedDeveloper: "<:BadgeEarlyVerifiedBotDeveloper:1128872810949918891>",
    ActiveDeveloper: "<:activedev:1128872808672399450>",
    VerifiedBot: `<:VerifiedBot:1129266556724052019>`,
    CertifiedModerator: `<:OfficialModerator:1128872790817247323>`,
}
  let member =  interaction.guild.members.cache.get(user.id);
  if(!member) member = await interaction.guild.members.cache.get(user.id);
  if(!member) member = null;
  const MutualServers = []
if(member) { 
        let roles = [];
        let roleCount = 10;
        await member._roles.forEach( async (roleID) => {
            let role = await interaction.guild.roles.fetch(roleID);
            roles.push({
                id: role.id,
                name: role.name,
                position: role.position
            });
        });

        roles = roles.sort( (a, b) => b.position - a.position ).map( (role) => `<@&${role.id}>` );

        for (const Guild of client.guilds.cache.values()) {
          if (Guild.members.cache.get(user.id) && Guild.members.cache.get(interaction.user.id)) {
              MutualServers.push(`[${Guild.name}](https://discord.com/guilds/${Guild.id})`)
          }
      }

        if (roles.length >= roleCount) {
            roles = roles.slice(0, roleCount);
            roles.push(`... and ${member._roles.length - roleCount} more (${member._roles.length} total)`);
        }
      
        const JoinPosition = await interaction.guild.members.fetch().then(Members => Members.sort((a, b) => a.joinedAt - b.joinedAt).map((User) => User.id).indexOf(member.id) + 1)

     
       const f = user.bannerURL({ size: 4096, dynamic: true});
    let g = interaction.guild;

   const embed = new EmbedBuilder()
.setColor(`#2c2d31`)
.setThumbnail(user?.displayAvatarURL({size: 4096, }))
.setAuthor({ name: `${user.tag}`, iconURL: user.displayAvatarURL({ })})                              
.setImage(f)
 const ee = interaction.guild.members.cache.get(user.id)
    if(ee) { 
      embed.setDescription(`${roles.join('\n')}`)
      embed.addFields({ name: 'User', value: `${user.tag} (**${user.id}**)\nRegistration: <t:${parseInt(user.createdTimestamp / 1000)}:F> [<t:${parseInt(user.createdTimestamp / 1000)}:R>]`, inline: true, })
//	embed.addFields({ name: 'User roles', value: `${ee.roles.cache.sort((a, b) => b.position - a.position).map(r => r).join(" ").replace("@everyone", "") || "None"}`, inline: true, })
embed.addFields({ name: 'User ID', value: `${ee.id}`, inline: false, })
embed.addFields({ name: 'User Badges', value: `${userFlags.length ? formatter.format(userFlags.map(flag => `${badges[flag]}`)) : ` `}`, inline: true, })
embed.addFields({ name: 'User Joined', value: `<t:${parseInt(ee.joinedTimestamp / 1000 )}:F>`, inline: true, })
embed.addFields({ name: 'Last 5 Tags:', value: `No Tags Tracked`, inline: true, })
embed.addFields({ name: 'Ban Stats:', value: `No Data Tracked`, inline: true, })
embed.setFooter({ text: `${member ? `Join Position - ${JoinPosition} | ` : ''} Mutual Servers - ${MutualServers.length}`, iconURL: user?.displayAvatarURL()})
}
interaction.followUp({ embeds: [embed] });
} else {
  for (const Guild of client.guilds.cache.values()) {
    if (Guild.members.cache.get(user.id) && Guild.members.cache.get(interaction.user.id)) {
        MutualServers.push(`[${Guild.name}](https://discord.com/guilds/${Guild.id})`)
    }
}
  const f = user.bannerURL({ size: 4096, });
  let g = interaction.guild;
let ee = user;
 const embed = new EmbedBuilder()
.setColor(`#2c2d31`)
.setThumbnail(user?.displayAvatarURL({size: 4096, }))
.setAuthor({ name: `${user.tag}`, iconURL: user.displayAvatarURL({dynamic:true}) })                              
.setImage(f)

    embed.addFields({ name: 'User', value: `${user.tag} (**${user.id}**)\nRegistration: <t:${parseInt(user.createdTimestamp / 1000)}:F> [<t:${parseInt(user.createdTimestamp / 1000)}:R>]`, inline: true, })
embed.addFields({ name: 'User ID', value: `${user.id}`, inline: false, })
embed.addFields({ name: 'User Badges', value: `${userFlags.length ? formatter.format(userFlags.map(flag => `${badges[flag]}`)) : ` `}`, inline: true, })
embed.setDescription(`${emoji.success} you and this user have **${MutualServers.length}** mutual servers on this shard`)
embed.addFields({ name: 'Last 5 Tags:', value: `No Tags Tracked`, inline: true, })

  
interaction.followUp({ embeds: [embed] });
}
    
    function top(index) {
      return index === 1 ? '??' : index === 2 ? '??' : index === 3 ? '??' : index < 10 ? String(`0${index}`) : index;
    }
  }
};