
const moment = require('moment')
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const warnings = require("../../database/guildData/warnings")
module.exports = {
    name: "ban",
    description: "Ban a member.",
type: ApplicationCommandType.ChatInput,
    subCommands: ["member", "soft", "hack", "remove"],
    category: "Moderation",
    userPerms: ["BAN_MEMBERS"],
    botPerms: ["BAN_MEMBERS", "EMBED_LINKS"],
    options: [
        {
            name: "add",
            description: "User to ban.",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "member",
                    description: "The member to ban.",
                   type: ApplicationCommandOptionType.User,   
                 required: true
                },
                {
                    name: "reason",
                    description: "Reason for the ban.",
                      type: ApplicationCommandOptionType.String,
                      required: false
                },
                {
                  name: "duration",
                  description: "The number of days for the ban to last",
                 type: ApplicationCommandOptionType.Number,   
               required: false
              },
              {
                name: "delete_messages",
                description: "Delete react messages",
               type: ApplicationCommandOptionType.Boolean,   
             required: false
            },
            ]
        },
        {
          name: "remove",
          description: "User to remove ban from.",
        type: ApplicationCommandOptionType.Subcommand,
          options: [
              {
                  name: "id",
                  description: "User ID to unban?",
                 type: ApplicationCommandOptionType.User,   
               required: true
              },
              {
                  name: "reason",
                  description: "Reason for the unban.",
                    type: ApplicationCommandOptionType.String,
                    required: false
              },
              
          ]
      },
      {
        name: "list",
        description: "Shows a list of all banned users.",
      type: ApplicationCommandOptionType.Subcommand,
    },
    ],
    run: async(client, interaction, args) => {
   
      await interaction.deferReply();
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers))
      return interaction.followUp({ ephemeral: true,
      embeds: [
      {
      color: 0x6787e7,
      author: {
      name: `${interaction.user.tag}`,
      icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
      
      },
      // footer: { icon_url: client.user.displayAvatarURL() },
      footer: {
      text: `${client.user.username}`,
      icon_url: `${client.user.displayAvatarURL()}`,
      },
      
      description: `You're missing the \`BanMembers\` permission`,
      timestamp: new Date(),
      },
      ],
      })
        if (interaction.options.getSubcommand() === "add") {
            let reason =  interaction.options.getString("reason");
            let duration = interaction.options.getNumber("duration");
            let delete_messages = interaction.options.getBoolean("delete_messages");
    if (!reason) reason = "Unspecified"
    const target = await interaction.options.getUser(`member`);	
    let user = target;
    if(target.id === interaction.user.id) {
      return interaction.followUp(`-_-`)
    }
    if (target.id === interaction.guild.ownerId) {
      return interaction.followUp("-_-")
    }
  let memberfound = interaction.guild.members.cache.get(target.id);
  if(!memberfound) memberfound = null;

if(memberfound) { 
  const boostconfirm = new ActionRowBuilder()
           .addComponents(
            new ButtonBuilder()
            .setCustomId('yes-ban')
			.setLabel('Confirm Ban')
			.setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
			.setCustomId('no-ban')
			.setLabel('Cancel')
			.setStyle(ButtonStyle.Secondary))

  if(interaction.user.id === interaction.guild.ownerId) {

    if (memberfound.premiumSinceTimestamp) {
      let msg = await interaction.followUp({  components: [boostconfirm], embeds:[new EmbedBuilder()
        .setAuthor({ name: `${memberfound.user.username}`, iconURL: `${memberfound.user?.displayAvatarURL({dynamic: true})}` })
      .setColor(Color)
      .setDescription(`<a:Boosts:1124367085485707307> This user is **boosting** the server should I still ban?`)
    ]})
      let filter = (m) => m.user.id === interaction.user.id;
      let collector = msg.createMessageComponentCollector({
        filter,
        type: "BUTTON",
        time: 60000,
        max: 1,
      });

      collector.on("collect", async (button) => {
        if (button.customId && button.customId === "yes-ban") {
          button.deferUpdate();

          let emb = new MessageEmbed()
          .setColor(`${Color}`)
                    
              .setDescription(`${target} you have been **banned** from ${interaction.guild.name} for ${reason}`)
         
          const row = new MessageActionRow()
               .addComponents(
                 new MessageButton()
           .setURL('https://discord.gg/WJhUSDw4pM')
                   .setLabel('Support')
                   .setStyle(ButtonStyle.Link), new MessageButton()
                      .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
                   .setLabel('Invite')
                   .setStyle(ButtonStyle.Link))
                   memberfound.user.send({ embeds: [emb], components: [row] })
          if(delete_messages === true) {
            await interaction.guild.members.ban(target.id,{
            reason: reason ? `Banned by ${interaction.user.tag}`: reason,
            days: duration || null,
            deleteMessageSeconds: 604799,
       }).catch((ee) => {
        return interaction.followUp({  embeds:[new EmbedBuilder()
        .setColor(Color)
        .setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
        });
      })
    } else {
      await interaction.guild.members.ban(target.id,{
        reason: reason ? `Banned by ${interaction.user.tag}`: reason,
        days: duration || null,
     //   deleteMessageDays: 7,
   }).catch((ee) => {
    return interaction.followUp({  embeds:[new EmbedBuilder()
    .setColor(Color)
    .setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
    });
  })
    }
      button.message.edit(`${target}: :eagle:`)
        }
        if (button.customId && button.customId === "no-ban") {
          button.deferUpdate();

          return button.message.delete();
        }
        
      })
    
    } else { 
      let emb = new MessageEmbed()
      .setColor(`${Color}`)
                
          .setDescription(`${target} you have been **banned** from ${interaction.guild.name} for ${reason}`)
     
      const row = new MessageActionRow()
           .addComponents(
             new MessageButton()
       .setURL('https://discord.gg/WJhUSDw4pM')
               .setLabel('Support')
               .setStyle(ButtonStyle.Link), new MessageButton()
                  .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
               .setLabel('Invite')
               .setStyle(ButtonStyle.Link))
               memberfound.user.send({ embeds: [emb], components: [row] })
               interaction.followUp(`${target}: :eagle:`)
               if(delete_messages === true) {
                await interaction.guild.members.ban(target.id,{
                reason: reason ? `Banned by ${interaction.user.tag}`: reason,
                days: duration || null,
                deleteMessageSeconds: 604799,
           }).catch((ee) => {
            return interaction.followUp({  embeds:[new EmbedBuilder()
            .setColor(Color)
            .setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
            });
          })
        } else {
          await interaction.guild.members.ban(target.id,{
            reason: reason ? `Banned by ${interaction.user.tag}`: reason,
            days: duration || null,
         //   deleteMessageDays: 7,
       }).catch((ee) => {
        return interaction.followUp({  embeds:[new EmbedBuilder()
        .setColor(Color)
        .setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
        });
      })
        }
    }
  } else { 
    if (memberfound.roles.highest.position >= interaction.member.roles.highest.position) {
      return interaction.followUp(`${emoji.error} You can not ban this user, due to your role placement.`);
    }
    if (memberfound.premiumSinceTimestamp) {
      let msg = await interaction.followUp({  components: [boostconfirm], embeds:[new EmbedBuilder()
        .setAuthor({ name: `${memberfound.user.username}`, iconURL: `${memberfound.user?.displayAvatarURL({dynamic: true})}` })
      .setColor(Color)
      .setDescription(`This user is **boosting** the server should I still ban?`)
    ]})
      let filter = (m) => m.user.id === interaction.user.id;
      let collector = msg.createMessageComponentCollector({
        filter,
        type: "BUTTON",
        time: 60000,
        max: 1,
      });

      collector.on("collect", async (button) => {
        if (button.customId && button.customId === "yes-ban") {
          button.deferUpdate();
          let emb = new MessageEmbed()
          .setColor(`${Color}`)
                    
              .setDescription(`${target} you have been **banned** from ${interaction.guild.name} for ${reason}`)
         
          const row = new MessageActionRow()
               .addComponents(
                 new MessageButton()
           .setURL('https://discord.gg/WJhUSDw4pM')
                   .setLabel('Support')
                   .setStyle(ButtonStyle.Link), new MessageButton()
                      .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
                   .setLabel('Invite')
                   .setStyle(ButtonStyle.Link))
                   memberfound.user.send({ embeds: [emb], components: [row] })
                   interaction.followUp(`${target}: :eagle:`)
                   if(delete_messages === true) {
                    await interaction.guild.members.ban(target.id,{
                    reason: reason ? `Banned by ${interaction.user.tag}`: reason,
                    days: duration || null,
                    deleteMessageSeconds: 604799,
               }).catch((ee) => {
                return interaction.followUp({  embeds:[new EmbedBuilder()
                .setColor(Color)
                .setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
                });
              })
            } else {
              await interaction.guild.members.ban(target.id,{
                reason: reason ? `Banned by ${interaction.user.tag}`: reason,
                days: duration || null,
             //   deleteMessageDays: 7,
           }).catch((ee) => {
            return interaction.followUp({  embeds:[new EmbedBuilder()
            .setColor(Color)
            .setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
            });
          })
            }
      button.message.edit(`${target}: :eagle:`)
        }
        if (button.customId && button.customId === "no-ban") {
          button.deferUpdate();
          return button.message.delete();
        }
        
      })
    
    } else { 
      let emb = new MessageEmbed()
      .setColor(`${Color}`)
                
          .setDescription(`${target} you have been **banned** from ${interaction.guild.name} for ${reason}`)
     
      const row = new MessageActionRow()
           .addComponents(
             new MessageButton()
       .setURL('https://discord.gg/WJhUSDw4pM')
               .setLabel('Support')
               .setStyle(ButtonStyle.Link), new MessageButton()
                  .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
               .setLabel('Invite')
               .setStyle(ButtonStyle.Link))
     memberfound.user.send({ embeds: [emb], components: [row] })
     interaction.followUp(`${target}: :eagle:`)
     if(delete_messages === true) {
      await interaction.guild.members.ban(target.id,{
      reason: reason ? `Banned by ${interaction.user.tag}`: reason,
      days: duration || null,
      deleteMessageSeconds: 604799,
 }).catch((ee) => {
  return interaction.followUp({  embeds:[new EmbedBuilder()
  .setColor(Color)
  .setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
  });
})
} else {
await interaction.guild.members.ban(target.id,{
  reason: reason ? `Banned by ${interaction.user.tag}`: reason,
  days: duration || null,
//   deleteMessageDays: 7,
}).catch((ee) => {
return interaction.followUp({  embeds:[new EmbedBuilder()
.setColor(Color)
.setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
});
})
}
    }
  }
} else { 
      
  

  interaction.followUp(`${target}: :eagle:`)
  if(delete_messages === true) {
    await interaction.guild.members.ban(target.id,{
    reason: reason ? `Banned by ${interaction.user.tag}`: reason,
    days: duration || null,
    deleteMessageSeconds: 604799,
}).catch((ee) => {
return interaction.followUp({  embeds:[new EmbedBuilder()
.setColor(Color)
.setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
});
})
} else {
await interaction.guild.members.ban(target.id,{
reason: reason ? `Banned by ${interaction.user.tag}`: reason,
days: duration || null,
//   deleteMessageDays: 7,
}).catch((ee) => {
return interaction.followUp({  embeds:[new EmbedBuilder()
.setColor(Color)
.setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
});
})
}
 let embed = new MessageEmbed()
.setColor(`${Color}`)
     .setDescription(`I have warned ${user} for ${reason}`)
 
       let emb = new MessageEmbed()
 .setColor(`${Color}`)
           
     .setDescription(`${target} you have been **banned** from ${interaction.guild.name} for ${reason}`)

 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL('https://discord.gg/WJhUSDw4pM')
					.setLabel('Support')
					.setStyle(ButtonStyle.Link), new MessageButton()
           	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite')
					.setStyle(ButtonStyle.Link))
target.send({ embeds: [emb], components: [row] })

    return interaction.followUp(`${target}: :eagle:`)
      }
    } else if (interaction.options.getSubcommand() === "soft") {

      let reason = await interaction.options.getString("reason");
      if (!reason) reason = "Unspecified"
      const target = await interaction.options.getMember('member');
             let user = target;
      if(target.id === interaction.member.id) {
          return interaction.reply(`-_-`)
      }
      if (target.id === interaction.guild.ownerId) {
       return interaction.reply("-_-")      }
        
            if (target.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply("-_- You cant ban them they have higher power.");
            }
                     
            let softBanEmbed = new MessageEmbed()
               .setDescription(`**Soft Banned**: ${target.user}\n> **Reason**: ${reason}`)
    .setColor(Color)
    .setThumbnail(target.user.displayAvatarURL({dynamic: true}));
 let embed = new Discord.MessageEmbed()
.setColor(`${Color}`)
     .setDescription(`I have warned ${user} for ${reason}`)
      .setTimestamp();
       let emb = new MessageEmbed()
 .setColor(`${Color}`)
           
     .setDescription(`${target} you have been **banned** from ${interaction.guild.name} for ${reason}`)
.setTimestamp();
 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL('https://discord.gg/mpZercYcz5')
					.setLabel('Support')
				.setStyle(ButtonStyle.Link), new MessageButton()
           	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite')
					.setStyle(ButtonStyle.Link))
target.send({ embeds: [emb], components: [row] })

            
            target
            .ban({
              days: 1,
         reason: reason ? `Banned by ${interaction.user.tag}`: reason
            })
            
              message.channel.send({ embeds: [softBanEmbed] })
        } else if (interaction.options.getSubcommand() === "hack") {
            let reason = await interaction.options.getString("reason");
            if (!reason) reason = "Unspecified"
            const target = await interaction.options.getString('id');
 let user = target;
            let targetUser = await client.users.fetch(target)

            if (!targetUser) {
                return interaction.reply('Invalid user ID?')
            }
            
            if(target === interaction.member.id) {
      return interaction.reply("-_-")  

            }
            if (target === interaction.guild.ownerId) {
            return interaction.reply("-_-")  
            }
            let targetMember = await targetUser.member
            let hackBanEmbed = new MessageEmbed()

        .setDescription(`**Hack Banned**: ${target.user}\n> **Reason**: ${reason}`)
    .setColor(Color)
    .setThumbnail(target.user.displayAvatarURL({dynamic: true}));
 let embed = new MessageEmbed()
.setColor(`${Color}`)
     .setDescription(`I have warned ${user} for ${reason}`)
      .setTimestamp();
       let emb = new MessageEmbed()
 .setColor(`${Color}`)
             .setDescription(`${target} you have been **banned** from ${interaction.guild.name} for ${reason}`)
.setTimestamp();
 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL('https://discord.gg/mpZercYcz5')
					.setLabel('Support')
					.setStyle(ButtonStyle.Link), new MessageButton()
           	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite')
					.setStyle(ButtonStyle.Link))
target.send({ embeds: [emb], components: [row] })

if(delete_messages === true) {
  await interaction.guild.members.ban(target.id,{
  reason: reason ? `Banned by ${interaction.user.tag}`: reason,
  days: duration || null,
  deleteMessageSeconds: 604799,
}).catch((ee) => {
return interaction.followUp({  embeds:[new EmbedBuilder()
.setColor(Color)
.setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
});
})
} else {
await interaction.guild.members.ban(target.id,{
reason: reason ? `Banned by ${interaction.user.tag}`: reason,
days: duration || null,
//   deleteMessageDays: 7,
}).catch((ee) => {
return interaction.followUp({  embeds:[new EmbedBuilder()
.setColor(Color)
.setDescription(`${emoji.error} There was a error while trying to ban the user.\n${ee}`)],
});
})
}
            
              return interaction.reply({ embeds: [hackBanEmbed] })
        } else if (interaction.options.getSubcommand() === "remove") {
            let reason = await interaction.options.getString("reason");
            if (!reason) reason = "Unspecified"
            const target = await interaction.options.getUser('id');

            let targetUser = target;

            if (!targetUser) {
                return interaction.reply('Couldn\'t find the user!')
            }
            
            if(target === interaction.member.id) {
                 return interaction.reply("-_-") 
            }
            if (target === interaction.guild.ownerId) {
              return interaction.reply("-_-")             }
            let targetMember = await targetUser.member
            let unBanEmbed = new MessageEmbed()
         

       
    .setDescription(`${emoji.success} ${target.username || target.user.username} has beeen unbanned\n**Reason**: ${reason || 'n/a'}`)
    .setColor(Color)
    .setThumbnail(target?.displayAvatarURL({dynamic: true}));
            await interaction.guild.members.ban(target, {
                  reason: reason ? `Banned by ${interaction.user.tag}`: reason
            })
            
            
            await interaction.guild.members.unban(target,{
                 reason: reason ? `Banned by ${interaction.user.tag}`: reason
            })
            
              return interaction.followUp({ embeds: [unBanEmbed] }) 
        } else if (interaction.options.getSubcommand() === "list") {
          const success = [], failed = [];
          const delay = (ms) => new Promise(r => setTimeout(() => r(2), ms));
          const bans = await interaction.guild.bans.fetch().catch(console.error);
          const valids = bans.map(b => b.user.id).filter(Boolean);
    let array = [];
    let count = 0;
          for await(const ban of valids) {
          let user = await client.users.fetch(ban);
          if(!user) return;
          count++;
          let member = user;
          console.log(user);
          array.push(`\`${count}\`. ${member} • (${member.tag})`);

           await delay(60); 
         }
          interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor(Color)
        .setDescription(`<a:DiscordLoading:1128199694183567361> Finding all banned user(s) **eta**: \`${valids.length * 100 / 1000}\` seconds`)]})
          
        if (array.length === 0) {
          return interaction.followUp({ content: `${emoji.error} No banned members found.`})
        }
      
        // Paginate the boosters using buttons
       
      
      const interval = 10;
      
      
       
      const range = (array.length == 1) ? '[1]' : `[1 - ${array.length}]`;
      let guilds = array;
        const generateEmbed = async start => {
      const current = array.slice(start, start + 10)
      
      // You can of course customise this embed however you want
      return new EmbedBuilder({
      author: { 
       name: `${interaction.user.username}`,
      iconURL: interaction.user?.displayAvatarURL({}),
      },
      thumbnail: {
         url: interaction.guild?.iconURL({ size: 4096, dyanmic: true}),
      
      },
      title: `Banned members in ${interaction.guild.name}`,
      description: `${current.join(`\n`)}`,
      footer: `${array.length || 0} users banned.`,
      color: 0x2c2d31,
      })
        };
      
      // Send the embed with the first 10 guilds
      const canFitOnOnePage = guilds.length <= 10
      const embedMessage = await interaction.editReply({
      embeds: [await generateEmbed(0)],
      components: canFitOnOnePage
      ? []
      : [new MessageActionRow({components: [forwardButton]})]
      })
      // Exit if there is only one page of guilds (no need for all of this)
      if (canFitOnOnePage) return;
      
      // Collect button interactions (when a user clicks a button),
      // but only when the button as clicked by the original message author
      const collector = embedMessage.createMessageComponentCollector({
      filter: ({user}) => user.id === interaction.user.id
      })
      
      let currentIndex = 0
      collector.on('collect', async interaction => {
      // Increase/decrease index
      interaction.customId === backId ? (currentIndex -= 10) : (currentIndex += 10)
      // Respond to interaction by updating message with new embed
      await interaction.update({
      embeds: [await generateEmbed(currentIndex)],
      components: [
        new MessageActionRow({
          components: [
            // back button if it isn't the start
            ...(currentIndex ? [backButton] : []),
            // forward button if it isn't the end
            ...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
          ]
        })
      ]
      })
      
         })
                
        
        }
    }
}