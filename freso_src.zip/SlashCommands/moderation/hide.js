const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const Discord = module.require("discord.js");
const emoji  = require("../../emoji.json");
const { Color } = require("../../config.json");
module.exports = {
  name: "hide",
type: ApplicationCommandType.ChatInput,
  description: "Hides a Channel",
    category: "Moderation",
  userPerms: ["MANAGE_CHANNELS"],
  botPerms: ["EMBED_LINKS", "MANAGE_CHANNELS"],
    options: [
                {
                    name: 'channel',
                    
                    description: 'Channel to hide',
                       type: ApplicationCommandOptionType.Channel,
                }
            ],
        
  run: async (client, interaction, args) => {
    let message = interaction;
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels))
    return interaction.reply({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`ManageChannels\` permission`,
    timestamp: new Date(),
    },
    ],
    })

    let channel =  interaction.options.getChannel('channel') || interaction.channel;
          
     if (!channel || channel.type === "voice")
      return interaction.reply({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `I need a valid text channel`,
          timestamp: new Date(),
        },
      ],
          })
            const embed1 = new MessageEmbed()
   
      .setDescription(`${emoji.success} ${channel} is now visble`)
       .setColor(`${Color}`)
                    .setTimestamp();
  
 channel.permissionOverwrites.edit(message.guild.id, {ViewChannel: false })
    const embed = new MessageEmbed()
   
      .setDescription(`${emoji.success} ${channel} has been hid`)
.setColor(`${Color}`) 
             .setTimestamp();
    await interaction.reply({ embeds: [embed] });
 
  },
};