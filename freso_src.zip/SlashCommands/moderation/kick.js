
const moment = require('moment')
const emoji  = require("../../emoji.json");
const { Color } = require("../../config.json");
const db = require("quick.db")
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const warnings = require("../../database/guildData/warnings")
type: ApplicationCommandType.ChatInput,
module.exports = {
name: "kick",
    category: "Moderation",
description: "kick a user",
cooldown: 5,
userPerms: ["KICK_MEMBERS"],
clientPerms: ["KICK_MEMBERS"],  
 options: [
                {
                    name: 'user',
                      required: true,
                    description: 'Who are you kicking a ghost?',
                      type: ApplicationCommandOptionType.User,
                },
                 {
                    name: 'reason',
                    description: 'Whats the reason for this kick?',
                    type: ApplicationCommandOptionType.String,
                }
            ],
        
  run: async (client, interaction, args) => {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers))
    return interaction.reply({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`ManageChannels\` permission`,
    timestamp: new Date(),
    },
    ],
    })
          
  let message = interaction;
   const mentionedMember = interaction.options.getMember('user');
          
 const reason = interaction.options.getString('reason') || "NO reason provided"

        if (!mentionedMember) return interaction.reply({ components: [row],
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},
          description: `:x: I can't fetch that user there must be some sort of a mistake?`,
          timestamp: new Date(),
        },
      ],
          })
  
            
        if (mentionedMember.id === message.user.id) return interaction.reply({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},
          description: `-__-`,
          timestamp: new Date(),
        },
      ],
          })
  
          

    if (!message.guild.owner) message.guild.members.fetch(message.guild.ownerID).catch(() => null);
    const guild = interaction.guild;  
        if (mentionedMember.roles.highest.position >= message.member.roles.highest.position && !message.user.id === `${message.guild.ownerId}` )  {
            return interaction.reply({ 
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
            },
          description: `${emoji.error} It is not possible for you to kick this member due to your role not being higher `,
          timestamp: new Date(),
        },
      ],
          })
  
            }
         
        
        if (mentionedMember.kickable) {
            const embed = new MessageEmbed()
          
            .setThumbnail(mentionedMember.user.displayAvatarURL({dynamic: true}))
          .setColor(`${Color}`)
.setTitle(`Member Kicked`)
            .setDescription(`
 **Member:** ${mentionedMember.user.username} - (${mentionedMember.user.id})
 **Reason:** ${reason || "None"}
            `)
      interaction.reply({ 
          embeds: [embed] })      
          let emb = new MessageEmbed()
.setColor(`${Color}`)
 .setTitle(`Important Notice`)
     .setThumbnail(mentionedMember.user.displayAvatarURL({dynamic: true}))
                 .setDescription(`You have been \`KICKED\` from **${interaction.guild.name}** for: 
     \`${reason}\``)
.setTimestamp();
 mentionedMember.send({ embeds: [emb],  })
      
        mentionedMember.kick(`Action by ${interaction.user.tag}`)
        } else {
            return interaction.reply({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},
          description: `:${emoji.error} Can not kick this user.`,
          timestamp: new Date(),
        },
      ],
          })
  
            }
        
   new warnings({
     action: `KICK`,
userId:  mentionedMember.id,
guildId:  interaction.guild.id,
moderatorId:  interaction.user.id,
reason: `${reason}`,
timestamp: new Date(),




 }).save();  
 let kickMember = mentionedMember;
            const embed = new MessageEmbed()
        
                .setColor("#ff0000")
                .setThumbnail(kickMember.user.displayAvatarURL({ dynamic: true }))
               
                               .setTimestamp();
 let channel = await db.get(`modlog_${message.guild.id}`)
            if (!channel) return;

            var sChannel = message.guild.channels.cache.get(channel)
            if (!sChannel) return;
            sChannel.send({
              embeds: [embed]
            })
        }
    }