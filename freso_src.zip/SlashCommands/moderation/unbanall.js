const fetch = require("node-fetch");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const emoji = require("../../emoji.json") 
const { Color } = require("../../config.json");

module.exports = { 
 name: 'unban-all',
category: "Moderation",
type: ApplicationCommandType.ChatInput,
  description: 'Unban all current banned users in this server.',
  run: async (client, interaction) => {
    let message = interaction;
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
    return message.reply({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`Administrator\` permission`,
    timestamp: new Date(),
    },
    ],
    })
          

  await interaction.deferReply()

 const delay = (ms) => new Promise(r => setTimeout(() => r(2), ms));

  const success = [], failed = [];

  const bans = await message.guild.bans.fetch().catch(console.error);
  const valids = bans.map(b => b.user.id).filter(Boolean);
  // status update
  message.editReply({ embeds: [new MessageEmbed()
.setColor(Color)
.setDescription(`**Bans**: \`${bans.size}\`
**Duration**: \`${valids.length * 200 / 1000}\` seconds. `)]})
  
  
  for(const ban of valids) {
     await message.guild.members.unban(ban)
      .then(() => success.push(ban))
      .catch(() => failed.push(ban))
     await delay(150); // wait 150ms due to ratelimits
  }
  // status update

      message.editReply({ embeds: [new MessageEmbed()
.setColor(Color)
.setDescription(`${emoji.success} Unbanned \`${success.length}\` / \`${valids.length}\` members, and I failed unbanning: \`${failed.length} members\``)]})

  }
  }
