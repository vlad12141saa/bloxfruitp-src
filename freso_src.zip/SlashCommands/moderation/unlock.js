const Discord = module.require("discord.js");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const { Color } = require("../../config.json");
module.exports = {
  name: "unlock",
  description: "Unlocks a Channel",
type: ApplicationCommandType.ChatInput,
category: "Moderation",
  userPerms: ["MANAGE_CHANNELS"],
  botPerms: ["EMBED_LINKS", "MANAGE_CHANNELS"],
    options: [
                {
                    name: 'channel',
                    description: 'Channel to unlock',
                 type: ApplicationCommandOptionType.Channel,
                }
            ],
        
  run: async (client, interaction, args) => {
    let message = interaction;
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels))
    return message.reply({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`Manage_Channels\` permission`,
    timestamp: new Date(),
    },
    ],
    })
          

    let channel =  interaction.options.getChannel('channel') || interaction.channel;
          
     if (!channel || channel.type === "voice")
      return interaction.reply({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `I need a valid text channel`,
          timestamp: new Date(),
        },
      ],
          })
            const embed1 = new MessageEmbed()
   
      .setDescription(`${channel} has been unlocked`)
     .setColor(`${Color}`)
                      .setTimestamp();

interaction.reply({
  embeds: [embed1]
}) 
 return channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: null})
  },
};