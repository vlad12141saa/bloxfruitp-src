const Discord = module.require("discord.js");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const { version: discordjsVersion } = require('discord.js');
const warnings = require("../../database/guildData/warnings")
const emoji = require(`../../emoji.json`);
const { Color } = require("../../config.json");
module.exports = {
  name: "warn",
  description: "warn a member.",
type: ApplicationCommandType.ChatInput,
  options: [
      {
          name: "add",
          description: "Warn a user",
        type: ApplicationCommandOptionType.Subcommand,
          options: [
        {
            name: 'target',
            description: 'The user you want to warn',
         required: true,
             type: ApplicationCommandOptionType.User,
          
        },
        {
            name: 'reason',
            description: 'Reason for the warn',
            required: true,
           type: ApplicationCommandOptionType.String,
          
            
        },
      ],
      },
      {
        name: "remove",
        description: "Remove a warn from a user",
      type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "storageid",
            required: true,
            description: "The storageId I should delete",
             type: ApplicationCommandOptionType.String,
        }
    ],
    },
    {
      name: "list",
      description: "Warn a user",
    type: ApplicationCommandOptionType.Subcommand,
      options: [
    {
        name: 'target',
        description: 'The user you want to warn',
     required: true,
         type: ApplicationCommandOptionType.User,
      
    },
  ],
  },

    ],
  run: async (client, interaction, ) => {
    await interaction.deferReply({});
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) 
                return interaction.followUp({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `You're missing the \`MANAGE_MESSAGES\` permission`,
          timestamp: new Date(),
        },
      ],
          })
          if (interaction.options.getSubcommand() === "add") {
     const user = interaction.options.getMember('target');
          if(user.user.bot || user.bot) {
             
 let embed = new Discord.EmbedBuilder()
 .setColor(`${Color}`)
 
      .setDescription(`${emoji.error} you can not warn a **discord bot** :skull:  `)
      .setAuthor({ name: `${user.user.tag}`, iconURL: user.user?.displayAvatarURL()})
      .addFields(
       { name: `/warn list`, value: `view all warn history on a user` },
       { name: `/warn remove`, value: `removes a warn from a user` },
     )
     return interaction.followUp({ embeds: [embed]})
          }
 const reason = interaction.options.getString('reason') || 'n/a';

 
 let embed = new Discord.EmbedBuilder()
.setColor(`${Color}`)

     .setDescription(`${emoji.success} successfully ${user}\n**Reason**: ${reason}`)
     .setAuthor({ name: `${user.user.tag}`, iconURL: user.user?.displayAvatarURL()})
     .addFields(
      { name: `/warn list`, value: `view all warn history on a user` },
      { name: `/warn remove`, value: `removes a warn from a user` },
    )
       let emb = new Discord.EmbedBuilder()
 .setColor(`${Color}`)
      
     .setDescription(`${user} you have been warned in ${interaction.guild.name} by **${interaction.member.user.tag}** for ${reason}`)

 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL(emoji.link)
					.setLabel('Support')
					.setStyle(ButtonStyle.Link), new MessageButton()
           	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite')
					.setStyle(ButtonStyle.Link))
user.send({ embeds: [emb], components: [row] });

      interaction.followUp({   embeds: [embed] })
      new warnings({
   action: `Warn Action`,
userId:  user.id,
guildId:  interaction.guild.id,
moderatorId:  interaction.user.id,
reason,
timestamp: `<t:${parseInt(interaction.createdAt / 1000 )}:F>`,

// msg.channel.send(``<t:${parseInt(message.timestamp / 1000 )}:F>``)


 }).save();

            }
            if (interaction.options.getSubcommand() === "remove") {
              const warnid = interaction.options.getString('storageid');
              let embed = new MessageEmbed()
           .setColor(`${Color}`)
                .setDescription(`${emoji.error} ${warnid} is not a valid storageId`)
                 .setTimestamp();
                  
              
                const data = await warnings.findById(warnid)
                 
                if (!data) return interaction.followUp({
                  embeds: [embed],
                //  components: [row] 
                })
                data.delete()
                const user = interaction.guild.members.cache.get(data.userId)
                 let emb = new MessageEmbed()
           .setColor(`${Color}`)
           .setAuthor({ name: `${user.user.tag}`, iconURL: user.user?.displayAvatarURL()})
           .addFields(
            { name: `/warn add`, value: `add a warn to a user` },
            { name: `/warn list`, value: `view all warnings on a user` },
          )
                .setDescription(`${emoji.success} removed ${warnid} out of ${user} warning records.`)
                
              interaction.followUp({
                 embeds: [emb],
               //  components: [row] 
                })
            }
            if (interaction.options.getSubcommand() === "list") {
              const user = interaction.options.getMember('target');
   const userWarnings = await warnings.find({
userId:  user.id,
guildId:  interaction.guild.id,
 });
 let embed = new Discord.EmbedBuilder()
.setColor(`${Color}`)
 
         
     .setDescription(`${emoji.error} No data was found on **${user.user.username}**.`)
  

 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL('https://discord.gg/WJhUSDw4pM')
					.setLabel('Support')
					.setStyle(ButtonStyle.Link),
           new MessageButton()
	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite Me')
					.setStyle(ButtonStyle.Link))

 if (!userWarnings?.length)
  return interaction.followUp({
    embeds: [embed],
    components: [row]
      });
  
   const embedd = userWarnings.map((warn) => {
const mod = interaction.guild.members.cache.get(warn.moderatorId) 

 

 return [
`\`Action\`: ${warn.action || 'Cant fetch'}`,
`\`storageId\`: ${warn._id}`,
`\`Moderator\`: ${mod || 'Left Server'}`,
`\`Date\`: 	${warn.timestamp}`,
`\`Reason\`: ${warn.reason}`



 ].join("\n");
  }
  ).join("\n\n");
  let embed1 = new Discord.EmbedBuilder()
.setColor(`${Color}`)
.setAuthor({ name: `${user.user.tag}`, iconURL: user.user?.displayAvatarURL()})
.addFields(
  { name: `/warn add`, value: `add a warn to a user` },
  { name: `/warn remove`, value: `remove a warn from a user` },
)
             .setFooter({ text: `User ID | ${user.id}`, })
     .setDescription(`${embedd}`)
interaction.followUp({ embeds: [embed1] })
            }
  }
  
}
