const Discord = module.require("discord.js");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const { version: discordjsVersion } = require('discord.js');

const { Color } = require("../../config.json");
const warnings = require("../../database/guildData/warnings")
module.exports = {
  name: "history",
  category: "Moderation",
type: ApplicationCommandType.ChatInput,
  description: "Display a user's history/warnings",
  options: [
      {
          name: "target",
          required: true,
          description: "The user history you want to view",
           type: ApplicationCommandOptionType.User,
      }
  ],
  run: async (client, interaction, args) => {
    const moment = require('moment');
  
 const user = interaction.options.getMember('target');
   const userWarnings = await warnings.find({
userId:  user.id,
guildId:  interaction.guild.id,
 });
 let embed = new Discord.EmbedBuilder()
.setColor(`${Color}`)
 
         
     .setDescription(`No history was found on that user `)
      .setTimestamp();
  

 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL('https://discord.gg/WJhUSDw4pM')
					.setLabel('Support')
					.setStyle(ButtonStyle.Link),
           new MessageButton()
	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite Me')
					.setStyle(ButtonStyle.Link))

 if (!userWarnings?.length)
  return interaction.reply({
    embeds: [embed],
    components: [row]
      });
  
   const embedd = userWarnings.map((warn) => {
const mod = interaction.guild.members.cache.get(warn.moderatorId) 

 

 return [
`\`Action\`: ${warn.action || 'Cant fetch'}`,
`\`caseID\`: ${warn._id}`,
`\`Moderator\`: ${mod || 'Left Server'}`,
`\`Date\`: 	${warn.timestamp}`,
`\`Reason\`: ${warn.reason}`



 ].join("\n");
  }
  ).join("\n\n");
  let embed1 = new Discord.EmbedBuilder()
.setColor(`${Color}`)
 
             .setFooter({ text: `User ID | ${user.id}`, })
     .setDescription(`${embedd}`)
      .setTimestamp();
interaction.reply({ embeds: [embed1] })
    
  },

};