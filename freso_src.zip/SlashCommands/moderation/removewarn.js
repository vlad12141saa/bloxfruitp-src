const Discord = module.require("discord.js");

const { Color } = require("../../config.json");
const db = require("quick.db")
const warnings = require("../../database/guildData/warnings")
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
const emoji  = require("../../emoji.json");
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
module.exports = {
  name: "remove-history",
      category: "Moderation",
type: ApplicationCommandType.ChatInput,
  description: "Remove a history using a ID",
  options: [
      {
          name: "warnid",
          required: true,
          description: "The warnid I should delete",
           type: ApplicationCommandOptionType.String,
      }
  ],
  run: async (client, interaction, args) => {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages))
    return interaction.reply({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`ManageMessages\` permission`,
    timestamp: new Date(),
    },
    ],
    })
    const warnid = interaction.options.getString('warnid');
   let embed = new MessageEmbed()
.setColor(`${Color}`)
     .setDescription(`:x: ${warnid} is not a valid caseid`)
      .setTimestamp();
       
   
     const data = await warnings.findById(warnid)
      
     if (!data) return interaction.reply({
       embeds: [embed],
       components: [row] 
     })
     data.delete()
     const user = interaction.guild.members.cache.get(data.userId)
      let emb = new MessageEmbed()
.setColor(`${Color}`)
     .setDescription(`<:tick_yes:888176874449170503> I removed ${warnid} out of ${user} history`)
      .setTimestamp();
   interaction.reply({
      embeds: [emb],
      components: [row] 
     })
     let kickMember = user;
            const embedb = new MessageEmbed()
                
                .setColor("#ff0000")
                .setThumbnail(kickMember.user.displayAvatarURL({ dynamic: true }))
               
                           .setTimestamp();
 let channel = db.fetch(`modlog_${interaction.guild.id}`)
            if (!channel) return;

            var sChannel = interaction.guild.channels.cache.get(channel)
            if (!sChannel) return;
            sChannel.send({
              embeds: [embedb]
              })

  },
};