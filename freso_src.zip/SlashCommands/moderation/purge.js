
const moment = require('moment')
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const autopfp = require("../../database/guildData/autopfp")
module.exports = {
    name: "purge",
    description: "Purge messages from this channel.",
type: ApplicationCommandType.ChatInput,

    category: "Moderation",
    userPerms: ["BAN_MEMBERS"],
    botPerms: ["BAN_MEMBERS", "EMBED_LINKS"],
    options: [
        {
            name: "user",
            description: "Purges message from user.",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "amount",
                    description: "amount?",
                   type: ApplicationCommandOptionType.Integer,   
                 required: true
                },
                {
                    name: "user",
                    description: "user?",
                   type: ApplicationCommandOptionType.User,   
                 required: true
                },
                          ]
        },
              
        {
            name: "any",
            description: "Purges message in a channel.",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
          {
            name: "amount",
            description: "amount?",
           type: ApplicationCommandOptionType.Integer,   
         required: false,
        },
    ],
        },
    ],
    run: async(client, interaction, args) => {
        try {
        await interaction.deferReply({ ephemeral: true })
const emed1 = new MessageEmbed()
   
.setDescription(`${emoji.error} You're missing the **ManageMessages** permission.`)
   .setColor(`${Color}`)
.setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })

if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages))
return    interaction.followUp({
ephemeral: true, embeds:[emed1]
})
if (interaction.options.getSubcommand() === "any") { 
    const amount = await interaction.options.getInteger('amount') || 99;
    let int = amount;
    const messages = await interaction.channel.messages.fetch({ limit: amount });
    const deletedMessages = messages.size;
    const successEmbed = new EmbedBuilder()
    .setDescription(`${emoji.success} Purged a total of **${amount}** messages`)
    .setColor(`${Color}`)
    await interaction.channel.bulkDelete(int);
    await interaction.editReply({ embeds: [successEmbed], ephemeral: true });
}
if (interaction.options.getSubcommand() === "user") { 
    
    const purgeUser = await interaction.options.getUser('user');
    const int = await interaction.options.getInteger('amount');
   
   let amount = int;
    if (purgeUser) {
        
        const messages = await interaction.channel.messages.fetch({ limit: int });
        
        const userMessages = await messages.filter(msg => msg.author.id === purgeUser.id);
        const deletedMessages = userMessages.size;
       
       
        const embed = new EmbedBuilder()
        .setColor(`${Color}`)
        .setDescription(`${emoji.success} Purged a total of **${amount}** messages from <@${purgeUser.id}>`)

        await await interaction.channel.messages.fetch({ limit: int }).then((messages) => { 
            let userMsgs = [];
             messages.filter(m => m.author.id === purgeUser.id).forEach(msg => userMsgs.push(msg))
             interaction.channel.bulkDelete(userMsgs);
          
             interaction.editReply({ embeds: [embed], ephemeral: true });
      });
    }else {
    
    await interaction.editReply({ content: `${emoji.error} tf, something happened`, ephemeral: true });}
}
} catch(err) {
    return await interaction.editReply('An error occured, try again or decrease the number of messages you want to delete.' + err)
}
    
},
};