
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
const emoji  = require("../../emoji.json");
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const { QuickDB } = require("quick.db");
const db = new QuickDB();
module.exports = {
    name: 'prune',
type: ApplicationCommandType.ChatInput,
    description: "Prune members from the server.",
    options: [
        {
            name: 'role',
            description: 'The members role to prune from.',
    type: ApplicationCommandOptionType.Subcommand,
          options: [
  {
    name: "role",
    description: "Role.",
    type: ApplicationCommandOptionType.Role,
    required: true
  }
],
        },
          {
            name: 'members',
          description: 'Prune members (THIS CANT BE UNDONE)',
               type: ApplicationCommandOptionType.Subcommand,

            options: [
  {
    name: "days",
    description: "Amount of inactivity of days to prune from.",
     type: ApplicationCommandOptionType.Number,

    required: true
  }
],
    
            },
   
    ],
sm: true,
    run: async(client, interaction, args) => {
      let message = interaction;
let guild = interaction.guild;
await interaction.deferReply()
        if (interaction.options.getSubcommand() === "role") {
       
     
          if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
          return interaction.followUp({ ephemeral: true,
          embeds: [
          {
          color: 0x6787e7,
          author: {
          name: `${interaction.user.tag}`,
          icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
          
          },
          // footer: { icon_url: client.user.displayAvatarURL() },
          footer: {
          text: `${client.user.username}`,
          icon_url: `${client.user.displayAvatarURL()}`,
          },
          
          description: `You're missing the \`Administrator\` permission`,
          timestamp: new Date(),
          },
          ],
          })


       await   db.set(`prunerole${message.guild.id}`, interaction.options.getRole(`role`).id)
interaction.followUp({
content: `${emoji.success} Successfully set the prune role.`,
});
        }
         

        if (interaction.options.getSubcommand() === "members") {
       
            if (!interaction.member.permissions.has("ADMINISTRATOR"))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: Color,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `${emoji.error} You're missing the \`ADMINISTRATOR\` permission`,
              timestamp: new Date(),
            },
          ],
        })
let day = interaction.options.getNumber(`days`)
          let role = await db.get(`prunerole${message.guild.id}`)
          if(role) {
            guild.members.prune({ dry: true, days: day, roles: [`${role}`] }).then(p => {
                   const e = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                    .setLabel('Yes')
                      .setStyle(ButtonStyle.Primary)
                    .setCustomId('backup-yes-create')
                )
                .addComponents(
                    new MessageButton()
                    .setLabel('No')
                      .setStyle(ButtonStyle.Danger)
                    .setCustomId('backup-no-create')
                );
              let name = message.guild.roles.cache.get(`${role}`).name;
              if(!name) return interaction.followUp(`${emoji.error} Prune roie found was deleted.`)
              interaction.followUp({ fetchReply: true, embeds: [new MessageEmbed()
.setColor(Color)

.setDescription(`Are you sure you would like to **prune** ${p} members using the prune role: **${name}**?`)],components: [e]})
                  const collector = interaction.channel.createMessageComponentCollector({
                time: 25000,
             
            })

            collector.on("collect", async (i) => {
if (i.customId === "backup-no-create") {
  return interaction.editReply({ components: []})
}
                if (i.customId === "backup-yes-create") {

                    if (i.user.id !== interaction.user.id) return i.reply({
                        content: "Not 4 u ",
                        ephemeral: true
                    })

                    i.deferUpdate()
                    const ConfirmEmbed1 = new MessageEmbed()
                        .setDescription(`Pruning ${p} members.`)
                  .setColor(`#2f3136`)
                       

                    const row1 = new MessageActionRow()
                        .addComponents(
                            new MessageButton()
                            .setLabel('Yes')
                              .setStyle(ButtonStyle.Primary)
                            .setCustomId('backup-yes-create')
                            .setDisabled(true)
                        )
                        .addComponents(
                            new MessageButton()
                            .setLabel('No')
                            .setStyle(ButtonStyle.Danger)               
             .setCustomId('backup-no-create')
                            .setDisabled(true)
                        );
                    interaction.editReply({
                        embeds: [ConfirmEmbed1],
                        components: [row1]
                    })
           
                     guild.members.prune({ days: day, roles: [`${role}`], reason: `Prune Action by ${interaction.user.tag}` }).then(x => {
     const e = new MessageEmbed()
                        .setDescription(`${emoji.success} **Pruned**: ${p} members.`)
                  .setColor(Color)
                       

                       interaction.editReply({ embeds: [e] })
                     })

                }
            })
            })
          }
if(!role) { 
          guild.members.prune({ dry: true, days: day,  }).then(p => {
                   const e = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                    .setLabel('Yes')
               .setStyle(ButtonStyle.Primary)
                    .setCustomId('backup-yes-create')
                )
                .addComponents(
                    new MessageButton()
                    .setLabel('No')
                     .setStyle(ButtonStyle.Danger)
                    .setCustomId('backup-no-create')
                );
              interaction.followUp({ fetchReply: true, embeds: [new MessageEmbed()

                 .setColor(Color)
.setDescription(`Are you sure you would like to **prune** ${p} members?`)], components: [e]})
                  const collector = interaction.channel.createMessageComponentCollector({
                time: 15000,
               
            })

            collector.on("collect", async (i) => {
if (i.customId === "backup-no-create") {
  return interaction.editReply({ components: []})
}
                if (i.customId === "backup-yes-create") {

                    if (i.user.id !== interaction.user.id) return i.reply({
                        content: "Not 4 u ",
                        ephemeral: true
                    })

                    i.deferUpdate()
                    const ConfirmEmbed1 = new MessageEmbed()
                        .setDescription(`Pruning ${p} members.`)
                                .setColor(Color)
                       

                    const row1 = new MessageActionRow()
                        .addComponents(
                            new MessageButton()
                            .setLabel('Yes')
                       .setStyle(ButtonStyle.Primary)
                            .setCustomId('backup-yes-create')
                            .setDisabled(true)
                        )
                        .addComponents(
                            new MessageButton()
                            .setLabel('No')
                            .setStyle(ButtonStyle.Danger)
                            .setCustomId('backup-no-create')
                            .setDisabled(true)
                        );
                    interaction.editReply({
                        embeds: [ConfirmEmbed1],
                        components: [row1]
                    })
           
                     guild.members.prune({ days: day, reason: `Prune Action by ${interaction.user.tag}`, }).then(x => {
   const ee = new MessageEmbed()
                        .setDescription(`${emoji.success} Successfully pruned: ${p} members.`)
                                   .setColor(Color)
                       interaction.editReply({ embeds: [ee]})
                     })

                }
            })
            })
}
        }
            
        
        }
      
      
}
