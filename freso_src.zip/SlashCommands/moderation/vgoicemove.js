const { ActionRowBuilder, SelectMenuBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  name: "voicemove",
  description: "Move users from the current vc to another channel.",
  permission: "MOVE_MEMBERS",
  category: "Moderation",
type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: "move-to",
      description: "Select the channel you want to move the members to.",
      type: ApplicationCommandOptionType.Channel,
   

      required: true,
    }
  ],
  run: async (client, interaction, args) => {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels))
    return interaction.reply({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`Manage_Channels\` permission`,
    timestamp: new Date(),
    },
    ],
    });
      const { member, options } = interaction;
    const newChannel = options.getChannel("move-to");
    const voiceChannel = member.voice.channel;

    if(!voiceChannel) return interaction.reply({content: "You need to be in the voice channel to move the members!", ephemeral: true});
    if(newChannel === voiceChannel) return interaction.reply({content: "You can't move members to the same channel they are already in!", ephemeral: true})

    voiceChannel.members.forEach(m => {
      m.voice.setChannel(newChannel, `Voice Moved by ${member.user.tag}`)
    })
    interaction.reply({content: `Moved all users to ${newChannel}.`, ephemeral: true})
  }
}