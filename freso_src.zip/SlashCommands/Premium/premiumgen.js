
const moment = require('moment')
const emoji = require("../../emoji.json") 
const dayjs = require('dayjs')
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const premium = require("../../database/guildData/premium");
const donator = require('../../database/guildData/donator')

module.exports = {
    name: "premium",
    description: "This command is only for the developers",
type: ApplicationCommandType.ChatInput,

    category: "Moderation",
    userPerms: ["BAN_MEMBERS"],
    botPerms: ["BAN_MEMBERS", "EMBED_LINKS"],
    options: [
        {
            name: "config",
description: "Toggle guild subscribtions",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "server-id",
                    description: "server id",
                   type: ApplicationCommandOptionType.String,   
                 required: true
                },
 {
                    name: "plan",
                    description: "Either monthly or lifetime",
                   type: ApplicationCommandOptionType.String,   
                 required: true,
   choices: [
 { name: "montly", value: "monthly" },

     { name: "lifetime", value: "lifetime" },
                            ]     },
 {
                    name: "customer",
                    description: "Customer of the subscribtion",
                   type: ApplicationCommandOptionType.User,   
                 required: true,
 },
                          ]
        },
                
    
        {
            name: "lookup",
description: "Lookup guild subscribtions",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "server-id",
                    description: "server id",
                   type: ApplicationCommandOptionType.String,   
                 required: true
                },

                          ]
        },  
        {
          name: "donator",
description: "Add/Remove a donator",
        type: ApplicationCommandOptionType.Subcommand,
          options: [
              {
                  name: "user",
                  description: "user",
                 type: ApplicationCommandOptionType.User,   
               required: true
              },

                        ]
      },  
       {
            name: "benefits",
description: "Benefits of subscribing to premium",
          type: ApplicationCommandOptionType.Subcommand,
        },  
    ],
    run: async(client, interaction, args) => {
await interaction.deferReply()

if (interaction.options.getSubcommand() === "donator") {
  let user = interaction.options.getUser(`user`);
  const Owner = [`1102905025421918251`, `2`,`101504658015526934`];
  if(!Owner.includes(interaction.user.id)) return interaction.followUp(`-__-`);
  let check = await donator.findOne({ userId: user.id});
  if(!check) {
    new donator({
      userId: user.id,
      Date: `<t:${parseInt(interaction.createdTimestamp / 1000 )}:F>`
    }).save();
    interaction.followUp({ embeds: [new EmbedBuilder()
      .setThumbnail(interaction.user.displayAvatarURL({}))
      .setDescription(`${emoji.success} added **${user.username || user}** to the donator perks.`)
                                        .addFields(
          { name: 'Date Subscribed', value: `<t:${parseInt(interaction.createdTimestamp / 1000 )}:F>` },
        )
                                      .setColor(Color)
      ] });

  } else {
    await donator.findOneAndRemove({
      userId: user.id,
    }).then(() => { 
    interaction.followUp({ embeds: [new EmbedBuilder()
     .setThumbnail(interaction.user.displayAvatarURL({}))
      .setDescription(`${emoji.success} removed **${user.username || user}** from donator perks.`)
                                        .addFields(
          { name: 'Date Subscribed', value: `${check.Date}` },
        )
                                      .setColor(Color)
      ] });
    })
  }
}
          if (interaction.options.getSubcommand() === "lookup") {
            const Owner = [`1102905025421918251`, `2`,`101504658015526934`];
if(!Owner.includes(interaction.user.id)) return interaction.followUp(`-__-`);
let server = interaction.options.getString(`server-id`);
            let premiumDB = await premium.findOne({ GuildID: server});
           if(premiumDB) { 
             let lifetime = false;
if(premiumDB.Lifetime === true) lifetime = true;
interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`<a:DiscordLoading:1128199694183567361> Found data on that server.`)
                                	.addFields(
		{ name: 'GuildID', value: `${server}` },
   { name: 'Premium Subscribed', value: `${premiumDB.Date || 'N/A'}` },
  { name: 'Premium Customer', value: `${premiumDB.Customer || 'N/A'}` },
  { name: 'Premium Lifetime', value: `${lifetime}` },
	)
                                .setColor(Color)
] });

}
if(!premiumDB) { 
  interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`${emoji.error} No data found for that server.`)
                                .setColor(Color)
] });
}
          }
   if (interaction.options.getSubcommand() === "benefits") {
    let message = ` `;
    if(interaction.guild){ 
    

    if(await premium.findOne({ GuildID: interaction.guild.id})) { 
       message = `${emoji.success} This server has **premium**.`
      } else {
       message = `${emoji.error} This server does not have premium.`;
      }
    }
     const row = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
         .setLabel('Support server')
	.setURL('https://discord.gg/WJhUSDw4pM')
	.setStyle(Discord.ButtonStyle.Link))
     interaction.followUp({ components: [row], embeds: [new EmbedBuilder()
                                     .setTitle('Premium Benefits')
.setDescription(`:star: **Premium Perks**

                \`1\`.  Nsfw posting invertal increased to 30 minutes instead of 30 seconds
                \`2\`.  Nsfw posting cooldown removed
                \`3\`.  Access to beta version of **${client.user.username}** with unreleased feaures
                \`4\`.  Hoisted custom role in support server
                \`5\`.  Change rank background in a server
                \`6\`.  Access to use config poj webhook mode
                \`7\`.  Able to add more than one confession channel
                \`8\`.  Get whitelisted to add **freso prime** to one server (Note: All premium features will remain on both bots)
                


               :gem:  **Prices**
                Premium (5$ / lifetime) (2x server boosts allowed)
               
               
               🔖 **Additonal**
                
                ${client.user.username}'s price will change in the future and features will be at a higher cost, so we suggest buying it now for a cheaper price.

                :money_with_wings: - **Where to purchase?**
                Join our support server [**CLICK HERE**](https://discord.gg/WJhUSDw4pM) and create a support ticket!
                
                **Note**: ${message}
               
`)
                                .setColor(Color)
] });
       }
        if (interaction.options.getSubcommand() === "config") {
          const Owner = [`1102905025421918251`, `2`,`101504658015526934`];
if(!Owner.includes(interaction.user.id)) return interaction.followUp(`-__-`);
let server = interaction.options.getString(`server-id`)
            let a = interaction.options.getString("plan");
          let user = interaction.options.getUser("customer");
if(await premium.findOne({ GuildID: server})) { 
let guild = client.guilds.cache.get(server)
interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`${emoji.success} removed that server from premium`)
                                .setColor(Color)
] });
return await premium.findOneAndRemove({ GuildID: server, });
}
if(!await premium.findOne({ GuildID: server})) { 

    if (a === "monthly") {
           const expirationDate = new Date();
      // expirationDate.setMonth(expirationDate.getMonth() + 1);
      expirationDate.setMonth(expirationDate.getMonth() + 1);

      new premium({
   GuildID: server,
        Customer: user.id,
expires: expirationDate,
time: Date.now(),
        Lifetime: false,
Transfered: 1,
  Date: `<t:${parseInt(interaction.createdTimestamp / 1000 )}:F>`
}).save();
  return interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`${emoji.success}  server (**${server}**) is set for the subscription plan **${a}**.`)
                                  .setColor(Color)
] });
    } else if (a === "lifetime") {
      expiresAt = null;
      new premium({
   GuildID: server,
time: Date.now(),
Lifetime: true,
Transfered: 1,

  Date: `<t:${parseInt(interaction.createdTimestamp / 1000 )}:F>`
}).save();
  interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`${emoji.success} server (**${server}**) is set for the subscription plan **${a}**.`)
                                  .setColor(Color)
] });
    }


}
}
    }
}
