
const moment = require('moment')
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const autopfp = require("../../database/guildData/autopfp")
module.exports = {
    name: "autopfp",
    description: "Set a auto pfp channel.",
type: ApplicationCommandType.ChatInput,

    category: "Moderation",
    userPerms: ["BAN_MEMBERS"],
    botPerms: ["BAN_MEMBERS", "EMBED_LINKS"],
    options: [
        {
            name: "toggle",
            description: "Setup auto-pfs from users to be sent",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "channel",
                    description: "the channel",
                   type: ApplicationCommandOptionType.Channel,   
                 required: true
                },
                          ]
        },
              
        
    ],
    run: async(client, interaction, args) => {
await interaction.deferReply();
const emed1 = new MessageEmbed()
   
.setDescription(`${emoji.error} You're missing the **MANAGE_CHANNELS** permission.`)
   .setColor(`${Color}`)
.setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })

if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels))
return    interaction.followUp({
ephemeral: true, embeds:[emed1]
})
        if (interaction.options.getSubcommand() === "toggle") {
            let ch = interaction.options.getChannel("channel");
if(await autopfp.findOne({ GuildID: interaction.guild.id, ChannelID: ch.id})) { 
interaction.followUp({ embeds: [new EmbedBuilder()
.setAuthor({ name: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL({dynamic:true})})
.setDescription(`${interaction.user}: removed the channel: ${ch} from the auto-pfp database..`)
                                .setColor(Color)
] });
return await autopfp.findOneAndRemove({ GuildID: interaction.guild.id, ChannelID: ch.id});
}
if(!await autopfp.findOne({ GuildID: interaction.guild.id, ChannelID: ch.id})) { 
new autopfp({
   GuildID: interaction.guild.id, ChannelID: ch.id
}).save()
  interaction.followUp({ embeds: [new EmbedBuilder()
.setAuthor({ name: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL({dynamic:true})})
.setDescription(`${interaction.user}: ${ch} has auto pfp enabled and toggled for action.`)
                                  .setColor(Color)
] });
}
}
    }
}
