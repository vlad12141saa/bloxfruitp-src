
const moment = require('moment')
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const confessschema = require("../../database/guildData/confess")
var timeoutv = [];
module.exports = {
    name: "confess",
    description: "Share a personal revelation discreetly or establish a mechanism for confessing.",
type: ApplicationCommandType.ChatInput,

    category: "Moderation",
    userPerms: ["BAN_MEMBERS"],
    botPerms: ["BAN_MEMBERS", "EMBED_LINKS"],
    options: [
        {
            name: "send",
            description: "Disclose a particular statement in a private manner. ",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "message",
                    description: "the message to privately confess",
                   type: ApplicationCommandOptionType.String,   
                 required: true
                },
                          ]
        },
        {
            name: "setup",
            description: "Set a channel wehere users can send unidentified confessments. ",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "channel",
                    description: "the channel were confessions should get sent",
                   type: ApplicationCommandOptionType.Channel,   
                 required: true
                },
                          ]
        }, 
        {
            name: "disable",
            description: "Turn off confessions in your server.",
          type: ApplicationCommandOptionType.Subcommand,
       
        }, 
           ],
    run: async(client, interaction, args) => {
await interaction.deferReply({ ephemeral: true, });

const sub = interaction.options.getSubcommand();
const confessdata = await confessschema.findOne({ Guild: interaction.guild.id });

switch (sub) {
    case 'setup':
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))  {
        return await interaction.followUp({ embeds: [new EmbedBuilder()
   
            .setDescription(`${emoji.error} You're missing the **Administrator** permission.`)
               .setColor(`${Color}`)
            .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
    }
    const channel = interaction.options.getChannel('channel');
    const logs =  interaction.options.getChannel('logs') || null;
    const timeout =  60;
    const time = timeout * 1000;

    if (confessdata)  return await interaction.followUp({ embeds: [new EmbedBuilder()
   
            .setDescription(`${emoji.error} The confession system is already enabled.`)
            .addFields(
                { name: `/confess send`, value: `send a private confession` },
                { name: `/confess reply`, value: `reply to a confession message` },
                { name: `/confess disable `, value: `disable the confession system` },
              )
               .setColor(`${Color}`)
            .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
    else {

        if (logs) {

            await confessschema.create({
                Guild: interaction.guild.id,
                Timeout: time,
                Channel: channel.id,
                Logs: logs.id
            })

        } else {

            await confessschema.create({
                Guild: interaction.guild.id,
                Timeout: time,
                Channel: channel.id,
                Logs: null,
            })

        }

        const setupembed = new EmbedBuilder()
        .setDescription(`${emoji.success} The confession system is now enabled.`)
        .addFields(
            { name: `Confession Chnanel `, value: `${channel}` },
            { name: `/confess send`, value: `send a private confession` },
            { name: `/confess reply`, value: `reply to a confession message` },
            { name: `/confess disable `, value: `disable the confession system` },
          )
           .setColor(`${Color}`)
        .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })
        await interaction.followUp({ embeds: [setupembed] });
    }

    break;
    case 'disable':
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))  {
            return await interaction.followUp({ embeds: [new EmbedBuilder()
       
                .setDescription(`${emoji.error} You're missing the **Administrator** permission.`)
                   .setColor(`${Color}`)
                .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
        }
    if (!confessdata)  return await interaction.followUp({ embeds: [new EmbedBuilder()
   
        .setDescription(`${emoji.error} The confession system is not enabled.`)
        .addFields(
            { name: `/confess send`, value: `send a private confession` },
            { name: `/confess reply`, value: `reply to a confession message` },
            { name: `/confess disable `, value: `disable the confession system` },
          )
           .setColor(`${Color}`)
        .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
         else {

        await confessschema.deleteMany({ Guild: interaction.guild.id });

      interaction.followUp({ embeds: [new EmbedBuilder()
        .setColor(`${Color}`)
        .setDescription(`${emoji.success} the confession system on the channel <#${confessdata.Channel}> has been disabled.`)
        .addFields(
            { name: `/confess send`, value: `send a private confession` },
            { name: `/confess reply`, value: `reply to a confession message` },
            { name: `/confess disable `, value: `disable the confession system` },
          )
        .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
        
    }
    break;
    case 'reply':

    if (!confessdata) return await interaction.followUp({ embeds: [new EmbedBuilder()
   
        .setDescription(`${emoji.error} The confession system is already enabled.`)
        .addFields(
            { name: `/confess send`, value: `send a private confession` },
            { name: `/confess reply`, value: `reply to a confession message` },
            { name: `/confess disable `, value: `disable the confession system` },
          )
           .setColor(`${Color}`)
        .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
    else {

        const messageLink = interaction.options.getString('message_-link'); // Replace with your interaction logic

        // Extract the necessary information from the message link
        const regex = /https?:\/\/(?:www\.)?discord(?:app)?\.com\/channels\/(\d+)\/(\d+)\/(\d+)/;
        const match = regex.exec(messageLink);
        if (!regex.test(messageLink)) {
            return await interaction.followUp({ embeds: [new EmbedBuilder()
   
                .setDescription(`${emoji.error} invalid message link.`)
              
                   .setColor(`${Color}`)
                .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
        }
        
        const guildId = match[1];
        const channelId = match[2];
        const messageId = match[3];
        
        // Fetch the target channel
        const targetChannel = await client.channels.fetch(channelId);
        
        if (!targetChannel || targetChannel.guild.id !== guildId || !targetChannel.isText()) {
            return await interaction.followUp({ embeds: [new EmbedBuilder()
   
                .setDescription(`${emoji.error} that is a invalid message link.`)
              
                   .setColor(`${Color}`)
                .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
        }
        
        // Fetch the target message
   

        const targetMessage = await targetChannel.messages.fetch(messageId);
        
        if (!targetMessage) {
            return await interaction.followUp({ embeds: [new EmbedBuilder()
   
                .setDescription(`${emoji.error} failed to find the message link.`)
              
                   .setColor(`${Color}`)
                .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })], ephemeral: true});
        }
        const existingThreads = await targetChannel.threads.fetchActive();
        const existingThread = existingThreads.find(thread => thread.name === `Confession Replies`);
        
        if (existingThread) {
            if(!confessdata.Reply) confessdata.Reply = 0;
            confessdata.Reply = confessdata.Reply + 1;
            confessdata.save();
            const messageembed = new EmbedBuilder()
            .setColor(`${Color}`)
            .setThumbnail(interaction.guild?.iconURL())
            .setTitle(`Anonymous Reply (#${confessdata.Reply || 0})`)
            .setDescription(`"${message}"`)

            existingThread.send({ embeds: [messageembed]}).then(() => {
                interaction.followUp({ content: `${emoji.success} your reply was added.`})
              });
        } else { 
        
        // Create a thread with the target message as the parent
        const thread = await targetChannel.threads.create({
          name: `Confession Replies`,
        //  autoArchiveDuration: 60, // Time in minutes, choose the duration that suits your needs
          startMessage: targetMessage,
        });
        if(!confessdata.Reply) confessdata.Reply = 0;
        confessdata.Reply = confessdata.Reply + 1;
        confessdata.save();
        // Send a message in the created thread
        const messageembed = new EmbedBuilder()
        .setColor(`${Color}`)
        .setThumbnail(interaction.guild?.iconURL())
        .setTitle(`Anonymous Reply (#${confessdata.Reply || 0})`)
        .setDescription(`"${message}"`)

        existingThread.send({ embeds: [messageembed]}).then(() => {
          interaction.followUp({ content: `${emoji.success} your reply was added.`})
        });
    }
    }

    break;
    case 'send':
   
    const timeouttime = 40;

    timeoutv.push(interaction.user.id);
    setTimeout(() => {
        timeoutv.shift();
    }, timeouttime)

    let message = interaction.options.getString('message');
    const confesschannel = await interaction.guild.channels.cache.get(confessdata.Channel);

    if (!confesschannel) {
        return await interaction.followUp({ 
            embeds: [new EmbedBuilder()
       
                .setDescription(`${emoji.error} an error happened while trying to deliever your confession, this can be because the confession channel was not found.`)
                   .setColor(`${Color}`)
                .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })],
                 ephemeral: true});
    }

    if (!message) {
        message = `${emoji.error} no message was found.`
    }
    if(!confessdata.Confessions) confessdata.Confessions = 0;
    confessdata.Confessions = confessdata.Confessions + 1;
    confessdata.save();
    const messageembed = new EmbedBuilder()
    .setColor(`${Color}`)
    .setThumbnail(interaction.guild?.iconURL())
    .setTitle(`Anonymous Confession (#${confessdata.Confessions || 0})`)
    .setDescription(`"${message}"`)

     confesschannel.send({ embeds: [messageembed] });

    

         interaction.followUp({ content: `${emoji.success} your confession(s) was delivered.`, ephemeral: true})


}
}
}
