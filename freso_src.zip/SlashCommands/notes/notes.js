const {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  Client,
  EmbedBuilder,
  time,
} = require("discord.js");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, } = require('discord.js');

const { Types } = require("mongoose");
const noteSchema = require("../../database/guildData/notes")
const emoji = require("../../emoji.json") 
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");

module.exports = {
  name: "notes",
  description: "...",
type: ApplicationCommandType.ChatInput,
  options: [
      {
          name: "add",
          description: "Add an note to a user",
        type: ApplicationCommandOptionType.Subcommand,
          options: [
              {
                  name: "user",
                  description: "user",
                 type: ApplicationCommandOptionType.User,   
               required: true
              },
              {
                name: "note",
                description: "the note to add.",
               type: ApplicationCommandOptionType.String,   
             required: true
            },
          ]
      },
      {
        name: "remove",
        description: "Remove an note from a user",
      type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "stoageid",
            description: "input",
           type: ApplicationCommandOptionType.String,   
         required: true
        },
          
        ]
    },
    {
      name: "update",
      description: "Updates a users note with storageId",
    type: ApplicationCommandOptionType.Subcommand,
      options: [
          {
              name: "stoageid",
              description: "input",
             type: ApplicationCommandOptionType.String,   
           required: true
          },
          {
            name: "note",
            description: "the note to update it to.",
           type: ApplicationCommandOptionType.String,   
         required: true
        },
      ]
  },
  {
    name: "view",
    description: "Views all the notes of a user",
  type: ApplicationCommandOptionType.Subcommand,
    options: [
        {
            name: "user",
            description: "user",
           type: ApplicationCommandOptionType.User,   
         required: true
        },
      
    ]
},
  ],
  run: async(client, interaction, args) => {
    const { options, member, guild } = interaction;
await interaction.deferReply({ ephemeral: true})
    switch (options.getSubcommand()) {
      case "add":
        const note = options.getString("note");
        const usr = options.getUser("user");
        const noteTime = time();

        const newSchema = new noteSchema({
          _id: Types.ObjectId(),
          guildId: guild.id,
          userId: usr.id,
          note: note,
          moderator: member.user.id,
          noteDate: noteTime,
        });

        newSchema.save().catch((err) => console.log(err));

        await interaction.followUp({
          embeds: [
            new EmbedBuilder()
              .setDescription(
                `${emoji.success} Note was added to **${usr.username}**.`
              )
              .setColor("#2f3136"),
          ],
          ephemeral: true,
        });
        break;

       case "view":
        const user = options.getUser("user");
        const backId = 'back'
        const forwardId = 'forward'
        const backButton = new ButtonBuilder({
          style: ButtonStyle.Primary,
          label: 'Back',
        
          customId: backId
        })
        const forwardButton = new ButtonBuilder({
          style: ButtonStyle.Primary,
          label: 'Forward',
        
          customId: forwardId
        });
          
               let Database = await noteSchema.find({ 
                guildId: guild.id,
                userId: user.id,
                moderator: interaction.user.id,
               }).exec(async (err, res) => {
                 let g = interaction.guild;
              //if database not found
              if (!res || !res.length) { 
                
                
                return interaction.followUp(`${emoji.error} You've added no notes to this user.`)
        
              } 
            
              let array = [];
        
              
              for (i = 0; i < res.length; i++) {
              array.push(`\`${i + 1}\`. **StorageId**: ${res[i]._id}\n\n**Note**: ${res[i].note}.`);
                
             
              }
         const interval = 10;
        
        
         
            const range = (array.length == 1) ? '[1]' : `[1 - ${array.length}]`;
        let guilds = array;
              const generateEmbed = async start => {
          const current = array.slice(start, start + 3)
        
          // You can of course customise this embed however you want
          return new EmbedBuilder({
           author: { 
             name: `${g.name}`,
            iconURL: g?.iconURL({dyanmic: true}),
           },
            thumbnail: {
               url: g?.iconURL({ size: 4096, dyanmic: true}),
          
            },
          
            description: `${current.join(`\n`)}`,
            
            color: 0x2e3135,
          })
              };
            
        // Send the embed with the first 10 guilds
        const canFitOnOnePage = guilds.length <= 3
        const embedMessage = await interaction.followUp({
          embeds: [await generateEmbed(0)],
          components: canFitOnOnePage
            ? []
            : [new ActionRowBuilder({components: [forwardButton]})]
        })
        // Exit if there is only one page of guilds (no need for all of this)
        if (canFitOnOnePage) return;
        
        // Collect button interactions (when a user clicks a button),
        // but only when the button as clicked by the original message author
        const collector = embedMessage.createMessageComponentCollector({
          filter: ({user}) => user.id === interaction.user.id
        })
        
        let currentIndex = 0
        collector.on('collect', async interaction => {
          // Increase/decrease index
          interaction.customId === backId ? (currentIndex -= 3) : (currentIndex += 3)
          // Respond to interaction by updating message with new embed
          await interaction.update({
            embeds: [await generateEmbed(currentIndex)],
            components: [
              new ActionRowBuilder({
                components: [
                  // back button if it isn't the start
                  ...(currentIndex ? [backButton] : []),
                  // forward button if it isn't the end
                  ...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
                ]
              })
            ]
          })
          
               })
              })
          break;
  

      case "remove":
        const noteId = options.getString("stoageid");
        const data = await noteSchema.findById(noteId);

        const error = new EmbedBuilder()
  
          .setDescription(
            `${emoji.error} No notes matched the following **${noteId}**.`
          )
          .setColor("#2f3136");

        if (!data) await interaction.followUp({ embeds: [error], ephemeral: true });
        if(data.moderator === interaction.user.id) { 
        data.delete();

        const success = new EmbedBuilder()
        .setColor("#2f3136")
          .setDescription(
            `${emoji.success} Note **${noteId}** was removed from <@${data.userId}> successfully.`
          );

        await interaction.followUp({
          embeds: [success],
          ephemeral: true,
        });
      } else {
        const em = new EmbedBuilder()
  
        .setDescription(
          `${emoji.error} You did not add this note.`
        )
        .setColor("#2f3136");
        await interaction.followUp({
          embeds: [em],
          ephemeral: true,
        });
      }
        break;

    

      case "update":
        const newNote = options.getString("note");
        const newId = options.getString("stoageid");

        const newData = await noteSchema.findById(newId);

        const err = new EmbedBuilder()
        .setDescription(
          `${emoji.error} No notes matched the following **${newId}**.`
        )
        .setColor("#2f3136");

        if (!newData) await interaction.followUp({ embeds: [err], ephemeral: true });

        await noteSchema.findOneAndUpdate(
          { guildId: guild.id, _id: newId },
          { note: newNote }
        );

        const suc = new EmbedBuilder()
        .setColor("#2f3136")
          .setDescription(
            `${emoji.success} Updated the note from <@${newData.userId}> to \`${newNote}\``
          );

        await interaction.followUp({
          embeds: [suc],
          ephemeral: true,
        });
      default:
        break;

       
    }
  },
};