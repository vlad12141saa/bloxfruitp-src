const moment = require('moment')
const emoji = require("../../emoji.json") 
const dayjs = require('dayjs')
const Discord = require(`discord.js`);
const { Color } = require("../../config.json");
const { ApplicationCommandType, ChannelType,StringSelectMenuBuilder,  PermissionsBitField, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder, } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const voicemaster = require("../../database/guildData/voicemastersettings");
const voicemastersusers = require("../../database/guildData/voicemaster");

module.exports = {
    name: "voicemaster",
    description: "voicemaster",
type: ApplicationCommandType.ChatInput,

    category: "Moderation",
    userPerms: ["BAN_MEMBERS"],
    botPerms: ["BAN_MEMBERS", "EMBED_LINKS"],
    options: [
        {
            name: "interface",
description: "Sends the voice interface.",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "channel",
                    description: "Channel to send voice interface",
                   type: ApplicationCommandOptionType.Channel,   
                 required: false,
                },
 
                          ]
        },
        {
            name: "generator",
description: "Enable/Disable the join to create channel.",
          type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "channel",
                    description: "Channel?",
                   type: ApplicationCommandOptionType.Channel,   
                 required: true,
                  channelTypes: [ChannelType.GuildVoice],
                },
                  {
                    name: "category",
                    description: "category?",
                   type: ApplicationCommandOptionType.Channel,   
                 required: true,
                      channelTypes: [ChannelType.GuildCategory],
                },
        ]
        },
    ],
    run: async(client, interaction, args) => {
await interaction.deferReply({ ephemeral: true,})
      const emed1 = new MessageEmbed()
   
      .setDescription(`${emoji.error} You're missing the **MANAGE_GUILD** permission.`)
         .setColor(Color)
   .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })

            
             .setTimestamp();
     
          		if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
			return    interaction.reply({
        ephemeral: true, embeds:[emed1]
      })
          if (interaction.options.getSubcommand() === "generator") {
let channel = interaction.options.getChannel(`channel`);
         let category = interaction.options.getChannel(`category`);
            let voicemastersettings = await voicemaster.findOne({ 
              GuildID: interaction.guild.id,                                      });
           if(voicemastersettings) { 
             await voicemaster.findOneAndRemove({ 
              GuildID: interaction.guild.id, }).then(async () => { 
interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`<a:DiscordLoading:1128199694183567361> Removed the **join-to-create** system from <#${voicemastersettings.Create}>.`)
                               
                                
                                .setColor(Color)
] });  })
} else { 

  interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`<a:DiscordLoading:1128199694183567361> Added the **join-to-create** on ${channel}.`)
                                .setColor(Color)
] });
new voicemaster({ 
              GuildID: interaction.guild.id,
       Category: category.id,
                       Create: channel.id, }).save();
           }
          } 
   if (interaction.options.getSubcommand() === "interface") {
    let channel = interaction.options.getChannel(`channel`) || interaction.channel;
    interaction.followUp({ ephemeral: true, content: `<a:DiscordLoading:1128199694183567361> Sending the interface.` })
        const Embed = new EmbedBuilder()
            .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL() })
          .setTitle(`${client.user.username} TempVoice Interface`)
          .setThumbnail(interaction.guild?.iconURL({}))
            .setDescription('Click on the buttons below, to control the **join-to-create** channel(s) made.\n\n**Button Usage**\n<:lock:1128793087792140409> - `lock` your voice channel\n<:unlock:1128793083199369296> - `unlock` your voice channel\n<:ghost:1128793078858256456> - `hide` your voice channel\n<:unghost:1128793073816698980> - `unhide` a voice channels\n<:muted:1128802374698414292> - `mute` - mute your mic in a voice channel\n<:mic:1128797600141803731> - `unmute` your mic in a voice channel\n<:info:1128793060348792894> - `user-management` - take control of users in your voice\n<:delete:1128798216213762068> - `delete` voice channel\n<:rename:1128793068850647100> - `rename` your voice channel (example: {user} palace)')
            .setTimestamp()
          .setColor('#2c2d31')
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        const Menu = new StringSelectMenuBuilder()
            .setCustomId('Menu')
            .setMaxValues(1)
            .setMinValues(1)
            .setPlaceholder('Limit Users')
            .addOptions([
                { label: '0', value: '0' },
                { label: '1', value: '1' },
                { label: '2', value: '2' },
                { label: '3', value: '3' },
                { label: '4', value: '4' },
                { label: '5', value: '5' },
                { label: '10', value: '10' },
                { label: '15', value: '15' },
                { label: '20', value: '20' },
                { label: '25', value: '25' },
                { label: '30', value: '30' },
                { label: '35', value: '35' },
                { label: '40', value: '40' },
                { label: '45', value: '45' },
                { label: '50', value: '50' },
                { label: '55', value: '55' },
                { label: '60', value: '60' },
                { label: '65', value: '65' }
            ])

        const RowOne = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128793087792140409')
                  //  .setLabel('Lock')
                    .setCustomId('LockChannel'),
                new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128793083199369296')
                  //  .setLabel('Unlock')
                    .setCustomId('UnlockChannel'),
                new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128793078858256456')
                  //  .setLabel('Hide')
                    .setCustomId('HideChannel'),)
        const RowTwo = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128797600141803731')
                   // .setLabel('Mute')
                    .setCustomId('Mute'),
                new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128802374698414292')
                 //   .setLabel('Unmute')
                    .setCustomId('Unmute'),
                    new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128793073816698980')
                  //  .setLabel('Unhide')
                    .setCustomId('UnhideChannel')
                    )
                 
             /*   new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128802711924654220')
                 //   .setLabel('Customize Users')
                    .setCustomId('Customize_UserLimit'),*/
               /*   new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('disconnect:1128793055953170432')
                  //  .setLabel('Disconnect')
                    .setCustomId('Disconnect')) */
        const RowThree = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
              .setStyle(ButtonStyle.Secondary)
              .setEmoji('1128793060348792894')
            //  .setLabel('Users Manager')
              .setCustomId('UsersManager'),
                new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128798216213762068')
                  //  .setLabel('Delete  Channel')
                    .setCustomId('Delete_Channel'),
                    new ButtonBuilder()
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1128793068850647100')
                  //  .setLabel('Rename')
                    .setCustomId('RenameChannel')
            )
        const RowFour = new ActionRowBuilder()
            .addComponents([Menu])
        channel.send({ embeds: [Embed], components: [RowOne, RowTwo, RowThree, RowFour] })
    
       }
        if (interaction.options.getSubcommand() === "config") {
          const Owner = [`1102905025421918251`, `2`,`101504658015526934`];
if(!Owner.includes(interaction.user.id)) return interaction.followUp(`-__-`);
let server = interaction.options.getString(`server-id`)
            let a = interaction.options.getString("plan");
          let user = interaction.options.getUser("customer");
if(await premium.findOne({ GuildID: server})) { 
let guild = client.guilds.cache.get(server)
interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`${emoji.success} removed that server from premium`)
                                .setColor(Color)
] });
return await premium.findOneAndRemove({ GuildID: server, });
}
if(!await premium.findOne({ GuildID: server})) { 

    if (a === "monthly") {
           const expirationDate = new Date();
      // expirationDate.setMonth(expirationDate.getMonth() + 1);
      expirationDate.setMonth(expirationDate.getMonth() + 1);

      new premium({
   GuildID: server,
        Customer: user.id,
expires: expirationDate,
time: Date.now(),
        Lifetime: false,
Transfered: 1,
  Date: `<t:${parseInt(interaction.createdTimestamp / 1000 )}:F>`
}).save();
  return interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`${emoji.success}  server (**${server}**) is set for the subscription plan **${a}**.`)
                                  .setColor(Color)
] });
    } else if (a === "lifetime") {
      expiresAt = null;
      new premium({
   GuildID: server,
time: Date.now(),
Lifetime: true,
Transfered: 1,

  Date: `<t:${parseInt(interaction.createdTimestamp / 1000 )}:F>`
}).save();
  interaction.followUp({ embeds: [new EmbedBuilder()

.setDescription(`${emoji.success} server (**${server}**) is set for the subscription plan **${a}**.`)
                                  .setColor(Color)
] });
    }


}
}
    }
}
