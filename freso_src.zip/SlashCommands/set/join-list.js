const db = require("quick.db");
const moment = require('moment');
const discord = require("discord.js");

const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;


const { Color } = require("../../config.json");
module.exports = {
type: ApplicationCommandType.ChatInput,
	name: 'joins',
	aliases: ["f-alts"],
	category: "admin",
sm: true,
description: "See the oldest/newest joins in your server",
options: [
  {
      name: 'options',
      description: 'Select a option',
     type: ApplicationCommandOptionType.String,
      required: true,
choices: [
  {
    name: 'newest joins',
    value: 'new'
  },
  {
    name: 'oldest joins',
    value: 'old'
  },
],
  },
],
	run: async (client, interaction, args) => {
      
		const Discord = require('discord.js');
		let bot = client;
    let message = interaction;
		message.bot = bot;
      await interaction.deferReply();
      let s = interaction.options.getString('options');
      const backId = 'back'
const forwardId = 'forward'
const backButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Back',
    customId: backId
})
const forwardButton = new MessageButton({
  style: ButtonStyle.Secondary,
  label: 'Forward',

  customId: forwardId
})
let members;

if(s === `new`) members = message.guild.members.cache
  .filter(member => !member.user.bot)
  .sorted((a, b) =>  b.joinedTimestamp - a.joinedTimestamp )
  if(s === `old`) members = message.guild.members.cache
  .filter(member => !member.user.bot)
  .sorted((a, b) => a.joinedTimestamp - b.joinedTimestamp)

let mapped = members.map(r => r)
.map((m, i) => { return `\`(#${i + 1})\` | <@${m.user.id}> (**${client.users.cache.get(`${m.user.id}`).username}**) · <t:${parseInt(m.joinedTimestamp / 1000)}:R>` || "User not found"
}) 
     

    
  


 
let guilds = mapped;
      let array = guilds;
      const generateEmbed = async start => {
  const current = array.slice(start, start + 10)

  // You can of course customise this embed however you want
  return new MessageEmbed({
    title: `Top users to join ${message.guild.name} ${start + 1}-${start + current.length} out of ${
      array.length
    }`,
    description: `${current.join(`\n`)}`,
    color: 0x2e3135, 
 })
      };
    
// Send the embed with the first 10 guilds
const canFitOnOnePage = guilds.length <= 10
const embedMessage = await interaction.followUp({
  embeds: [await generateEmbed(0)],
  components: canFitOnOnePage
    ? []
    : [new MessageActionRow({components: [forwardButton]})]
})
// Exit if there is only one page of guilds (no need for all of this)
if (canFitOnOnePage) return

// Collect button interactions (when a user clicks a button),
// but only when the button as clicked by the original message author
const collector = embedMessage.createMessageComponentCollector({
  filter: ({user}) => user.id === interaction.user.id
})

let currentIndex = 0
collector.on('collect', async interaction => {
  // Increase/decrease index
  interaction.customId === backId ? (currentIndex -= 10) : (currentIndex += 10)
  // Respond to interaction by updating message with new embed
  await interaction.update({
    embeds: [await generateEmbed(currentIndex)],
    components: [
      new MessageActionRow({
        components: [
          // back button if it isn't the start
          ...(currentIndex ? [backButton] : []),
          // forward button if it isn't the end
          ...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
        ]
      })
    ]
  })
})    

    
  }
  
};