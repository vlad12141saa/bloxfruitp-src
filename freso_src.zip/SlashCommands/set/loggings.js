const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const Discord = require(`discord.js`)
const discord = require(`discord.js`)
const { Color } = require("../../config.json");
const log = require(`../../database/guildData/logs`)
module.exports = {
type: ApplicationCommandType.ChatInput,
    name: 'logging',
    description: "Role module!",
    options: [
        {
            name: 'config',
            description: 'Adds a logging event.',
        type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'event',
                    description: 'Event to add to loggings.',
                   type: ApplicationCommandOptionType.String,
                    required: true,
                     choices: [
          {
            name: 'All Events',
            value: 'All Events'
          },
          {
            name: 'Create Channel',
            value: 'Create Channel'
          },
           {
            name: 'Delete Channel',
            value: 'Delete Channel'
          },
                        {
            name: 'Update Channel',
            value: 'Update Channel'
          },
        {
            name: 'Emoji Events',
            value: 'Emoji Events'
          },
                       {
            name: 'Add Ban',
            value: 'Add Ban'
          },
                       {
            name: 'Remove Ban',
            value: 'Remove Ban'
          },  {
            name: 'Member Join',
            value: 'Member Join'
          },
                       {
            name: 'Member Leave',
            value: 'Member Leave'
          },
                       {
            name: 'Member Update',
            value: 'Member Update'
          },
  {
            name: 'Role Adds',
            value: 'Role Adds'
          },
  {
            name: 'Role Removes',
            value: 'Role Removes'
          },


                       {
            name: 'Guild Update',
            value: 'Guild Update'
          },
                         {
            name: 'Message Delete',
            value: 'Message Delete'
          },
                         {
            name: 'Message Delete Bulk',
            value: 'Message Delete Bulk'
          },
                         {
            name: 'Message Update',
            value: 'Message Update'
          },
                         {
            name: 'Role Create',
            value: 'Role Create'
          },
                         {
            name: 'Role Delete',
            value: 'Role Delete'
          },
                         {
            name: 'Role Update',
            value: 'Role Update'
          },
                        {
            name: 'Voice Channel Leave',
            value: 'Voice Channel Leave'
          },
                        {
            name: 'Voice Channel Join',
            value: 'Voice Channel Join'
          },
                        {
            name: 'Voice Channel Update',
            value: 'Voice Channel Update'
          },
                  ],
                },
                     { 
                    name: 'channel',
                    description: 'Channel.',
                type: ApplicationCommandOptionType.Channel,
                      required: true,
                
              
              
                },
              ],
        },
    ],
          
    run: async(client, interaction, args) => {
      const wait = require('util').promisify(setTimeout);
      let message  = interaction;
      
        if (interaction.options.getSubcommand() === "remove") {
             const s = interaction.options.getString("event")
    const ch = interaction.options.getChannel("channel")
    const { PermissionFlagsBits } = require('discord.js')
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
    return interaction.followUp({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`Manage_Guild\` permission`,
    timestamp: new Date(),
    },
    ],
    });
  if(s === "All Events") {
    new log({
      GuildID: interaction.guild.id,
      All: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`${emoji.success} all events will be logged into ${ch.id}`)
    interaction.reply({
      embeds: [embed]
    });
  }
           if(s === "Create Channel") {
    new log({
      GuildID: interaction.guild.id,
      createChannel: false,
          //Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: channelCreate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
           if(s === "Delete Channel") {
    new log({
      GuildID: interaction.guild.id,
      channelDelete: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`? **Event**: channelDelete
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
         if(s === "Update Channel") {
    new log({
      GuildID: interaction.guild.id,
      channelUpdate: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: channelUpdate
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }    if(s === "Emoji Events") {
    new log({
      GuildID: interaction.guild.id,
      emoji: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: emojiCreate, emojiUpdate, emojiDelete
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }  if(s === "Add Ban") {
    new log({
      GuildID: interaction.guild.id,
      guildBanAdd: false,
       //   Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: guildBanAdd
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }   
     if(s === "Remove Ban") {
    new log({
      GuildID: interaction.guild.id,
      guildBanRemove: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: guildBanRemove
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
           if(s === "Member Join") {
    new log({
      GuildID: interaction.guild.id,
      guildMemberAdd: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: guildMemberAdd
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
             if(s === "Member Leave") {
    new log({
      GuildID: interaction.guild.id,
      guildMemberRemove: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: guildMemberRemove
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Member Update") {
    new log({
      GuildID: interaction.guild.id,
      guildMemberUpdate: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: guildMemberUpdate
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
        if(s === "Guild Update") {
    new log({
      GuildID: interaction.guild.id,
      guildUpdate: true,
        //  Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: guildUpdate
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
            if(s === "Message Delete") {
    new log({
      GuildID: interaction.guild.id,
      messageDelete: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: messageDelete
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
            if(s === "Message Delete Bulk") {
    new log({
      GuildID: interaction.guild.id,
      messageDeleteBulk: true,
          //Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: messageDeleteBulk
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
             if(s === "Message Update") {
    new log({
      GuildID: interaction.guild.id,
      messageUpdate: false,
          //Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: messageUpdate
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Role Create") {
    new log({
      GuildID: interaction.guild.id,
      roleCreate: false,
         // Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: roleCreate
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Role Update") {
    new log({
      GuildID: interaction.guild.id,
      roleUpdate: false,
        //Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: roleUpdate
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Role Delete") {
    new log({
      GuildID: interaction.guild.id,
      roleDelete: false,
       // Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: roleDelete
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Voice Channel Leave") {
    new log({
      GuildID: interaction.guild.id,
      voiceLeave: false,
       // Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: voiceLeave
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
                if(s === "Voice Channel Join") {
    new log({
      GuildID: interaction.guild.id,
      voiceJoin: false,
        //Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: voiceJoin
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }   
          
                if(s === "Voice Channel Update") {
    new log({
      GuildID: interaction.guild.id,
      voiceUpdate: false,
     // Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
    .setDescription(`? **Event**: voiceUpdate
? Channel:${ch}
? Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
        
        }
    
        if (interaction.options.getSubcommand() === "config") {
            const s = interaction.options.getString("event")
    const ch = interaction.options.getChannel("channel")
              if (!client.guilds.cache.get(interaction.guild.id).members.cache.get(interaction.member.id).permissions.has("MANAGE_GUILD")) {
                return interaction.reply('Missing Permissions!')
            }
  if(s === "All Events") {
    let d = await log.findOne({
          GuildID: interaction.guild.id,
      All: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      All: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      All: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
      .setColor(Color)
    .setDescription(`**Event**: All
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
           if(s === "Create Channel") {
                 let d = await log.findOne({
          GuildID: interaction.guild.id,
      channelCreate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      channelCreate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      createChannel: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
      .setColor(Color)
    .setDescription(`**Event**: channelCreate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
           if(s === "Delete Channel") {
                 let d = await log.findOne({
          GuildID: interaction.guild.id,
      channelDelete: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      channelDelete: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      channelDelete: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
      .setColor(Color)
    .setDescription(`**Event**: channelDelete
 Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
         if(s === "Update Channel") {
               let d = await log.findOne({
          GuildID: interaction.guild.id,
      channelUpdate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      channelUpdate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      channelUpdate: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: channelUpdate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }    if(s === "Emoji Events") {
             let d = await log.findOne({
          GuildID: interaction.guild.id,
      emoji: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      emoji: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      emoji: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: emojiCreate, emojiUpdate, emojiDelete
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }  if(s === "Add Ban") {
             let d = await log.findOne({
          GuildID: interaction.guild.id,
      guildBanAdd: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      guildBanAdd: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      guildBanAdd: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildBanAdd
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }   
     if(s === "Remove Ban") {
         let d = await log.findOne({
          GuildID: interaction.guild.id,
      guildBanRemove: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      guildBanRemove: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      guildBanRemove: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildBanRemove
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
           if(s === "Member Join") {
               let d = await log.findOne({
          GuildID: interaction.guild.id,
      guildMemberAdd: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      guildMemberAdd: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      guildMemberAdd: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildMemberAdd
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
             if(s === "Member Leave") {
                 let d = await log.findOne({
          GuildID: interaction.guild.id,
      guildMemberRemove: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      guildMemberRemove: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      guildMemberRemove: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildMemberRemove
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Member Update") {
                let d = await log.findOne({
          GuildID: interaction.guild.id,
      guildMemberUpdate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      guildMemberUpdate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      guildMemberUpdate: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildMemberUpdate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
        if(s === "Guild Update") {
            let d = await log.findOne({
          GuildID: interaction.guild.id,
      guildUpdate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      guildUpdate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      guildUpdate: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildUpdate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
            if(s === "Message Delete") {
                let d = await log.findOne({
          GuildID: interaction.guild.id,
      messageDelete: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      messageDelete: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      messageDelete: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: messageDelete
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }
            if(s === "Message Delete Bulk") {
                let d = await log.findOne({
          GuildID: interaction.guild.id,
      messageDeleteBulk: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      messageDeleteBulk: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      messageDeleteBulk: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: messageDeleteBulk
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
             if(s === "Message Update") {
                 let d = await log.findOne({
          GuildID: interaction.guild.id,
      messageUpdate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      messageUpdate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      messageUpdate: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: messageUpdate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Role Create") {
                let d = await log.findOne({
          GuildID: interaction.guild.id,
      roleCreate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      roleCreate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      roleCreate: true,
          Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: roleCreate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Role Update") {
                let d = await log.findOne({
          GuildID: interaction.guild.id,
      roleUpdate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      roleUpdate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      roleUpdate: true,
        Channel: ch.id,
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: roleUpdate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Role Delete") {
                let d = await log.findOne({
          GuildID: interaction.guild.id,
      roleDelete: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      roleDelete: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      roleDelete: true,
        Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: roleDelete
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
            if(s === "Voice Channel Leave") {
                let d = await log.findOne({
          GuildID: interaction.guild.id,
      voiceLeave: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      voiceLeave: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      voiceLeave: true,
        Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: voiceLeave
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
                if(s === "Voice Channel Join") {
                    let d = await log.findOne({
          GuildID: interaction.guild.id,
      voiceJoin: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      voiceJoin: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      voiceJoin: true,
        Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(` **Event**: voiceJoin
Channel:${ch}
 Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  }   
          
                if(s === "Voice Channel Update") {
                    let d = await log.findOne({
          GuildID: interaction.guild.id,
      voiceUpdate: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      voiceUpdate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      voiceUpdate: true,
      Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: voiceUpdate
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
   if(s === "Role Adds") {
                    let d = await log.findOne({
          GuildID: interaction.guild.id,
      roleAdd: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      voiceUpdate: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      roleAdd: true,
      Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildMemberRoleAdd
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 
   if(s === "Role Removes") {
                    let d = await log.findOne({
          GuildID: interaction.guild.id,
      roleRemove: true, 
    });
    if(d) {
      await log.findOneAndRemove({
            GuildID: interaction.guild.id,
      roleRemove: true, 
      })
      return interaction.reply({
        content: `${emoji.error} Disabled loggings for that event.`
      })
    }
    new log({
      GuildID: interaction.guild.id,
      voiceUpdate: true,
      Channel: ch.id
    }).save()
    const embed = new MessageEmbed()
.setColor(Color)
    .setDescription(`**Event**: guildMemberRoleRemove
Channel:${ch}
Time: <t:${parseInt(Date.now() / 1000)}:R>`)
    interaction.reply({
      embeds: [embed]
    });
  } 


        
        }
    }
          
        
        }