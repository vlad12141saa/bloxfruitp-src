const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const wait = require('node:timers/promises').setTimeout;
const { Color } = require("../../config.json");
let e = require(`../../database/guildData/antilink`);
module.exports = {
    name: "ping",
    description: "See how fast I run.",
type: ApplicationCommandType.ChatInput,
    /**
     * 
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */

    run: async (client, interaction) => {
      
         const ping = Date.now() - interaction.createdAt;
        await interaction.deferReply()
     const getDatabasePing = async () => {
            const Now = Date.now();
            await e.find().then(entrys => {})
            return `${~~(Date.now() - Now)}`;
        };

        const DbPing = await getDatabasePing();    
  interaction.editReply({ embeds:[new MessageEmbed()
        .setColor(Color)
        .setDescription(`<a:DiscordLoading:1128199694183567361> wait, hollon.`)]}).then(msg => {

        msg.edit({ embeds: [], content: `
        \`-\` Ping: **${client.ws.ping}**ms
        \`-\` Edit: **${ping}**ms
        \`-\` Database: **${DbPing}**ms\n\`-\` Shard: ${interaction.guild.shardId}`}).catch(e => interaction.editReply(e));
 
  })
    }
}