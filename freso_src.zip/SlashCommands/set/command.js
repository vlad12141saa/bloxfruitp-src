const Discord = require("discord.js")
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const { Color } = require("../../config.json");
const emoji = require("../../emoji.json") 
const ms = require("ms")
module.exports = {
  name: 'command',
type: ApplicationCommandType.ChatInput,
  description: 'Manage my commands.',
category: "config",
  options: [
      {
    
            name: 'enable',
          
            description: 'Enables a command',
           type: ApplicationCommandOptionType.Subcommand, 

            options: [ { 
              name: 'command',
            description: 'The command to enable.',
        type: ApplicationCommandOptionType.String,

            required: true
        }
            ],


  },
  {
            name: 'disable',
          
            description: 'Disable the command specified.',
       type: ApplicationCommandOptionType.Subcommand, 
          options: [
        {
            name: 'command',
            description: 'Command to disable?',
         type: ApplicationCommandOptionType.String,
            required: true
        }
            ],


  },
  ],

  run: async (client, interaction) => {
const cmddata = require(`../../database/guildData/cmd`)
  let message = interaction; 
  await interaction.deferReply()
   const emed1 = new MessageEmbed()
   
      .setDescription(`You're missing the **MANAGE_GUILD** permission or the ${client.user.username} Manager role.`)
     
                 .setTimestamp();

        // If the member doesn't have enough permissions
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild) && !interaction.member.roles.cache.some((r) => r.name === `${client.user.username} Manager`)) {
            return interaction.followUp({
         embeds: [emed1],
                ephemeral: true
            });
        }

        if (interaction.options.getSubcommand() === "disable") {
let cmd = interaction.options.getString(`command`);
if(cmd?.includes(`command`)) return interaction.followUp({ content: `${emoji.error} You can not disable this command.`})
let c = client.slash.get(cmd);
if(!c) return interaction.followUp({ content: `${emoji.error} That is not a available command.`})
let rrrre = await new cmddata({
    GuildID: interaction.guild.id,
    Command: c.name,
  Moderator: interaction.user,
  Date: `<t:${parseInt(message.createdAt / 1000)}:F>`,
}).save()
await interaction.followUp(`${emoji.success} The command **${c.name}** has been disabled.`)
        }
              if (interaction.options.getSubcommand() === "enable") {
let cmd = interaction.options.getString(`command`);
let c = client.slash.get(cmd);
if(!c) return interaction.followUp({ content: `${emoji.error} That is not a available command.`})
let e = await cmddata.findOne({ GuildID: interaction.guild.id,
                              Command: cmd,});
if(!e) return interaction.followUp({ content: `${emoji.error} That command was never disabled.`})

                interaction.followUp(`${emoji.success} **${c.name}** has been enabled.`)
       await cmddata.findOneAndRemove({ 
        GuildID: interaction.guild.id,
        Command: c.name,
      })

              }
  }
};