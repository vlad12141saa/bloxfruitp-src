const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const { connection } = require("mongoose");
const os = require("os");
const Discord = require("discord.js")

const { Color } = require("../../config.json");
module.exports = {
    name: "botinfo",
type: ApplicationCommandType.ChatInput,
    description: "Bot stats.",
    /**
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */

  run: async (client, interaction, args) => {
await interaction.deferReply()
        await client.user.fetch();
        await client.application.fetch();

        const status = [
            "Disconnected",
            "Connected",
            "Connecting",
            "Disconnecting"
        ];
client.cluster
    .broadcastEval(c => c.guilds.cache.size)
    .then(results => {

client.cluster
	.broadcastEval(c => c.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0))
	.then(u => {
    const memoryUsage = process.memoryUsage().heapUsed / 1024 / 1024; // Memory Usage
        const cpuUsage = process.cpuUsage().user / 1000000; // CPU Usage
        const embed = new MessageEmbed()
            .setColor(Color)
            .setDescription(`This bot was made and developed by **yxny#0**`)
            .addFields(
              { name: 'Memory Usage', value: `> ${memoryUsage.toFixed(2)} MB`, inline: true },
              { name: 'CPU Usage', value: `> ${cpuUsage.toFixed(2)}%`, inline: true },
          )
                 .addFields(   
      //          { name: "Developer(s)", value: `\`\`\`yaml\nConflict#9427\`\`\``, inline: true },
                { name: "System", value: `\`\`\`yaml\n${os.type().includes("Windows") ? "\`\`\`yaml\nLinux Ubuntu 20.04 LTS\`\`\``" : os.type()}\`\`\``, inline: true },
                { name: "Node Version", value: `\`\`\`yaml\n${process.version}\`\`\``, inline: true },
                { name: "Discord.js", value: `\`\`\`yaml\nDiscord.js v14\`\`\``, inline: true },
                { name: "Ping", value: `\`\`\`yaml\n${client.ws.ping}ms\`\`\``, inline: true },
                { name: "Commands", value: `\`\`\`yaml\n${client.slash.size} slash cmds\`\`\``, inline: true },
                { name: "Servers", value: `\`\`\`yaml\n${results.reduce((prev, val) => prev + val, 0)} servers\`\`\``, inline: true},
                { name: "Users", value: `\`\`\`yaml\n${u.reduce((acc, memberCount) => acc + memberCount, 0)} users\`\`\``, inline: true},
                { name: "Uptime", value: `<t:${parseInt(client.readyTimestamp / 1000)}:R>`, inline: true },            );
           
      const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel('Support Server')
    .setURL("https://discord.gg/DPpWF8jF4W")
    .setStyle(ButtonStyle.Link));
        const r = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel('Developers')
    .setCustomId(`devs`)
    .setStyle(ButtonStyle.Secondary));
      const r2 = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel('Go back')
    .setCustomId(`main`)
    .setStyle(ButtonStyle.Success))
      interaction.editReply({ fetchReply: true, components: [row], embeds: [embed], ephemeral: true });

    let filter = (m) => m.user.id === interaction.user.id
					let collector = interaction.channel.createMessageComponentCollector({
						filter,
            type: 'BUTTON',
						time: 25000,
					})
          // <t:${parseInt(member.user.createdTimestamp / 1000 )}:F>
	collector.on('collect', async (button) => {
    let b = button;
      let c = button;
let msg = await interaction.fetchReply()
  if (b.customId === 'devs') {
  await b.deferUpdate();
    let embed = new MessageEmbed()
    .setColor(Color)
    .setTitle(`${client.user.username} Team`)
   embed.setDescription(`**Lead Developer**: yxny`)
    msg.edit({ components: [r2, row], embeds: [embed], ephemeral: true });

  }
    
  if (b.customId === 'main') {
   await b.deferUpdate();
msg.edit({ components: [r, row], embeds: [embed], ephemeral: true });

  }
  })
  })
})
    }
}
