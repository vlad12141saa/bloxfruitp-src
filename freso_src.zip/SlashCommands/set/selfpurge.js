const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ApplicationCommandOptionType, ButtonStyle } = require("discord.js");
const { post } = require("node-superfetch");
const { Color } = require(`../../config.json`)
const { inspect } = require("util");
const emoji = require("../../emoji.json") 
const donator = require('../../database/guildData/donator')
module.exports = {
  name: "selfpurge",
  description: "Purge your own messages with manage_messages permissions",
  options: [
    {
      name: "amount",
      description: "amount of your own messages to delete",
      required: true,
      type: ApplicationCommandOptionType.Number,
    },
  ],

  run: async (client, interaction, prefix) => {
     let message = interaction;
let msg = interaction;
let userId = interaction.user.id;
let amount = interaction.options.getNumber('amount');
await interaction.deferReply({ ephemeral: true, });
let check = await donator.findOne({
  userId: userId,
});
const row = new ActionRowBuilder()
.addComponents(
  new ButtonBuilder()
.setURL(`${emoji.link}`)
    .setLabel('Support Server')
    .setStyle(ButtonStyle.Link),
     new ButtonBuilder()
.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
    .setLabel('Invite Me')
 
    .setStyle(ButtonStyle.Link))
if(!check) {

  return interaction.followUp({ components: [row], content: `${emoji.error} **join** our support server to see how to become a donator.`})
}
await interaction.channel.messages.fetch({  limit: amount }).then((messages) => {
    const myMessages = messages.filter(m => m.author.id === userId);

    if (myMessages.length === 0) {
        return interaction.followUp({ content: `${emoji.error} There was no messages to delete.`})
    }

    const messageIds = myMessages.map(m => m.id);

    interaction.channel.bulkDelete(messageIds)
        .then(() => {
           interaction.followUp({ content: `<a:DiscordLoading:1128199694183567361> Removing **${amount}** of your messages.`});
           message.channel.send(`${emoji.success} **${interaction.user.username}**: is **self-purging** his messages (this feature is for donators only).`)
           .then(msg => {
           setTimeout(() => {
               msg.delete();
           }, 12000)
           });
        });
})

  }
}