const Discord = require('discord.js');

const emoji  = require("../../emoji.json");
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;


const MessageData = require(`../../database/guildData/messages`);
module.exports = {
  type: ApplicationCommandType.ChatInput,
        name:"reset-messages",
        aliases: ["invs"],
        category: "info",

        description: `Reset users messages count.`,
          options: [
            
    {
     type: ApplicationCommandOptionType.User,
      name: "user",
      description: "Reset messages of a specific user.",
      required: false,
    },
      ],
  run: async (client, interaction, args) => {
    let message = interaction;
    await interaction.deferReply();
    if(!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGulid)) return interaction.followUp(`${emoji.error} You are missing the required permissions.`)
const { options } = interaction;
        const r1 = new MessageActionRow().addComponents(
                new MessageButton()
                .setLabel("Yes")
     
                .setStyle(ButtonStyle.Success)
                .setCustomId("yes"),
                new MessageButton()
                .setLabel("No")
              
                .setStyle(ButtonStyle.Danger)
                .setCustomId("no")
            );
    
      const e1 = new MessageEmbed()
    
            .setDescription(`Are sure to about this action?`)
            .setColor(Color)
      
    if(interaction.options.getUser(`user`)) {
        interaction.followUp({
                embeds: [e1],
                components: [r1],
            });
          const filter = i => i.user.id === interaction.user.id;
            const collector = interaction.channel.createMessageComponentCollector({
                 filter, 
                 time: 60000 
                });
            collector.on("collect", async i => {
                if(i.customId === "yes") {
                  
                  
      i.update({ components: [], content: `${interaction.options.getUser(`user`)} messages have been cleared.`, embeds: []})
     return await MessageData.findOneAndUpdate({
             GuildID: interaction.guild.id,
             userID: interaction.options.getUser(`user`).id,
             
           messageCount: 0,
          }
        );
                }
              if(i.customId == `no`) {
           return     i.update({components: [] })
              }
            })
    
    }
    if(!interaction.options.getUser(`user`)) {
                        
    interaction.followUp({
                embeds: [e1],
                components: [r1],
            });
                               
    const filter = i => i.user.id === interaction.user.id;
            const collector = interaction.channel.createMessageComponentCollector({
                 filter, 
                 time: 60000 
                });
            collector.on("collect", async i => {
                if(i.customId === "yes") {
                  
                  client.embed(interaction, 'all tracked messages found have been cleared.')

 return  await   MessageData.deleteMany(
          { GuildID: message.guild.id,
      
          }
        );
                }
              if(i.customId == `no`) {
           return     i.update({components: [] })
              }
            })
    }
  }
    }