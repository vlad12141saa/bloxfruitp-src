const discord = require("discord.js");
const Discord = require ("discord.js")
const { version } = require('../../package.json');
const ms = require('pretty-ms');
const db = require("quick.db")
const emoji = require("../../emoji.json") 
const { Color } = require("../../config.json");

const Guild = require("../../database/guildData/autostatus");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;


const { version: discordjsVersion } = require('discord.js');
module.exports = {
  name: "autostatus",
  description: "Roles on a certain status",
     options: [
        {
            name: 'role',
            description: 'The role you would like to give.',
         required: true,
            type: ApplicationCommandOptionType.Role,
          
        },
        {
            name: 'status',
            description: 'The status that I should set in my database.',
            required: true,
            type:ApplicationCommandOptionType.String,
          
            
        },
   {
            name: 'logs',
            description: 'The channel',
            required: true,
            type: ApplicationCommandOptionType.Channel,
          
            
        },

    ],
  run: async (client, interaction, args) => {
  if (!client.guilds.cache.get(interaction.guild.id).members.cache.get(interaction.member.id).permissions.has("MANAGE_GUILD", "MANAGE_ROLES")) {
                return interaction.reply({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing  \`MANAGE_ROLES\`, \`MANAGE_SERVER\` permission`,
          timestamp: new Date(),
        },
      ],
          })
  }
  let message = interaction;
  
  let s = new MessageEmbed()
.setDescription(`${emoji.success} The status system now has been turned off.`)

   .setColor(`${Color}`)

  const search = await Guild.findOne({ id: interaction.guild.id });
  if(search) {
  

      interaction.reply({ embeds: [s] })
   return await Guild.findOneAndRemove({ id: interaction.guild.id });
  }
const logs = interaction.options.getChannel('logs') 
       const role = interaction.options.getRole('role') 
          const status = interaction.options.getString('status') 
           const newSetup = new Guild({
                id: interaction.guild.id,
                role: role.id,
                statusmessage: status,
                log: logs.id
            })
       
let embed = new MessageEmbed()
.setDescription(`${emoji.success} Updated status system, is it now enabled.`)
    .setColor(`${Color}`)
      
    
          interaction.reply({ embeds: [embed], })

     newSetup.save();

    }
  }