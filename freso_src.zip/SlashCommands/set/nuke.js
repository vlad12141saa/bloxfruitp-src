const Discord = require('discord.js');
const discord = require('discord.js');
const db = require("quick.db");
const ms = require("ms");
const pms = require("pretty-ms");
const emoji = require("../../emoji.json") 
const { Color } = require("../../config.json");
const prem = require(`../../database/guildData/nuke`)
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

module.exports = {
	name: 'nuke',
type: ApplicationCommandType.ChatInput,
	aliases: ["a-con"],
	category: "admin",
	description: "Deletes a channel and remake it clearing everything from the channel!",
	usage: "alt-config",
    options: [
        {
            name: 'channel',
          
            description: 'Nuke channel.',
                    type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'channel',
                    //  required: true,
                    description: 'Channel.',
                     type: ApplicationCommandOptionType.Channel,
                }
            ],
        },

          {
            name: 'disable',
          
            description: 'Remove a channel from getting nuked.',
    type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'channel',
                      required: true,
                    description: 'Channel',
                     type: ApplicationCommandOptionType.Channel,
                }
            ],
        },
         {
            name: 'enable',
          
            description: 'Enable a channel from getting nuked.',
                   type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'channel',
                      required: true,
                    description: 'Channel',
                   type: ApplicationCommandOptionType.Channel,
                }
            ],
        },
    ],
	run: async (client, interaction, args) => {
    let message = interaction;
    let perm = prem;
  
        if (interaction.options.getSubcommand() === "channel") {
  
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    if(!message.member.permissions.has("MANAGE_CHANNELS")) 
     return interaction.reply({    ephemeral: true,
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `You're missing the \`MANAGE_CHANNELS\` permission`,
          timestamp: new Date(),
        },
      ],
          })
  
           let data = await prem.findOne({
            GuildID: interaction.guild.id,
            Channel: channel.id
          });
          if(data) return interaction.reply({
            content: `${emoji.error} This channel has already been disabled for nuking.`,
          })

              .setColor(Color)
  .setTimestamp();
  if (!channel.parentID) {
    channel.clone({ position: channel.rawPosition }).then((ch) => {
      ch.send({  content: `first` })
    });
    interaction.reply(`Nuking ${channel}...`)
   

  } else {
   channel.clone({ parent: channel.parentID, position: channel.rawPosition }).then((ch) => {
          ch.send({  content: `first` })
    });
  }
  channel.delete();

					

        }
    
        if (interaction.options.getSubcommand() === "disable") {
          const channel = interaction.options.getChannel(`channel`);
              if(!message.member.permissions.has("MANAGE_CHANNELS")) 
     return interaction.reply({    ephemeral: true,
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `You're missing the \`MANAGE_CHANNELS\` permission`,
          timestamp: new Date(),
        },
      ],
          });
          let data = await prem.findOne({
            GuildID: interaction.guild.id,
            Channel: channel.id
          });
          if(data) return interaction.reply({
            content: `${emoji.error} This channel has already been disabled for nuking.`,
          })
          interaction.reply({
            content: `${emoji.success} Success, added \`${channel.name}\` disabled for nuking!`
          })
         let shhshss =  new perm({
            GuildID: interaction.guild.id,
            Channel: channel.id,
          }).save()
        }
     if (interaction.options.getSubcommand() === "enable") {
          const channel = interaction.options.getChannel(`channel`);
              if(!message.member.permissions.has("MANAGE_CHANNELS")) 
     return interaction.reply({    ephemeral: true,
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `You're missing the \`MANAGE_CHANNELS\` permission`,
          timestamp: new Date(),
        },
      ],
          });
          let data = await prem.findOne({
            GuildID: interaction.guild.id,
            Channel: channel.id
          });
          if(!data) return interaction.reply({
            content: `${emoji.error} This channel is not disabled for nuking.`,
          })
          interaction.reply({
            content: `${emoji.success} Success, enabled \`${channel.name}\` for nuking.`,
          });
       await data.delete()
        }
    }
  }
    