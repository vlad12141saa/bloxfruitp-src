const discord = require("discord.js");
const emoji  = require("../../emoji.json");
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField , SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const Discord = require("discord.js");
const db = require("quick.db")
module.exports = {
name: 'clone',
type: ApplicationCommandType.ChatInput,
    description: "Clone a certain channel in this guild",
             options: [
                {
                    name: 'channel',
                    description: 'Channel to clone?',
                       type: ApplicationCommandOptionType.Channel,

                }
            ],
        
  run: async (client, interaction, args) => {
  
let message = interaction;
  if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
                return interaction.reply({
      embeds: [
        {
  color: 0x2f3136,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `You're missing the \`MANAGE_CHANNELS\` permission`,
          timestamp: new Date(),
        },
      ],
          })
  }
    const channel = interaction.options.getChannel('channel') || interaction.channel;
          

            if (!channel) {
      
                return interaction.reply({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} error`,
          timestamp: new Date(),
        },
      ],
          })
}
            const c = await channel.clone()
const m = await interaction.reply(`${emoji.success} Channel has been cloned ${c}`)

  
            }
    }
  