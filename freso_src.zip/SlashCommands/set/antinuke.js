const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType,PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const db = require("quick.db")
const emoji = require("../../emoji.json") 
const wait = require('node:timers/promises').setTimeout;
let antinuke = require(`../../database/antinuke/antinuke`);
let whitelist = require(`../../database/antinuke/whitelisted`)
module.exports = {
    name: 'antinuke',
type: ApplicationCommandType.ChatInput,
    description: "Antinuke config",
    cooldown: 10,
    options: [
        {
            name: 'toggle',
            description: 'Toggle antinuke system.',
                type: ApplicationCommandOptionType.Subcommand,
        },
        {
          name: 'settings',
          description: 'Shows anti nuke settings.',
              type: ApplicationCommandOptionType.Subcommand,
      },
          {
            name: 'whitelist',
          description: 'Add user to anti nuke whitelist.',
                   type: ApplicationCommandOptionType.Subcommand,
            options: [
  {
    name: "user",
    description: "User to add/remove to whitelist.",
        type: ApplicationCommandOptionType.User,
    required: true
  },
  {
    name: 'category',
    description: 'Whitelist users from being touched',
   type: ApplicationCommandOptionType.String,
    required: true,
     choices: [
      {
        name: 'Extra Owner',
        value: 'Owner'
        },
        {
          name: 'All',
          value: 'All'
          },
{
name: 'Banning Members',
value: 'Bans'
},
{
name: 'Kicking Members',
value: 'Kicks'
},
{
name: 'Deleting Channels',
value: 'ChannelDelete'
},
        {
name: 'Create Channels',
value: 'ChannelCreate'
},
{
name: 'Deleting Roles',
value: 'RoleDelete'
},
{
name: 'Create Roles',
value: 'RoleCreate'
},
       {
name: 'Changing Vanity URL',
value: 'GuildUpdate'
},
       {
name: 'Whitelist Bot Join Authorization',
value: 'BotAdd'
},
  ],
},
],
    
            },
            {
              name: 'threshold',
            description: 'set the thresholds to antinuke',
                     type: ApplicationCommandOptionType.Subcommand,
                     options: [
                     {
                      name: 'action',
                      description: 'Select an action',
                     type: ApplicationCommandOptionType.String,
                      required: true,
                       choices: [
            {
              name: 'Banning Members',
              value: 'Bans'
            },
            {
              name: 'Kicking Members',
              value: 'Kicks'
            },
             {
              name: 'Deleting Channels',
              value: 'ChannelDelete'
            },
                          {
              name: 'Create Channels',
              value: 'ChannelCreate'
            },
          {
              name: 'Deleting Roles',
              value: 'RoleDelete'
            },
            {
              name: 'Create Roles',
              value: 'RoleCreate'
            },
                 ],
                  },
    {
      name: "threshold",
      description: "Input.",
          type: ApplicationCommandOptionType.Number,
      required: true
    }
  ],
      
              },
              {
                name: 'logs',
              description: 'Sets channel that recieves antinuke alerts',
                       type: ApplicationCommandOptionType.Subcommand,
                options: [
      {
        name: "channel",
        description: "Input.",
            type: ApplicationCommandOptionType.Channel,
        required: true
      }
    ],
        
                },
                {
                  name: 'events',
                  description: 'Toggle antinuke events.',
              type: ApplicationCommandOptionType.Subcommand,
                  options: [
                      {
                          name: 'event',
                          description: 'Events to toggle',
                         type: ApplicationCommandOptionType.String,
                          required: true,
                           choices: [
                {
                  name: 'Banning Members',
                  value: 'Bans'
                },
                {
                  name: 'Kicking Members',
                  value: 'Kicks'
                },
                 {
                  name: 'Deleting Channels',
                  value: 'ChannelDelete'
                },
                              {
                  name: 'Create Channels',
                  value: 'ChannelCreate'
                },
              {
                  name: 'Deleting Roles',
                  value: 'RoleDelete'
                },
                {
                  name: 'Create Roles',
                  value: 'RoleCreate'
                },
                             {
                  name: 'Changing Vanity URL',
                  value: 'GuildUpdate'
                },
                             {
                  name: 'Adding bots',
                  value: 'BotAdd'
                },
                        ],
                      },
                          
                    ],
              },
              {
                name: 'punishment',
                description: 'Set the antinuke punishments.',
            type: ApplicationCommandOptionType.Subcommand,
                options: [
                    {
                        name: 'punishment',
                        description: 'The punishment for users breakin the thresold',
                       type: ApplicationCommandOptionType.String,
                        required: true,
                         choices: [
              {
                name: 'Ban',
                value: 'Ban'
              },
              {
                name: 'Kick',
                value: 'Kick'
              },
               {
                name: 'Strip roles',
                value: 'Role'
              },
                  
                      ],
                    },
                        
                  ],
            },
    ],
    run: async(client, interaction, args) => {
      let message = interaction;
let guild = interaction.guild;
await interaction.deferReply();
let owner = await interaction.guild.fetchOwner();
let extraowner = await whitelist.findOne({ 
  GuildID: interaction.guild.id,
  userId: interaction.user.id,
  trustedowner: true,
 });
if(owner.id === interaction.user.id || extraowner) { 
  if (interaction.options.getSubcommand() === "settings") {
    let antinukeDB = await antinuke.findOne({ GuildID: interaction.guild.id });
    if(!antinukeDB) {
      let embed = new MessageEmbed()
   
      
      .setDescription(`${emoji.error} The antinuke system is not enabled.`)
  .setColor(`${Color}`)
         interaction.followUp({ embeds: [embed], });
    } else {
      interaction.followUp(`<a:DiscordLoading:1128199694183567361> Please wait for me to get all the **data**.`)
      let whitelistedarray = [];
      let punishment;
      if(antinukeDB.punishment) punishment = antinukeDB.punishment;
      if(antinukeDB.punishment) punishment = antinukeDB.punishment;
      let countnum = 0;
      await whitelist.find({
      GuildID: interaction.guild.id,
      }).exec(async (err, res) => {

     if (!res || !res.length) { 
       return whitelistedarray.push('No users were found');
     } 
     
     for (i = 0; i < res.length; i++) {
      let type = [];
      if(res[i].whitelisted === true) type.push(`Bypass All Events`);
      if(res[i].trustedowner === true) type.push(`Trusted Owner`);
      if(res[i].Banswhitelisted === true) type.push(`User Bans`);
      if(res[i].Kickswhitelisted === true) type.push(`User Kicks`);
      if(res[i].RoleDeletewhitelisted === true) type.push(`Role Deletes`);
      if(res[i].RoleCreatewhitelisted === true) type.push(`Role Creates`);
      if(res[i].ChannelDeletewhitelisted === true) type.push(`Channel Deletes`);
      if(res[i].ChannelCreatewhitelisted === true) type.push(`Channel Creates`);
      if(res[i].GuildUpdatewhitelisted === true) type.push(`Vanity Chnages`);
      if(res[i].BotAddwhitelisted === true) type.push(`Adding Bots`);
      await wait(200);
      if(type.length >= 1) {
        countnum++;
        whitelistedarray.push(`\`${countnum}\`. <@${res[i].userId}> • ${type.join(', ')}`);
      }
      }

    })
      let bans = `<:wrong:1127123450440458341>`;
      if(antinukeDB.Bans && antinukeDB.Bans === true)  bans = `<:check:1127123484888276992>`;
      let kicks = `<:wrong:1127123450440458341>`;
      if(antinukeDB.Kicks && antinukeDB.Kicks === true)  kicks = `<:check:1127123484888276992>`;
      let ChannelCreate = `<:wrong:1127123450440458341>`;
      if(antinukeDB.ChannelCreate && antinukeDB.ChannelCreate === true)  ChannelCreate = `<:check:1127123484888276992>`;
      let ChannelDelete = `<:wrong:1127123450440458341>`;
      if(antinukeDB.ChannelDelete && antinukeDB.ChannelDelete === true)  ChannelDelete = `<:check:1127123484888276992>`;
      let RoleCreate = `<:fresodisable:1128200771939356672><:fresoenabled:1128190843967242240>`;
      if(antinukeDB.RoleCreate && antinukeDB.RoleCreate === true)  RoleCreate = `<:check:1127123484888276992>`;
      let RoleDelete = `<:wrong:1127123450440458341>`;
      if(antinukeDB.RoleDelete && antinukeDB.RoleDelete === true)  RoleDelete = `<:check:1127123484888276992>`;
      let Antivanity = `<:wrong:1127123450440458341>`;
      if(antinukeDB.Antivanity && antinukeDB.Antivanity === true)  Antivanity = `<:check:1127123484888276992>`;
      let BotAdd = `<:wrong:1127123450440458341>`;
      if(antinukeDB.BotAdd && antinukeDB.BotAdd === true)  BotAdd = `<:check:1127123484888276992>`;
      let Logs = `n/a`;
      if(antinukeDB.Logs)  Logs = `<#${antinukeDB.Logs}>`;
      let thresoldarray = [];
      let countnum1 = 0;
      let Bansthreshold = 5;
      if(antinukeDB.Bansthreshold)  Bansthreshold = antinukeDB.Bansthreshold;
      let Kicksthreshold = 5;
      if(antinukeDB.Kicksthreshold)  Kicksthreshold = antinukeDB.Kicksthreshold;
      let ChannelCreatethreshold = 5;
      if(antinukeDB.ChannelCreatethreshold)  ChannelCreatethreshold = antinukeDB.ChannelCreatethreshold;
      let ChannelDeletethreshold = 5;
      if(antinukeDB.ChannelDeletethreshold)  ChannelDeletethreshold = antinukeDB.ChannelDeletethreshold;
      let RoleCreatethreshold = 5;
      if(antinukeDB.RoleCreatethreshold)  RoleCreatethreshold = antinukeDB.RoleCreatethreshold;
      let RoleDeletehreshold = 5;
      if(antinukeDB.RoleDeletehreshold)  RoleDeletehreshold = antinukeDB.RoleDeletehreshold;
      await wait(2100);
      let embed = new MessageEmbed()
      .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL()})
      .setTitle(`${interaction.guild.name} anti-nuke configuration`)
      .setDescription(`- **Punishment** is set to ${punishment}, and **Logs** wll be sent to ${Logs}

                       - Whitelisted users

                       ${whitelistedarray.join('\n')}

                       - Thresolds
                       Bansthreshold: ${Bansthreshold}/60s
                       Kicksthreshold: ${Kicksthreshold}/60s
                       ChannelCreatethreshold: ${ChannelCreatethreshold}/60s
                       ChannelDeletethreshold: ${ChannelDeletethreshold}/60s
                       RoleCreatethreshold: ${RoleCreatethreshold}/60s
                       RoleDeletehreshold: ${RoleDeletehreshold}/60s

                       
                       
      `)
      .addFields(
        { name: `Anti Bans`, value: `${bans}` },
        { name: `Anti Kicks`, value: `${kicks}` },
        { name: `Anti Channel Create`, value: `${ChannelCreate}` },
        { name: `Anti Channel Delete`, value: `${ChannelDelete}` },
        { name: `Anti Role Create`, value: `${RoleCreate}` },
        { name: `Anti Role Delete`, value: `${RoleDelete}` },
        { name: `Anti Bot Add`, value: `${BotAdd}` },
        { name: `Anti Vanity Change`, value: `${Antivanity}` },
      )
  .setColor(`${Color}`);
  if(interaction.guild.iconURL({dynamic:true})) embed.setThumbnail(interaction.guild?.iconURL({ }));
  if(interaction.guild.bannerURL({dynamic:true})) embed.setImage(interaction.guild?.bannerURL({ }));
         interaction.editReply({ embeds: [embed], }).catch((e) => {
          let embed = new MessageEmbed()
          .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL()})
          .setTitle(`${interaction.guild.name} anti-nuke configuration`)
          .setDescription(`- **Punishment** is set to ${punishment}, and **Logs** wll be sent to ${Logs}

                           - Whitelisted users
    
                           ${whitelistedarray.join('\n')}
                            
                           - Thresolds
                       Bansthreshold: ${Bansthreshold}/60s
                       Kicksthreshold: ${Kicksthreshold}/60s
                       ChannelCreatethreshold: ${ChannelCreatethreshold}/60s
                       ChannelDeletethreshold: ${ChannelDeletethreshold}/60s
                       RoleCreatethreshold: ${RoleCreatethreshold}/60s
                       RoleDeletehreshold: ${RoleDeletehreshold}/60s
                       
                       `)
          const embed1 = new EmbedBuilder()
          .setColor(`${Color}`)
          .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL()})
              .addFields(
            { name: `Anti Bans`, value: `${bans}` },
            { name: `Anti Kicks`, value: `${kicks}` },
            { name: `Anti Channel Create`, value: `${ChannelCreate}` },
            { name: `Anti Channel Delete`, value: `${ChannelDelete}` },
            { name: `Anti Role Create`, value: `${RoleCreate}` },
            { name: `Anti Role Delete`, value: `${RoleDelete}` },
            { name: `Anti Bot Add`, value: `${BotAdd}` },
            { name: `Anti Vanity Change`, value: `${Antivanity}` },
          );

          interaction.editReply({ embeds: [embed, embed1], }).catch(e=> {
            interaction.editReply({ content: `${e}`})
          })

         })

    }
  }
                    if (interaction.options.getSubcommand() === "toggle") {
                    let antinukeDB = await antinuke.findOne({ GuildID: interaction.guild.id });
                    if(antinukeDB) {
                      await antinuke.findOneAndRemove({ GuildID: interaction.guild.id }).then(() => {
                        let embed = new MessageEmbed()
   
      
                        .setDescription(`${emoji.success} disabled the antinuke system`)
                    .setColor(`${Color}`)
                        .setTimestamp();
                        
                           interaction.followUp({ embeds: [embed], });
                      })
                    } else {
                      new antinuke({ 
                        GuildID: interaction.guild.id,
                      Bansthreshold: 3,
                      Bans: true,
                      Kicksthreshold: 3,
                      Kicks: true,
                      Threshold: 5,
                      Channelsthreshold: 3,
                     ChannelCreate: true,
                     ChannelDelete: true,
                     RoleCreate: true,
                     RoleDelete: true,
                     Rolesthreshold: 3,
                     Antivanity:  true,
                     punishment: 'strip',
                     Roles: true, }).save();
                      let embed = new MessageEmbed()
   
      
    .setDescription(`${emoji.success} the antinuke system is now toggled on`)
.setColor(`${Color}`)
       interaction.followUp({ embeds: [embed], });
                    }
                }
          if (interaction.options.getSubcommand() === "whitelist") {
       let user = interaction.options.getUser('user');
       let s = interaction.options.getString('category');
       if(s === "Owner") {
       let whitelistDB = await whitelist.findOne({ 
        GuildID: interaction.guild.id,
        userId: user.id,
       });
       if(whitelistDB) {
        if(whitelistDB.trustedowner && whitelistDB.trustedowner === true) { 
        whitelistDB.trustedowner = false;
        await whitelistDB.save();
        let embed = new MessageEmbed()
   
      
        .setDescription(`${emoji.success} ${user} has been removed as a **trusted owner**.`)
    .setColor(`${Color}`)
    interaction.followUp({ embeds: [embed]})
        } else {
          whitelistDB.trustedowner = true;
        await whitelistDB.save();
        let embed = new MessageEmbed()
   
      
        .setDescription(`${emoji.success} ${user} has been edited to a **trusted owner**.`)
    .setColor(`${Color}`)
    interaction.followUp({ embeds: [embed]})
        }
        
        } else {
          new whitelist({ 
            GuildID: interaction.guild.id,
            userId: user.id,
            trustedowner: true,
           }).save();
           let embed = new MessageEmbed()
   
      
           .setDescription(`${emoji.success} ${user} has been added as a **trusted owner**.`)
       .setColor(`${Color}`)
       interaction.followUp({ embeds: [embed]})
        }
        }
        if(s === "All") {
          let whitelistDB = await whitelist.findOne({ 
           GuildID: interaction.guild.id,
           userId: user.id,
          });
          if(whitelistDB) {
           if(whitelistDB.whitelisted && whitelistDB.whitelisted === true) { 
           whitelistDB.whitelisted = false;
           await whitelistDB.save();
           let embed = new MessageEmbed()
      
         
           .setDescription(`${emoji.success} ${user} has been removed from being whitelisted on all events.`)
       .setColor(`${Color}`)
       interaction.followUp({ embeds: [embed]})
           } else {
             whitelistDB.whitelisted = true;
           await whitelistDB.save();
           let embed = new MessageEmbed()
      
         
           .setDescription(`${emoji.success} ${user} is now updated to bypass all anti-nuke events.`)
       .setColor(`${Color}`)
       interaction.followUp({ embeds: [embed]})
           }
           
           } else {
             new whitelist({ 
               GuildID: interaction.guild.id,
               userId: user.id,
               whitelisted: true,
              }).save();
              let embed = new MessageEmbed()
      
         
              .setDescription(`${emoji.success} ${user} can bypass all antinuke events now.`)
          .setColor(`${Color}`)
          interaction.followUp({ embeds: [embed]})
           }
           }
           if(s === "Bans") {
            let whitelistDB = await whitelist.findOne({ 
             GuildID: interaction.guild.id,
             userId: user.id,
            });
            if(whitelistDB) {
             if(whitelistDB.Banswhitelisted && whitelistDB.Banswhitelisted === true) { 
             whitelistDB.Banswhitelisted = false;
             await whitelistDB.save();
             let embed = new MessageEmbed()
        
           
             .setDescription(`${emoji.success} ${user} has been removed from the **${s}** category.`)
         .setColor(`${Color}`)
         interaction.followUp({ embeds: [embed]})
             } else {
               whitelistDB.Banswhitelisted = true;
             await whitelistDB.save();
             let embed = new MessageEmbed()
        
           
             .setDescription(`${emoji.success} ${user} is now updated to be whitelisted in the **${s}** category..`)
         .setColor(`${Color}`)
         interaction.followUp({ embeds: [embed]})
             }
             
             } else {
               new whitelist({ 
                 GuildID: interaction.guild.id,
                 userId: user.id,
                 Banswhitelisted: true,
                }).save();
                let embed = new MessageEmbed()
        
           
                .setDescription(`${emoji.success} ${user} has been added to the **${s}** category.`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
             }
             }
             if(s === "Kicks") {
              let whitelistDB = await whitelist.findOne({ 
               GuildID: interaction.guild.id,
               userId: user.id,
              });
              if(whitelistDB) {
               if(whitelistDB.Kickswhitelisted && whitelistDB.Kickswhitelisted === true) { 
               whitelistDB.Kickswhitelisted = false;
               await whitelistDB.save();
               let embed = new MessageEmbed()
          
             
               .setDescription(`${emoji.success} ${user} has been removed from the **${s}** category.`)
           .setColor(`${Color}`)
           interaction.followUp({ embeds: [embed]})
               } else {
                 whitelistDB.Kickswhitelisted = true;
               await whitelistDB.save();
               let embed = new MessageEmbed()
          
             
               .setDescription(`${emoji.success} ${user} is now updated to be whitelisted in the **${s}** category..`)
           .setColor(`${Color}`)
           interaction.followUp({ embeds: [embed]})
               }
               
               } else {
                 new whitelist({ 
                   GuildID: interaction.guild.id,
                   userId: user.id,
                   Kickswhitelisted: true,
                  }).save();
                  let embed = new MessageEmbed()
          
             
                  .setDescription(`${emoji.success} ${user} has been added to the **${s}** category.`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
               }
              }
               if(s === "ChannelCreate") {
                let whitelistDB = await whitelist.findOne({ 
                 GuildID: interaction.guild.id,
                 userId: user.id,
                });
                if(whitelistDB) {
                 if(whitelistDB.ChannelCreatewhitelisted && whitelistDB.ChannelCreatewhitelisted === true) { 
                 whitelistDB.Kickswhitelisted = false;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} has been removed from the **${s}** category.`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 } else {
                   whitelistDB.ChannelCreatewhitelisted = true;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} is now updated to be whitelisted in the **${s}** category..`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 }
                 
                 } else {
                   new whitelist({ 
                     GuildID: interaction.guild.id,
                     userId: user.id,
                     ChannelCreatewhitelisted: true,
                    }).save();
                    let embed = new MessageEmbed()
            
               
                    .setDescription(`${emoji.success} ${user} has been added to the **${s}** category.`)
                .setColor(`${Color}`)
                interaction.followUp({ embeds: [embed]})
                 }
               }
               if(s === "ChannelDelete") {
                let whitelistDB = await whitelist.findOne({ 
                 GuildID: interaction.guild.id,
                 userId: user.id,
                });
                if(whitelistDB) {
                 if(whitelistDB.ChannelDeletewhitelisted && whitelistDB.ChannelDeletewhitelisted === true) { 
                 whitelistDB.ChannelDeletewhitelisted = false;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} has been removed from the **${s}** category.`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 } else {
                   whitelistDB.ChannelDeletewhitelisted = true;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} is now updated to be whitelisted in the **${s}** category..`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 }
                 
                 } else {
                   new whitelist({ 
                     GuildID: interaction.guild.id,
                     userId: user.id,
                     ChannelDeletewhitelisted: true,
                    }).save();
                    let embed = new MessageEmbed()
            
               
                    .setDescription(`${emoji.success} ${user} has been added to the **${s}** category.`)
                .setColor(`${Color}`)
                interaction.followUp({ embeds: [embed]})
                 }
               }
               if(s === "RoleCreate") {
                let whitelistDB = await whitelist.findOne({ 
                 GuildID: interaction.guild.id,
                 userId: user.id,
                });
                if(whitelistDB) {
                 if(whitelistDB.RoleCreatewhitelisted && whitelistDB.RoleCreatewhitelisted === true) { 
                 whitelistDB.RoleCreatewhitelisted = false;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} has been removed from the **${s}** category.`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 } else {
                   whitelistDB.RoleCreatewhitelisted = true;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} is now updated to be whitelisted in the **${s}** category..`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 }
                 
                 } else {
                   new whitelist({ 
                     GuildID: interaction.guild.id,
                     userId: user.id,
                     RoleCreatewhitelisted: true,
                    }).save();
                    let embed = new MessageEmbed()
            
               
                    .setDescription(`${emoji.success} ${user} has been added to the **${s}** category.`)
                .setColor(`${Color}`)
                interaction.followUp({ embeds: [embed]})
                 }
               }
               if(s === "RoleDelete") {
                let whitelistDB = await whitelist.findOne({ 
                 GuildID: interaction.guild.id,
                 userId: user.id,
                });
                if(whitelistDB) {
                 if(whitelistDB.RoleDeletewhitelisted && whitelistDB.RoleDeletewhitelisted === true) { 
                 whitelistDB.RoleDeletewhitelisted = false;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} has been removed from the **${s}** category.`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 } else {
                   whitelistDB.RoleDeletewhitelisted = true;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} is now updated to be whitelisted in the **${s}** category..`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 }
                 
                 } else {
                   new whitelist({ 
                     GuildID: interaction.guild.id,
                     userId: user.id,
                     RoleDeletewhitelisted: true,
                    }).save();
                    let embed = new MessageEmbed()
            
               
                    .setDescription(`${emoji.success} ${user} has been added to the **${s}** category.`)
                .setColor(`${Color}`)
                interaction.followUp({ embeds: [embed]})
                 }
               }
               if(s === "GuildUpdate") {
                let whitelistDB = await whitelist.findOne({ 
                 GuildID: interaction.guild.id,
                 userId: user.id,
                });
                if(whitelistDB) {
                 if(whitelistDB.GuildUpdatewhitelisted && whitelistDB.GuildUpdatewhitelisted === true) { 
                 whitelistDB.GuildUpdatewhitelisted = false;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} has been removed from the **${s}** category.`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 } else {
                   whitelistDB.GuildUpdatewhitelisted = true;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
               
                 .setDescription(`${emoji.success} ${user} is now updated to be whitelisted in the **${s}** category..`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 }
                 
                 } else {
                   new whitelist({ 
                     GuildID: interaction.guild.id,
                     userId: user.id,
                     GuildUpdatewhitelisted: true,
                    }).save();
                    let embed = new MessageEmbed()
            
               
                    .setDescription(`${emoji.success} ${user} has been added to the **${s}** category.`)
                .setColor(`${Color}`)
                interaction.followUp({ embeds: [embed]})
                 }
               }
               if(s === "BotAdd") {
                let embed = new MessageEmbed()
            
                .setAuthor({ 
                  name: `${user.tag}` ,
                  icon: `${user?.displayAvatarURL({})}`,
                })
                    .setDescription(`${emoji.error} ${user.tag} must be a discord bot to enter the server gateway.`)
                .setColor(`${Color}`)
              
                if(!user.bot) return interaction.followUp({ embeds: [embed]})
                let whitelistDB = await whitelist.findOne({ 
                 GuildID: interaction.guild.id,
                 userId: user.id,
                });
                if(whitelistDB) {
                
                 if(whitelistDB.BotAddwhitelisted && whitelistDB.BotAddwhitelisted === true) { 
                 whitelistDB.BotAddwhitelisted = false;
                 await whitelistDB.save();

                 let embed = new MessageEmbed()
            
               .setAuthor({ 
                name: `${user.tag}` ,
                icon: `${user?.displayAvatarURL({})}`,
              })
                 .setDescription(`${emoji.success} ${user.tag} has been removed from the **${s}** entry gateway.`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 } else {
                   whitelistDB.BotAddwhitelisted = true;
                 await whitelistDB.save();
                 let embed = new MessageEmbed()
            
                 .setAuthor({ 
                  name: `${user.tag}` ,
                  icon: `${user?.displayAvatarURL({})}`,
                })
                 .setDescription(`${emoji.success} ${user} is now  authorized to enter the gateway **${s}** (meaning they can now join the server lol).`)
             .setColor(`${Color}`)
             interaction.followUp({ embeds: [embed]})
                 }
                 
                 } else {
                   new whitelist({ 
                     GuildID: interaction.guild.id,
                     userId: user.id,
                     BotAddwhitelisted: true,
                    }).save();
                    let embed = new MessageEmbed()
                    .setAuthor({ 
                      name: `${user.tag}` ,
                      icon: `${user?.displayAvatarURL({})}`,
                    })
               
                    .setDescription(`${emoji.success} ${user} has been added to the **${s}** authorization gateway (meaning they can now join the server lol).`)
                .setColor(`${Color}`)
                interaction.followUp({ embeds: [embed]})
                 }
               }
      }
        if (interaction.options.getSubcommand() === "threshold") {
          let number = interaction.options.getNumber('threshold');
          const s = interaction.options.getString("action");
          let antinukeDB = await antinuke.findOne({ GuildID: interaction.guild.id });
          if(!antinukeDB) {
            let embed = new MessageEmbed()
   
      
            .setDescription(`${emoji.error} anti nuke has not been toggled on `)
        .setColor(`${Color}`)
       return interaction.followUp({ embeds: [embed]})
          }
          if(s === "Bans") {
          antinukeDB.Bansthreshold = number;
          await antinukeDB.save();
          
          let embed = new MessageEmbed()
   
      
          .setDescription(`${emoji.success} the **${s}** threshold is now set to **${number}** `)
      .setColor(`${Color}`)
      interaction.followUp({ embeds: [embed]})
          }
          if(s === "kicks") {
            antinukeDB.Kicksthreshold = number;
            await antinukeDB.save();
            
            let embed = new MessageEmbed()
     
        
            .setDescription(`${emoji.success} the **${s}** threshold is now set to **${number}** `)
        .setColor(`${Color}`)
        interaction.followUp({ embeds: [embed]})
            }
            if(s === "RoleCreate") {
              antinukeDB.RoleCreatethreshold = number;
              await antinukeDB.save();
              
              let embed = new MessageEmbed()
       
          
              .setDescription(`${emoji.success} the **${s}** threshold is now set to **${number}** `)
          .setColor(`${Color}`)
          interaction.followUp({ embeds: [embed]})
              }
              if(s === "RoleDelete") {
                antinukeDB.RoleDeletehreshold = number;
                await antinukeDB.save();
                
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} the **${s}** threshold is now set to **${number}** `)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                }
                if(s === "ChannelCreate") {
                  antinukeDB.ChannelCreatethreshold = number;
                  await antinukeDB.save();
                  
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} the **${s}** threshold is now set to **${number}** `)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                  }
                  if(s === "ChannelDelete") {
                    antinukeDB.ChannelDeletethreshold = number;
                    await antinukeDB.save();
                    
                    let embed = new MessageEmbed()
             
                
                    .setDescription(`${emoji.success} the **${s}** threshold is now set to **${number}** `)
                .setColor(`${Color}`)
                interaction.followUp({ embeds: [embed]})
                    }
           }
           if (interaction.options.getSubcommand() === "punishment") {
            const s = interaction.options.getString("punishment");
            console.log(s)
            let antinukeDB = await antinuke.findOne({ GuildID: interaction.guild.id });
            if(!antinukeDB) {
              let embed = new MessageEmbed()
     
        
              .setDescription(`${emoji.error} anti nuke has not been toggled on`)
          .setColor(`${Color}`)
         return interaction.followUp({ embeds: [embed]})
            }
           
            if(s === "Ban") {
              if(antinukeDB.punishment) { 
                antinukeDB.punishment = `ban`;
                await antinukeDB.save();
    
              let embed = new MessageEmbed()
       
          
              .setDescription(`${emoji.success} the punishments for the anti nuke is edited to **${s}** `)
          .setColor(`${Color}`)
          interaction.followUp({ embeds: [embed]})
              } else {
                antinukeDB.punishment = `ban`;
                await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} the punishments for the anti nuke is set to **${s}** `)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
              }
            }
            if(s === "Kick") {
              if(antinukeDB.punishment) { 
                antinukeDB.punishment = `kick`;
                await antinukeDB.save();
    
              let embed = new MessageEmbed()
       
          
              .setDescription(`${emoji.success} the punishments for the anti nuke is edited to **${s}** `)
          .setColor(`${Color}`)
          interaction.followUp({ embeds: [embed]})
              } else {
                antinukeDB.punishment = `kick`;
                await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} the punishments for the anti nuke is set to **${s}** `)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
              }
            }
            if(s === "Role") {
              if(antinukeDB.punishment) { 
                antinukeDB.punishment = `strip`;
                await antinukeDB.save();
    
              let embed = new MessageEmbed()
       
          
              .setDescription(`${emoji.success} the punishments for the anti nuke is edited to **${s}** `)
          .setColor(`${Color}`)
          interaction.followUp({ embeds: [embed]})
              } else {
                antinukeDB.punishment = `strip`;
                await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} the punishments for the anti nuke is set to **${s}** `)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
              }
            }
          }
           if (interaction.options.getSubcommand() === "logs") {
            let channel = interaction.options.getChannel('channel');
            let antinukeDB = await antinuke.findOne({ GuildID: interaction.guild.id });
            if(!antinukeDB) {
              let embed = new MessageEmbed()
     
        
              .setDescription(`${emoji.error} anti nuke has not been toggled on`)
          .setColor(`${Color}`)
         return interaction.followUp({ embeds: [embed]})
            }
            antinukeDB.Logs = channel.id;
            await antinukeDB.save();
            
  
            let embed = new MessageEmbed()
     
        
            .setDescription(`${emoji.success} anti-nuke loggings will be sent to ${channel} `)
        .setColor(`${Color}`)
        interaction.followUp({ embeds: [embed]})
              
            }
             if (interaction.options.getSubcommand() === "events") {
              const s = interaction.options.getString("event");
              console.log(s)
              let antinukeDB = await antinuke.findOne({ GuildID: interaction.guild.id });
              if(!antinukeDB) {
                let embed = new MessageEmbed()
       
          
                .setDescription(`${emoji.error} anti nuke has not been toggled on`)
            .setColor(`${Color}`)
           return interaction.followUp({ embeds: [embed]})
              }
             
              if(s === "Bans") {
                if(antinukeDB.Bans === true) { 
                  antinukeDB.Bans = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} ${s} event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.Bans = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "Kicks") {
                if(antinukeDB.Kicks === true) { 
                  antinukeDB.Kicks = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.Kicks = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "Kicks") {
                if(antinukeDB.Kicks === true) { 
                  antinukeDB.Kicks = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.Kicks = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "ChannelDelete") {
                if(antinukeDB.ChannelDelete === true) { 
                  antinukeDB.ChannelDelete = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.ChannelDelete = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "ChannelCreate") {
                if(antinukeDB.ChannelCreate === true) { 
                  antinukeDB.ChannelCreate = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.ChannelCreate = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "RoleCreate") {
                if(antinukeDB.RoleCreate === true) { 
                  antinukeDB.RoleCreate = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.RoleCreate = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "RoleDelete") {
                if(antinukeDB.RoleDelete === true) { 
                  antinukeDB.RoleDelete = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.RoleDelete = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "GuildUpdate") {
                if(antinukeDB.GuildUpdate === true) { 
                  antinukeDB.GuildUpdate = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.GuildUpdate = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
              if(s === "BotAdd") {
                if(antinukeDB.BotAdd === true) { 
                  antinukeDB.BotAdd = false;
                  await antinukeDB.save();
      
                let embed = new MessageEmbed()
         
            
                .setDescription(`${emoji.success} **${s}** event has been toggled off`)
            .setColor(`${Color}`)
            interaction.followUp({ embeds: [embed]})
                } else {
                  antinukeDB.BotAdd = true;
                  await antinukeDB.save();
        
                  let embed = new MessageEmbed()
           
              
                  .setDescription(`${emoji.success} **${s}** antinuke monitor has been toggled on`)
              .setColor(`${Color}`)
              interaction.followUp({ embeds: [embed]})
                }
              }
               }
      } else {
       return interaction.followUp({
          embeds: [new MessageEmbed()
                  .setColor(Color)
                  .setDescription(`${emoji.error} only the **owner** of this server or a **extra owner** can use these commands.`)]
        });
      }
  
            
        
        }
      
      
}
