/*const { Color } = require("../../config.json");
const Discord = require(`discord.js`);
const Guild = require("../../database/guildData/autostatus");
const { MessageActionRow, MessageEmbed, MessageSelectMenu, MessageButton } = require('discord.js');
const { version: discordjsVersion } = require('discord.js');
module.exports = {
  name: "status-role",
  description: "Roles on a certain status",

     options: [
           {
            name: 'auto',
            description: 'Auto roles users via status.',
            type: "SUB_COMMAND",
            options: [
        {
            name: 'role',
            description: 'The role you would like to use.',
         required: true,
            type: "ROLE",
          
        },
        {
            name: 'status',
            description: 'The status text that users should have.',
            required: true,
            type: "STRING",
          
            
        },
         {
            name: 'logs',
            description: 'The status that I should set in my database.',
            required: true,
            type: "CHANNEL",
          
            
        },
        
              ],
            
        },
        {
            name: 'all',
          description: 'Give roles to members with the mentioned status text.',
            type: "SUB_COMMAND",
           options: [
        {
            name: 'role',
            description: 'Role..',
         required: true,
            type: "ROLE",
          
        },
  {
            name: 'status',
            description: 'Status..',
         required: true,
            type: "STRING",
          
        },

             ],
        },
       
       
    ],
          
  run: async (client, interaction, args) => {
    await interaction.deferReply()
    
        if (interaction.options.getSubcommand() === "auto") {
  if(!client.guilds.cache.get(interaction.guild.id).members.cache.get(interaction.member.id).permissions.has("MANAGE_GUILD", "MANAGE_ROLES")) {
                return interaction.followUp({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing  \`MANAGE_ROLES\`, \`MANAGE_SERVER\` permission`,
          timestamp: new Date(),
        },
      ],
          })
  }
  let message = interaction;
  
  let s = new Discord.MessageEmbed()
.setDescription(`${emoji.error} I will not auto role people on a certain status anymore.`)
 .setAuthor(`${interaction.member.user.tag}`, interaction.member.user.displayAvatarURL({ dynamic: true }))
   .setColor(`${Color}`)
             .setFooter(`${client.user.username}`,client.user.displayAvatarURL())
      .setTimestamp();    
  const search = await Guild.findOne({ id: interaction.guild.id });
  if(search) {
      await Guild.delete()

      return interaction.followUp({ embeds: [s] })
  }
const logs = interaction.options.getChannel('logs') 
       const role = interaction.options.getRole('role') 
          const status = interaction.options.getString('status') 
           const newSetup = new Guild({
                id: interaction.guild.id,
                role: role.id,
                statusmessage: status,
                log: logs.id,
            })
            newSetup.save();
let embed = new Discord.MessageEmbed()
.setDescription(`${emoji.success} I will now give a role to the members with the status.\n> **Status**:  \`${status}\`\n> **Role**:  \`${role.name}\`\n> **Logs**:  \`${logs.name}\`  `)
 .setAuthor(`${interaction.user.tag}`, interaction.user.displayAvatarURL({ dynamic: true }))
   .setColor(`${Color}`)
             .setFooter(`${client.user.username}`,client.user.displayAvatarURL())
      .setTimestamp();     
             const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL('https://discord.gg/mpZercYcz5')
					.setLabel('Support')
					.setStyle('LINK'),
           new MessageButton()
	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite Me')
					.setStyle('LINK'))
interaction.followUp({ content: `${interaction.member.user} has enabled role for status.`, embeds: [embed], components:[row] })
  }


        if (interaction.options.getSubcommand() === "all") {
 const { channel, options } = interaction;
let array = []
        const Amount = options.getString("status");
        const Target = options.getRole("role");
  if (!interaction.member.permissions.has("ADMINISTRATOR"))
      return interaction.followUp({ 
       content: "You Don't Have Enough Permission To Execute This Command - ADMINISTRATOR",
         ephemeral: true
      });
           if (Target.position  >= interaction.member.roles.highest.position )  {
            return interaction.followUp({ 
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
            },
          description: `This role is higher than you..  Therfore you can not give this role!! `,
          timestamp: new Date(),
        },
      ],
          })
  
            }
      const embed = new MessageEmbed()
        
            .setAuthor(interaction.user.tag, interaction.user.avatarURL({dynamic: true}))
      .setDescription(`Successfully starting the status role!`)
      .setColor(Color)
      .setTimestamp()
      interaction.followUp({ embeds: [embed]})
      
    interaction.guild.members.cache.forEach(async (user) => {
      await wait(1000)
const activities = user?.presence.activities[0];
const count = interaction.guild.memberCount * 1000
interaction.editReply(`This will take about ${humanizeDuration(count)}`)

  if (activities && (activities.state?.match(`${Amount}`))) {
user.roles.add(Target.id)
    array.push(user.id)
  }
    })
      interaction.editReply(`Success, completed the progress.\n Gave role to **${array.length}**`)

        }
    }
  }*/