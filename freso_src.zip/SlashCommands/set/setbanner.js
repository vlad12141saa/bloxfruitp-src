const Discord = require('discord.js');
const AsciiTable = require("ascii-table");
const table = new AsciiTable().setHeading("#", "User", "Level", "XP");
const { Rank } = require("canvacord");

const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder,   PermissionFlagsBits,
  ChatInputCommandInteraction,  AttachmentBuilder,
  SlashCommandBuilder,
  ChannelType, } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const emoji = require("../../emoji.json") 
const User = require("../../database/guildData/levels");
module.exports = {
  
        name: "setbanner",
        aliases: ["invs"],
        category: "info",
type: ApplicationCommandType.ChatInput,
        description: `Set a banner in a server`,
          options: [
    {
        type: ApplicationCommandOptionType.String,
      name: "banner",
      description: "The bannner url",
      required: true,
    },
      ],
  run: async (client, interaction, args) => {
    let message = interaction;
    await interaction.deferReply();
    const { PermissionFlagsBits } = require('discord.js')
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
    return interaction.followUp({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`Manage_Guild\` permission`,
    timestamp: new Date(),
    },
    ],
    });
let banner = interaction.options.getString('banner');
interaction.guild.setBanner(`${banner}`)
 .then(updated => {
 interaction.followUp(`${emoji.success} Updated the guild banner successfully.`)
 }).catch((e) => {
  interaction.followUp(`${emoji.error} There was a issue **${e}**.`)
 })


    }
    }