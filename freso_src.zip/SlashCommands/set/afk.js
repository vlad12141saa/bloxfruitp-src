const discord = require("discord.js");

const emoji = require("../../emoji.json") 
const { Color } = require("../../config.js");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const Schema = require('../../database/guildData/afk');
module.exports = {
  name: "afk",
type: ApplicationCommandType.ChatInput,
  category: "info",
  description: `Set ur status as afk`,
  options: [
    {
        name: 'reason',
        description: 'Reasoning on this afk?',
           type: ApplicationCommandOptionType.String,

    }
],
  run: async (client, interaction, args) => {
    let message = interaction;
    let embed = new MessageEmbed()
    let reason = interaction.options.getString('reason') || 'AFK';

await interaction.deferReply();
Schema.findOne({ Guild: interaction.guild.id, User: interaction.user.id }, async (err, data) => {
  if (data) {
      return interaction.followUp({ content: `${emoji.error} aren't you supposed to be **afk**?`})
  }
  else {
      new Schema({
          Guild: interaction.guild.id,
          User: interaction.user.id,
          Message: reason,
          Date: `<t:${parseInt(interaction.createdAt / 1000)}:F>`
      }).save();

      if (!interaction.member.displayName.includes(`[AFK] `)) {
          interaction.member.setNickname(`[AFK] ` + interaction.member.displayName).catch(e => { });
      }
interaction.followUp({ embeds: [new EmbedBuilder()
  .setColor(Color)
  .setDescription(`${emoji.success} Your **afk** was set.\n**Reason**: ${reason || 'AFK'}`)
]
})
  
  }
})
    
  
  }
}