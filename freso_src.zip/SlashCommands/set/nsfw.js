const { Color } = require("../../config.json");
const { ApplicationCommandType, PermissionsBitField, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const Discord = require('discord.js')
let DB = require(`../../database/guildData/nsfwDB`)
module.exports = {
    name: 'nsfw',
type: ApplicationCommandType.ChatInput,
    description: "Nsfw system",
    options: [
        {
            name: 'channel',
            description: 'Sets a discord channel as NSFW.',
                type: ApplicationCommandOptionType.Subcommand,
          options: [
  {
    name: "channel",
    description: "Set channel as a nsfw",
        type: ApplicationCommandOptionType.Channel,
    required: false,
  },
],
        },
    {
      name: 'toggle',
      description: 'Toggles nsfw in the server (only in age restricted channels).',
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "channel",
              description: "Set channel to use nsfw commands",
                  type: ApplicationCommandOptionType.Channel,
              required: false,
            },
          ],
  },
  {
    name: 'posts',
    description: 'Posts some nsfw content (only in age restricted channels).',
        type: ApplicationCommandOptionType.Subcommand,
},
    ],
    run: async(client, interaction, args) => {
      let message = interaction;
let guild = interaction.guild;
await interaction.deferReply();

const emed1 = new MessageEmbed()
   
.setDescription(`${emoji.error} You're missing the **MANAGE_GUILD** permission.`)
   .setColor(Color)
.setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })
if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
return    interaction.followUp({
  ephemeral: true, embeds:[emed1]
})
              
           if (interaction.options.getSubcommand() === "toggle") {
            let channel = interaction.options.getChannel('channel') || interaction.channel;
            let embed = new MessageEmbed()
   

            .setColor(`${Color}`)
            let data = await DB.findOne({ GuildID: interaction.guild.id, ChannelID: channel.id});
              if(data) { 
        await  DB.findOneAndDelete({ GuildID: interaction.guild.id, ChannelID: channel.id }).then(() => {
                embed.setDescription(`${emoji.success} disabled the **nsfw** systemo on ${channel}.`)
                interaction.followUp({ embeds: [embed]})
                })
               } else {
               new DB({ 
                GuildID: interaction.guild.id,
                ChannelID: channel.id,
                }).save();

                  embed.setDescription(`${emoji.success} the **nsfw** system has been enabled on ${channel} (horny ass).`)
          interaction.followUp({ embeds: [embed]})
              }
           }
 if (interaction.options.getSubcommand() === "channel") {
            let channel = interaction.options.getChannel('channel') || interaction.channel;
            let embed = new MessageEmbed()
   

            .setColor(`${Color}`)
            
              if (channel.nsfw === false) {
                channel.edit({ nsfw: true }).then(() => {
                embed.setDescription(`${emoji.success} ${channel} is now age restricted.`)
                interaction.followUp({ embeds: [embed]})
                }).catch((e) => interaction.followUp(`${emoji.error} ${e}`));
               } else {

                channel.edit({ nsfw: false }).then(() => {
                  embed.setDescription(`${emoji.success} ${channel} is edited to **non-age** restricted.`)
                  interaction.followUp({ embeds: [embed]})
                  }).catch((e) => interaction.followUp(`${emoji.error} ${e}`));
              }
            
           }
         if (interaction.options.getSubcommand() === "posts") {
          const { RandomPHUB } = require('discord-phub'); //if you are on nodejs

//If you want to generate unique media each time else set it to false (by default it's false)
const nsfw = new RandomPHUB(unique = false);
           const premium = require("../../database/guildData/premium");
  const row = new Discord.ActionRowBuilder()
        .addComponents(
          new MessageButton()
          .setCustomId('cancelpost')
            .setLabel(`Cancel Posting`)
           		.setStyle(ButtonStyle.Danger))

          const wait = require('node:timers/promises').setTimeout;
          const akaneko = require('akaneko');
          const Nsfw = require("nsfw-images");
const KazeClient = new Nsfw.Client();
           let count = 5;
           let posted = 0;
           let time  = 30000;
           let timemsg = `**${time / 1000}** second(s)` 
           
           let premiumDB = await premium.findOne({
             GuildID: interaction.guild.id
           });
           if(premiumDB && !premiumDB.Lifetme) {
               const expirationDate = premiumDB.expires;

      if (expirationDate > new Date()) {
        time = 60000 * 30;
        timemsg = `**30** minute(s)` 
      } else {
      
         time = 30000;
        console.log('expired')
      }
           }
           if(premiumDB && premiumDB.Lifetime && premiumDB.Lifetime === true) {
              time = 60000 * 30;
        timemsg = `**30** minute(s)` 
           }
           await wait(150)
           let embed = new MessageEmbed()
   

           .setColor(`${Color}`)
           let data = await DB.findOne({ GuildID: interaction.guild.id, ChannelID: interaction.channel.id});
           if(!data) { 
            embed.setDescription(`${emoji.error} the nsfw system is not toggled on this channel.`)
            return interaction.followUp({ embeds: [embed]});
           } else { 
           let nsfwembed = new MessageEmbed()
           .setColor(`${Color}`)

           
            
              if (interaction.channel.nsfw === false) {
                embed.setDescription(`${emoji.error} ${interaction.channel} is not **age restricted**, if you wish to make it **age restricted** you can do the command **nsfw channel**.`)
                interaction.followUp({ embeds: [embed]})
             
               } else {
                embed.addFields(
                  { name: `Premium?`, value: `Consider getting premium and unlock access to some more benefits! </premium benefits:1127110734787137608>` },
                  { name: `Need help?`, value: `If you have questions, concerns or want to report a bug please [**click here**](https://discord.gg/wVWq9wfMEV)` },
                )
                
                  if(client.posting[interaction.channel.id] === true) return interaction.followUp({ content: `${emoji.error} posts are already being sent to this channel.`, embeds: [embed]});
              
                  embed.setDescription(`${emoji.success} Making posts to the designated channel for ${timemsg}.`)
                  if(time > 30001) embed.setDescription(`${emoji.success} Making posts to ${interaction.channel} for ${timemsg}, thanks for buying a premium guild subscription of **freso**, you now have 30 minutes of posting!`)
                
                  interaction.followUp({ components: [row], content: `<a:DiscordLoading:1128199694183567361> Finding posts across web.`, embeds: [embed]});
                  client.posting[interaction.channel.id] = true;
             let nsfwposting = setInterval(async () => {
                if(client.posting[interaction.channel.id] === false) {
                            return clearInterval(nsfwposting)
                            }
                            await KazeClient.nsfw.real.random().then((json) => { 
                              nsfwembed.setImage(json.url);
                              interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                                posted++;
                              }
                              );
                            })
                            
                            if(client.posting[interaction.channel.id] === false) {
                      
                              return clearInterval(nsfwposting)
                              }
             await wait(250) 
             
             if(client.posting[interaction.channel.id] === false) {
                      
              return clearInterval(nsfwposting)
              }
             await KazeClient.nsfw.real.random().then((json) => { 
              nsfwembed.setImage(json.url);
              interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                posted++;
              }
              );
            })
            await wait(200)
             
            if(client.posting[interaction.channel.id] === false) {
                      
              return clearInterval(nsfwposting)
              }

             await KazeClient.nsfw.real.random().then((json) => { 
              nsfwembed.setImage(json.url);
              interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                posted++;
              }
              );
            })
      
    
                    nsfwembed.setImage(await akaneko.nsfw.cum());
                  interaction.channel.send({ components: [row],  embeds: [nsfwembed]}).then(() => {
                    posted++;
                  }
                  )
                
              
                  nsfwembed.setImage(await akaneko.nsfw.masturbation());
                interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                  posted++;
                }
                )
              
                await wait(250) 
                
                if(client.posting[interaction.channel.id] === false) {
                      
                  return clearInterval(nsfwposting)
                  }
            await KazeClient.nsfw.real.random().then((json) => { 
              nsfwembed.setImage(json.url);
              interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                posted++;
              }
              );
            })
                nsfwembed.setImage(await akaneko.nsfw.hentai());
              interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                posted++;
              }
              )
              
              if(client.posting[interaction.channel.id] === false) {
                      
                return clearInterval(nsfwposting)
                }
              await wait(250) 
              
              if(client.posting[interaction.channel.id] === false) {
                      
                return clearInterval(nsfwposting)
                }
              await KazeClient.nsfw.real.random().then((json) => { 
                nsfwembed.setImage(json.url);
                interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                  posted++;
                }
                );
              })
      
              nsfwembed.setImage(await akaneko.nsfw.blowjob());
              interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                posted++;
              }
              );
              await wait(250) 
              
              if(client.posting[interaction.channel.id] === false) {
      
              return clearInterval(nsfwposting)
              }
              await KazeClient.nsfw.real.random().then((json) => { 
                nsfwembed.setImage(json.url);
                interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                  posted++;
                }
                );
              })
              nsfwembed.setImage(await akaneko.nsfw.hentai());
              interaction.channel.send({ components: [row], embeds: [nsfwembed]}).then(() => {
                posted++;
              }
              );
        
    
             
                            if(client.posting[interaction.channel.id] === false) {
                      
                            return clearInterval(nsfwposting)
                            }
              }, 7500)
              let filter = (m) => m.user.id === interaction.user.id;
              let collector = interaction.channel.createMessageComponentCollector({
                filter,
                type: "BUTTON",
                time: time,
              });
              collector.on("collect", async (button) => {
               const b = button;
               if (button.customId && button.customId === "cancelpost") {
             b.deferUpdate();
             client.posting[button.channel.id] = false;
             clearInterval(nsfwposting);
             clearTimeout(timeout);
             b.message.edit({ components: [], });
           await wait(500)
             let emb = new MessageEmbed()
            .setColor(`${Color}`)
            emb.addFields(
             { name: `Premium?`, value: `Consider getting premium and unlock access to some more benefits! </premium benefits:1127110734787137608>` },
   { name: `Need help?`, value: `If you have questions, concerns or want to report a bug please [**click here**](https://discord.gg/wVWq9wfMEV)` },
 )
 emb.setDescription(`${emoji.success} Finished posting the **nsfw-posts**.`)
   button.channel.send({ embeds: [emb]});
               }
             });
           let timeout =   setTimeout(async () => {
clearInterval(nsfwposting);
         
if(client.posting[interaction.channel.id] === false) {
                      
  return clearInterval(nsfwposting)
  }
await wait(6000)
if(client.posting[interaction.channel.id] === false) {
                      
  return clearInterval(nsfwposting)
  }
let emb = new MessageEmbed()
           .setColor(`${Color}`)
           emb.addFields(
            { name: `Premium?`, value: `Consider getting premium and unlock access to some more benefits! </premium benefits:1127110734787137608>` },
  { name: `Need help?`, value: `If you have questions, concerns or want to report a bug please [**click here**](https://discord.gg/wVWq9wfMEV)` },
)
emb.setDescription(`${emoji.success} Finished posting the **nsfw-posts**.`)
  interaction.channel.send({ embeds: [emb]});
  client.posting[interaction.channel.id] = false;
               
             }, time + 1250) 
         
               }
              }
           }
            }
}
