const db = require("quick.db");
const moment = require('moment');
const discord = require("discord.js");
const emoji = require("../../emoji.json") 
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const { Color } = require("../../config.json");
module.exports = {
	name: 'fetch-alts',
type: ApplicationCommandType.ChatInput,
	aliases: ["f-alts"],
	category: "admin",
sm: true,
	description: "fetch alts under a specfic amount of days",
	usage: "fetch-alts",  
  options: [ 
                 {
                    name: 'days',
                    description: 'days of account creation to fetch?',
                type: ApplicationCommandOptionType.Number,
                   required: true
                },
            ],
        
	run: async (client, interaction, args) => {
      
		const Discord = require('discord.js');
		let bot = client;
    let message = interaction;
		message.bot = bot;
      await interaction.deferReply();
     const emed1 = new MessageEmbed()
   
      .setDescription(` You're missing the **MANAGE_GUILD** permission`)
         .setColor(`${Color}`)
                   .setTimestamp();
          		if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
			return    interaction.followUp({
        ephemeral: true, embeds:[emed1]
      })
      const backId = 'back'
const forwardId = 'forward'
const backButton = new MessageButton({
  style: ButtonStyle.Primary,
  label: 'Back',

  customId: backId
})
const forwardButton = new MessageButton({
  style: ButtonStyle.Primary,
  label: 'Forward',

  customId: forwardId
})

// Put the following code wherever you want to send the embed pages:

//const {author, channel} = message;
let s = interaction.options.getNumber(`days`);
let days = s;
      let day = Number(days);

    if(day > 350) return client.embed(interaction, "You may only find alts of an account age of **100 days** or below");
    
    let array = []
let embeds = [];
    message.guild.members.cache.forEach(async(user)=>{

    let math = day * 86400000

    let x = Date.now() - user.user.createdAt;
    let created = Math.floor(x / 86400000);
      
    if(day >= created) {

    array.push(`${user} (${user.user.tag} | ${user.id})\nCreated At: <t:${parseInt(user.user.createdTimestamp / 1000)}:R>`)
    }
   
    })

    const interval = 10;

    const embed = new MessageEmbed()
    .setTitle(`Alt Detector - Account age < ${days} Days`)
    .setDescription(array.join("\n") || "No alts found")
    .setColor(`${Color}`)


 
    const range = (array.length == 1) ? '[1]' : `[1 - ${array.length}]`;
let guilds = array;
      const generateEmbed = async start => {
  const current = array.slice(start, start + 10)

  // You can of course customise this embed however you want
  return new MessageEmbed({
    title: `Showing Alts ${start + 1}-${start + current.length} out of ${
      array.length
    }`,
    description: `${current.join(`\n`)}`,
    color: 0x2e3135,
  })
      };
    
// Send the embed with the first 10 guilds
const canFitOnOnePage = guilds.length <= 10
const embedMessage = await interaction.followUp({
  embeds: [await generateEmbed(0)],
  components: canFitOnOnePage
    ? []
    : [new MessageActionRow({components: [forwardButton]})]
})
// Exit if there is only one page of guilds (no need for all of this)
if (canFitOnOnePage) return

// Collect button interactions (when a user clicks a button),
// but only when the button as clicked by the original message author
const collector = embedMessage.createMessageComponentCollector({
  filter: ({user}) => user.id === interaction.user.id
})

let currentIndex = 0
collector.on('collect', async interaction => {
  // Increase/decrease index
  interaction.customId === backId ? (currentIndex -= 10) : (currentIndex += 10)
  // Respond to interaction by updating message with new embed
  await interaction.update({
    embeds: [await generateEmbed(currentIndex)],
    components: [
      new MessageActionRow({
        components: [
          // back button if it isn't the start
          ...(currentIndex ? [backButton] : []),
          // forward button if it isn't the end
          ...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
        ]
      })
    ]
  })
})    

    
  }
  
};