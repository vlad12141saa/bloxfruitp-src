const discord = require("discord.js");

const emoji = require("../../emoji.json") 
const { Color } = require("../../config.js");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

module.exports = {
  name: "invite",
type: ApplicationCommandType.ChatInput,
  category: "info",
  description: `Sends my invitation link and support server`,
  run: async (client, interaction, args) => {
    let message = interaction;
await interaction.deferReply()

              const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL(`https://discord.gg/WJhUSDw4pM`)
					.setLabel('Support')
					.setStyle(ButtonStyle.Link),
           new MessageButton()
	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite Me')
					.setStyle(ButtonStyle.Link))
   interaction.followUp({ content: `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`, components: [row]});
    
  
  }
}