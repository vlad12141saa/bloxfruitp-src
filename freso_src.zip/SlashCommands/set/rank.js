const Discord = require('discord.js');
const AsciiTable = require("ascii-table");
const table = new AsciiTable().setHeading("#", "User", "Level", "XP");
const { Rank } = require("canvacord");
const { profileImage } = require('discord-arts');
const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder,   PermissionFlagsBits,
  ChatInputCommandInteraction,  AttachmentBuilder,
  SlashCommandBuilder,
  ChannelType, } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const emoji = require("../../emoji.json") 
const User = require("../../database/guildData/levels");
module.exports = {
  
        name:"rank",
        aliases: ["invs"],
        category: "info",
type: ApplicationCommandType.ChatInput,
        description: `See you or another users rank`,
          options: [
    {
        type: ApplicationCommandOptionType.User,
      name: "user",
      description: "View the rank of a specific user.",
      required: false,
    },
      ],
  run: async (client, interaction, args) => {
    let message = interaction;
    await interaction.deferReply();
    let user;
let member = interaction.options.getMember(`user`) || interaction.member;
const guildId = interaction.guild.id;
const userId = member.id;
user = await User.findOne({
  userID: userId,
  guildID: guildId
});

if (!user) {
  user = {
    level: 0,
    xp: 0,
  };
}
let addlevel = user.level + 1;
       const buffer = await profileImage(member.id, {
         borderColor: ['#2c2d31', '#6787e7'],
      presenceStatus: member.presence?.status ?? 'invisible',
      badgesFrame: true,
      usernameColor: '#d9dfef',
      customBackground: 'https://cdn.discordapp.com/attachments/1127473085960949850/1127775564359532594/unnamed.png',
    
      squareAvatar: true,
        rankData: {
            currentXp: user.xp,
            requiredXp: addlevel * addlevel * 100,
            level: user.level,
            barColor: "#ffbddf",
        }
    })
    
 
const rank = new Rank()
.setAvatar(member.user?.displayAvatarURL())
.setCurrentXP(user.xp)
.setLevel(user.level)
.setRank(0, 0, false)
.setRequiredXP(addlevel * addlevel * 100)
.setStatus("online")
.setProgressBar("#75ff7e", "COLOR")
.setUsername(member.user.username)
.setBackground(
  "IMAGE",
    "https://cdn.discordapp.com/attachments/1127473085960949850/1127775564359532594/unnamed.png"
);
const attachment = new AttachmentBuilder(buffer, { name: 'freso.png' });
interaction.followUp({ files: [attachment] });


    }
    }