const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const emoji  = require("../../emoji.json");
const db = require("quick.db")
const autorole = require(`../../database/guildData/autorole`);
module.exports = {
    name: 'autorole',
type: ApplicationCommandType.ChatInput,
    description: "Prune members from the server.",
    options: [
        {
            name: 'add',
            description: 'Add a autorole.',
     type: ApplicationCommandOptionType.Subcommand, 
          options: [
  {
    name: "role",
    description: "Role.",
    type: ApplicationCommandOptionType.Role,
    required: true
  }
],
        },
          {
            name: 'remove',
          description: 'Remove a role from autorole',
          type: ApplicationCommandOptionType.Subcommand, 
            options: [
  {
    name: "role",
    description: "Role to remove from autorole.",
   type: ApplicationCommandOptionType.Role,
    required: true
  }
],
    
            },
                {
            name: 'list',
          description: 'Lists all the autoroles.',
     type: ApplicationCommandOptionType.Subcommand,          
    
            },
   
    ],

    run: async(client, interaction, args) => {
      let message = interaction;
let guild = interaction.guild;
await interaction.deferReply()
            if (interaction.options.getSubcommand() === "list") {
  
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`MANAGE_ROLES\` permission`,
              timestamp: new Date(),
            },
          ],
        })
              
                const backId = 'back'
const forwardId = 'forward'
const backButton = new MessageButton({
  style: ButtonStyle.Primary,
  label: 'Back',
 // emoji: '??',
  customId: backId
})
const forwardButton = new MessageButton({
  style: ButtonStyle.Primary,
  label: 'Forward',
 // emoji: '??',
  customId: forwardId
});
  
       let Database = await autorole.find({ 
         GuildID: message.guild.id, })
       .exec(async (err, res) => {
         let g = interaction.guild;
      //if database not found
      if (!res || !res.length) { 
        
        
        return interaction.followUp(`${emoji.error} There isn't any autoroles`)

      } 
    
      let array = [];

      
      for (i = 0; i < res.length; i++) {
      array.push(`\`${top(i + 1)}. \` <@&${res[i].Role}> - Added by <@${res[i].Author}>`);
        
 
     
      }
 const interval = 10;


 
    const range = (array.length == 1) ? '[1]' : `[1 - ${array.length}]`;
let guilds = array;
      const generateEmbed = async start => {
  const current = array.slice(start, start + 1)

  // You can of course customise this embed however you want
  return new MessageEmbed({
   author: { 
     name: `${g.name}`,
    iconURL: g?.iconURL({dyanmic: true}),
   },
    thumbnail: {
       url: g?.iconURL({ size: 4096, dyanmic: true}),
  
    },
    title: `Autoroles ${start + 1}-${start + current.length} out of ${
      guilds.length
    }`,
    description: `${current.join(`\n`)}`,
    
    color: 0x2e3135,
  })
      };
    
// Send the embed with the first 10 guilds
const canFitOnOnePage = guilds.length <= 1
const embedMessage = await interaction.followUp({
  embeds: [await generateEmbed(0)],
  components: canFitOnOnePage
    ? []
    : [new MessageActionRow({components: [forwardButton]})]
})
// Exit if there is only one page of guilds (no need for all of this)
if (canFitOnOnePage) return;

// Collect button interactions (when a user clicks a button),
// but only when the button as clicked by the original message author
const collector = embedMessage.createMessageComponentCollector({
  filter: ({user}) => user.id === interaction.user.id
})

let currentIndex = 0
collector.on('collect', async interaction => {
  // Increase/decrease index
  interaction.customId === backId ? (currentIndex -= 1) : (currentIndex += 1)
  // Respond to interaction by updating message with new embed
  await interaction.update({
    embeds: [await generateEmbed(currentIndex)],
    components: [
      new MessageActionRow({
        components: [
          // back button if it isn't the start
          ...(currentIndex ? [backButton] : []),
          // forward button if it isn't the end
          ...(currentIndex + 1 < guilds.length ? [forwardButton] : [])
        ]
      })
    ]
  })
  
       })
                              
  })
              
    
    function top(index) {
      return index === 1 ? '1' : index === 2 ? '2' : index === 3 ? '3' : index < 10 ? String(`0${index}`) : index;
    }
            }
        if (interaction.options.getSubcommand() === "add") {
       let role = interaction.options.getRole(`role`);
       if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`MANAGE_ROLES\` permission`,
              timestamp: new Date(),
            },
          ],
        })

                 if (interaction.member.roles.highest.position < role.postion) {
                return interaction.followUp('👎🏾')
            }
          let e = await autorole.findOne({
            Role: role.id,
            GuildID: interaction.guild.id,
          })
          if(e) {
            return interaction.followUp({
              content: `${emoji.error} The role named: \`${role.name}\` is already on the autorole list.`,
            })
          }
if(!e) { 
          interaction.followUp({
            content: `👍🏾`
                              });
          new autorole({
    GuildID: interaction.guild.id,

            Role: role.id,
                    Author: interaction.user.id,
          }).save()

}
        }
         

      
             if (interaction.options.getSubcommand() === "remove") {
       let role = interaction.options.getRole(`role`);
       if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`MANAGE_ROLES\` permission`,
              timestamp: new Date(),
            },
          ],
        })

 
          let e = await autorole.findOne({
            Role: role.id,
            GuildID: interaction.guild.id,
          })
          if(!e) {
            return interaction.followUp({
              content: `${emoji.error} The role named: \`${role.name}\` was not found in my autorole database.`,
            })
          }
         
          interaction.followUp({
         embeds:[new EmbedBuilder()
        .setDescription(`${emoji.success} Successfully added ${role} to be gave upon user join.`)]
                              })
               await autorole.findOneAndRemove({
                 Role: role.id,
            GuildID: interaction.guild.id,
               });
               
        }
         

            
        
        }
      
      
}
