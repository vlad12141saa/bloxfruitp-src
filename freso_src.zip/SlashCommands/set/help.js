const { ApplicationCommandType, ApplicationCommandOptionType,AttachmentBuilder, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const { readdirSync } = require("fs");
const { Color } = require("../../config.json");
let MessageAttachment = AttachmentBuilder;
module.exports = {
    name: 'help',
type: ApplicationCommandType.ChatInput,
    description: 'Lists all commands the bot has.',
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {
await interaction.deferReply()
let message = interaction;
const attachments = [
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129593283618811994/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129593361574133822/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129593536430489700/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129596145279189072/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129596357552906311/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129596643470225458/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129596799208923136/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129597262494974012/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129600798582636716/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129600929889517648/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129601080850911292/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129601282827628604/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129601554840829952/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129601691763884042/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129601821489496144/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129602122929942568/image.png'),
  new AttachmentBuilder('https://cdn.discordapp.com/attachments/1127129746380165140/1129602189199941803/image.png'),

];

const row = new ActionRowBuilder()
  .addComponents(new MessageButton().setCustomId('prev').setLabel('Previous').setStyle(ButtonStyle.Secondary))
  .addComponents(new MessageButton().setCustomId('next').setLabel('Next').setStyle(ButtonStyle.Secondary))

const messageOptions = { files: [attachments[0]], components: [row] };
const sentMessage = await interaction.followUp(messageOptions);
let currentIndex = 0;

const filter = (interaction) => interaction.user.id === message.user.id;
const collector = message.channel.createMessageComponentCollector({ idle: 60000, filter });

collector.on('collect', async (interaction) => {
interaction.deferUpdate();
  if (interaction.customId === 'prev') {
      currentIndex = (currentIndex - 1 + attachments.length) % attachments.length;
  } else if (interaction.customId === 'next') {
      currentIndex = (currentIndex + 1) % attachments.length;
  }

  messageOptions.files = [attachments[currentIndex]];
  await interaction.message.edit(messageOptions);
});

      
      }
}