const Discord = require('discord.js');


const { Color } = require("../../config.json");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const emoji = require("../../emoji.json") 
const MessageData = require(`../../database/guildData/messages`);
module.exports = {
  
        name:"messages",
        aliases: ["invs"],
        category: "info",
type: ApplicationCommandType.ChatInput,
        description: `View how many messages you have.`,
          options: [
    {
        type: ApplicationCommandOptionType.User,
      name: "mention",
      description: "View messages of a specific user.",
      required: false,
    },
      ],
  run: async (client, interaction, args) => {
    let message = interaction;
    await interaction.deferReply();
let user = interaction.options.getMember(`mention`) || interaction.user;
          MessageData.findOne(
        {
          userID: user.id,
         GuildID: message.guild.id,
        },
        (err, messages) => {
          if (err) console.error(err);
          if (!messages) {
            const newTracker = new MessageData({
              userID: user.id,
              GuildID: message.guild.id,
              messageCount: 0,
            });
            newTracker.save().catch(err => console.error(err));
                        let e = new MessageEmbed()
              .setColor(Color)
         

            .setDescription(`${emoji.error} You have no messages tracked in this server.`)
                                       
      
            message.followUp({ embeds: [e] })
          } else {
            let embed = new MessageEmbed()
              .setColor(Color)
            .setDescription(`${user} sent **${messages.messageCount}** messages.`)
            message.followUp({ embeds: [embed] })
          }
        }
      );
    }
    }