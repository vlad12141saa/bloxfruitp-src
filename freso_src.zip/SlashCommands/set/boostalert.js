const { Color } = require("../../config.js");
const { ApplicationCommandType, ApplicationCommandOptionType, PermissionsBitField, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const db = require("quick.db")
let DB = require(`../../database/guildData/boostlog`)
module.exports = {
    name: 'boost-log',
type: ApplicationCommandType.ChatInput,
    description: "Prune members from the server.",
    options: [
        {
            name: 'channel',
            description: 'Config the channel for the boost loggings.',
          type: ApplicationCommandOptionType.Subcommand, 

          options: [
  {
    name: "channel",
    description: "Channel.",
   type: ApplicationCommandOptionType.Channel,
    required: true
  }
],
        },
          {
            name: 'message',
          description: 'Set the boost log message (JSON embeds supported)',
             type: ApplicationCommandOptionType.Subcommand, 

            options: [
  {
    name: "input",
    description: "Input (Embed JSON supported).",
   type: ApplicationCommandOptionType.String,

    required: true
  }
],
    
            },
    {
            name: 'help',
          description: 'Simple help page for boost loggings setup.',
            type: ApplicationCommandOptionType.Subcommand, 
           
    
            },
       {
            name: 'toggle',
          description: 'Toggle to enable or disable boost logs.',
              type: ApplicationCommandOptionType.Subcommand, 

         
    
            },
        {
            name: 'show',
          description: 'Displays the current boost log settings.',
        type: ApplicationCommandOptionType.Subcommand, 

         
    
            },
    ],

    run: async(client, interaction, args) => {
      let message = interaction;
let guild = interaction.guild;
await interaction.deferReply()
                if (interaction.options.getSubcommand() === "help") {
       
                  if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`ADMINISTRATOR\` permission`,
              timestamp: new Date(),
            },
          ],
        })
                      let embed = new MessageEmbed()
   .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })

            
    .setDescription('**Boost custom message**\nThese variables will be replaced in the message.\n**Variables **\n> `{member_mention}`\n> `{server}`\n>  `{member_name}`\n> `{member_createdAt}`\n> `{member_pfp}`\n> `{member_tag}`\n> `{member_id}`\n> `{server_boosts}`\n> `{server_boosters}`\n> `{server_id}`\n> `{server_membercount}`\n> `{server_icon}`\nJSON-embeds are what you need to use to make **freso** send embeds instead of plain texts. You can get a json-embed code at [**message.style**](https://message.style/). You can then copy and paste the given json code in the fields that say "JSON Embeds supported" we also support buttons in the JSON.')
 
   .setColor(`${Color}`)
    .setTimestamp();
    
        interaction.followUp({ embeds: [embed],  });
                }
          if (interaction.options.getSubcommand() === "toggle") {
       
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`ADMINISTRATOR\` permission`,
              timestamp: new Date(),
            },
          ],
        })
let f = await DB.findOne({
  GuildID: interaction.guild.id,
})
          if(!f) {  
            interaction.followUp({ embeds: [new MessageEmbed()
                                                    .setDescription(`${interaction.user}: enabled the boost loggings system.`).setColor(Color)]})
                new DB({
GuildID: interaction.guild.id,
}).save()

                 }
          if(f) {
            interaction.followUp({
              embeds: [new MessageEmbed()
                      .setColor(Color)
                      .setDescription(`👍🏾 Disabled the boost loggings system.`)]
            })
            await DB.deleteMany({
              GuildID: interaction.guild.id,
            })
          }
        }
           if (interaction.options.getSubcommand() === "show") {
       
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`ADMINISTRATOR\` permission`,
              timestamp: new Date(),
            },
          ],
        })
let f = await DB.findOne({
  GuildID: interaction.guild.id,
})
          if(!f) return interaction.followUp({ embeds: [new MessageEmbed()
                     .setDescription(`${interaction.user}: you need to toggle boost loggings before using this command.`).setColor(Color)]});
    if(!f.Message && !f.Channel) return interaction.followUp({ embeds: [new MessageEmbed()
                     .setDescription(`${interaction.user}:  you need to setup the boost message and the channel.`).setColor(Color)]})
   if(!f.Message) return interaction.followUp({ embeds: [new MessageEmbed()
                     .setDescription(`${interaction.user}:  you need to setup the boost message.`).setColor(Color)]})
   if(!f.Channel) return interaction.followUp({ embeds: [new MessageEmbed()
                     .setDescription(`${interaction.user}: you need to setup the boost channel.`).setColor(Color)]})


let c = `<#${f.Channel}>` || `:x:`;
     let msg = f.Message;
let state = f.Message || ":x:"
if(!state) state = `:x:`;

           if(msg.startsWith("{") && msg.endsWith("}")){
 msg = msg.replaceAll(
       "{server_icon}",
       `${interaction.guild?.iconURL({dynamic:true})}`
     );
 msg = msg.replaceAll(
       "{member_pfp}",
       `${interaction.user.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{footer_member_pfp}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{thumbnail_member_pfp}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
msg = msg.replace(
       "{author_member_pfp}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{footer_server_icon}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{thumbnail_server_icon}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
msg = msg.replace(
       "{author_server_icon}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );

interaction.followUp({
        embeds: [new MessageEmbed()
                .setTitle(`Boost Log Settings`)
                .setDescription(`**Configurations**:\n> **State**: <:check:1002045865512407170>\n> **Channel**: ${c}\n**Message**: (Shown Below)`)] })
let e = JSON.parse(msg)
return interaction.channel.send(e).catch(err => interaction.channel.send(`${err}`))
}
      interaction.followUp({
        embeds: [new MessageEmbed()
                .setTitle(`Boost Log Settings`)
                .setDescription(`**Configurations**:\n> **State**: <:check:1002045865512407170>\n> **Channel**: ${c}\n**Message**: ${state}`)]
      }).catch(e => interaction.followUp({ embeds: [new MessageEmbed()
                .setTitle(`Boost Log Settings`)
                .setDescription(`**Configurations**:\n> **State**: <:check:1002045865512407170>\n> **Channel**: ${c}\n**Message**: enabled (to big to display)`)]
        
      }))
        }
         
            if (interaction.options.getSubcommand() === "message") {
       
              if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`ADMINISTRATOR\` permission`,
              timestamp: new Date(),
            },
          ],
        })
let f = await DB.findOne({
  GuildID: interaction.guild.id,
})
          if(!f) return interaction.followUp({ embeds: [new MessageEmbed()
                                                    .setDescription(`${interaction.user}:  you need to toggle boost loggings before using this command.`).setColor(Color)]})

          if(f) {
            let msg = interaction.options.getString(`input`);
            let ms1 = interaction.options.getString(`input`);
           if(msg.startsWith("{") && msg.endsWith("}")){
 msg = msg.replaceAll(
       "{server_icon}",
       `${interaction.guild?.iconURL({dynamic:true})}`
     );
 msg = msg.replaceAll(
       "{member_pfp}",
       `${interaction.user.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{footer_member_pfp}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{thumbnail_member_pfp}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
msg = msg.replace(
       "{author_member_pfp}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{footer_server_icon}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
 msg = msg.replace(
       "{thumbnail_server_icon}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );
msg = msg.replace(
       "{author_server_icon}",
       `${interaction.user?.displayAvatarURL({dynamic:true})}`
     );

  interaction.followUp({ 
              embeds: [new MessageEmbed()
                      .setColor(Color)
                      .setDescription(`${interaction.user}: Boost loggings setting updated.`)]
  })
let embed = JSON.parse(msg);
interaction.channel.send(embed).catch(e => {

interaction.channel.send(`${e}`)


});
            return   await  DB.findOneAndUpdate({ GuildID: interaction.guild.id }, {   Message: ms1 }, { new: true, upsert: true }).catch((err) => console.log(err));      
           }
       
            interaction.followUp({ 
              embeds: [new MessageEmbed()
                      .setColor(Color)
                      .setDescription(`${interaction.user}: Boost loggings setting updated.`)]
            })
           await DB.findOneAndUpdate({ GuildID: interaction.guild.id }, {   Message: msg }, { new: true, upsert: true }).catch((err) => console.log(err));      
    

          }
        }
         
        if (interaction.options.getSubcommand() === "channel") {
       
          if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.followUp({ ephemeral: true,
          embeds: [
            {
              color: 0x2f3136,
              author: {
                name: `${interaction.user.tag}`,
                icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

              },
              // footer: { icon_url: client.user.displayAvatarURL() },
              footer: {
                text: `${client.user.username}`,
                icon_url: `${client.user.displayAvatarURL()}`,
              },

              description: `You're missing the \`ADMINISTRATOR\` permission`,
              timestamp: new Date(),
            },
          ],
        })
let f = await DB.findOne({
  GuildID: interaction.guild.id,
})
          if(!f) return interaction.followUp({ embeds: [new MessageEmbed()
                                                    .setDescription(`${interaction.user}: you need to toggle boost loggings before using this command.`).setColor(Color)]})

          if(f) {
            interaction.followUp({
              embeds: [new MessageEmbed()
                      .setColor(Color)
                      .setDescription(`${interaction.user}: Sucessfully set the boost loggings channel as: ${interaction.options.getChannel(`channel`)}.`)]
            })
      await  DB.findOneAndUpdate({ GuildID: interaction.guild.id }, {   Channel: interaction.options.getChannel(`channel`).id }, { new: true, upsert: true }).catch((err) => console.log(err));          }
        }
         

  
            
        
        }
      
      
}
