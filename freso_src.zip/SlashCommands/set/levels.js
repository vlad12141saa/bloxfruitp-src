const { Color } = require("../../config.json");
const { ApplicationCommandType, PermissionsBitField, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;
const emoji = require("../../emoji.json") 
const db = require("quick.db")
const Discord = require('discord.js')
let DB = require(`../../database/guildData/welc`)
module.exports = {
    name: 'levels',
type: ApplicationCommandType.ChatInput,
    description: "Level system.",
    options: [
        {
            name: 'create-reward',
            description: 'Create a reward for levels.',
                type: ApplicationCommandOptionType.Subcommand,
          options: [
  {
    name: "level",
    description: "Level which should have the reward?",
        type: ApplicationCommandOptionType.Number,
    required: true
  },
  {
    name: "role",
    description: "Role which should be rewarded to user on level.",
        type: ApplicationCommandOptionType.Role,
    required: true
  }
],
        },
        {
          name: 'delete-reward',
          description: 'Delete a reward for levels.',
              type: ApplicationCommandOptionType.Subcommand,
        options: [
{
  name: "level",
  description: "Level whcih should have the reward removed?",
      type: ApplicationCommandOptionType.Number,
  required: true
},
],
      },
      {
        name: 'rewards-list',
        description: 'Lists all reward roles found',
            type: ApplicationCommandOptionType.Subcommand,
    },
      {
        name: 'annoucement-message',
        description: 'Set the message when a user levels up.',
            type: ApplicationCommandOptionType.Subcommand,
      options: [
{
name: "message",
description: "Example: GG you've leveled up?",
    type: ApplicationCommandOptionType.String,
required: true
},
],
    },
    {
      name: 'help',
      description: 'Helps with th setup proccess for level config.',
          type: ApplicationCommandOptionType.Subcommand,
        
  },
    {
      name: 'annoucement-channel',
      description: 'Set the channel where annoucements will be made..',
          type: ApplicationCommandOptionType.Subcommand,
    options: [
{
name: "channel",
description: "input",
  type: ApplicationCommandOptionType.Channel,
required: true
},
],
  },
      {
        name: 'leaderboard',
        description: 'See the leaderboard for levels.',
            type: ApplicationCommandOptionType.Subcommand,
    },
    {
      name: 'toggle',
      description: 'Toggles the level system.',
          type: ApplicationCommandOptionType.Subcommand,
  },
  {
    name: 'userdm-toggle',
    description: 'Toggles the level system to dm user when leveled up or not.',
        type: ApplicationCommandOptionType.Subcommand,
},
{
  name: 'annoucements-toggle',
  description: 'Toggle the bot to send annoucements on level ups',
      type: ApplicationCommandOptionType.Subcommand,
      
},
{
  name: 'resetall',
  description: 'Reset all levels in the server.',
      type: ApplicationCommandOptionType.Subcommand,
      
},
{
  name: 'reset',
  description: 'Reset a users level',
      type: ApplicationCommandOptionType.Subcommand,
options: [
{
name: "user",
description: "input",
type: ApplicationCommandOptionType.User,
required: true
},
],
},
    ],
    run: async(client, interaction, args) => {
      let message = interaction;
let guild = interaction.guild;
await interaction.deferReply();

if (interaction.options.getSubcommand() === "leaderboard") {
  const Schema = require("../../database/guildData/levels");
  const rawLeaderboard = await Schema.find({ guildID: interaction.guild.id }).sort(([['xp', 'descending']])).exec();
  let embed = new MessageEmbed()

 .setDescription(`${emoji.error} No data was found or the system has not been toggled on.`)
  .setColor(`${Color}`)
  
  if (!rawLeaderboard) return interaction.followUp({ embeds: [embed]})
  if(!await Schema.findOne({ Guild: interaction.guild.id, Levels: true })) {
    return interaction.followUp({ embeds: [embed]})
  }

  const lb = rawLeaderboard.map(e => `**${rawLeaderboard.findIndex(i => i.guildID === interaction.guild.id && i.userID === e.userID) + 1}** | <@!${e.userID}> - Level: \`${e.level.toLocaleString()}\` (${e.xp.toLocaleString()} xp)`);
let title = `・Levels - ${interaction.guild.name}`

  interaction.followUp({ embeds: [await client.generateEmbed(0, 0, lb, title, interaction)], fetchReply: true }).then(async msg => {
    if (lb.length <= 10) return;

    let button1 = new Discord.ButtonBuilder()
        .setCustomId('back_button')
        .setEmoji('⬅️')
        .setStyle(Discord.ButtonStyle.Primary)
        .setDisabled(true);

    let button2 = new Discord.ButtonBuilder()
        .setCustomId('forward_button')
        .setEmoji('➡️')
        .setStyle(Discord.ButtonStyle.Primary);

    let row = new Discord.ActionRowBuilder()
        .addComponents(button1, button2);

    msg.edit({ embeds: [await client.generateEmbed(0, 0, lb, title, interaction)], components: [row] })

    let currentIndex = 0;
    const collector = interaction.channel.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, time: 60000 });

    collector.on('collect', async (btn) => {
        if (btn.user.id == interaction.user.id && btn.message.id == msg.id) {
            btn.customId === "back_button" ? currentIndex -= 10 : currentIndex += 10;

            let btn1 = new Discord.ButtonBuilder()
                .setCustomId('back_button')
                .setEmoji('⬅️')
                .setStyle(Discord.ButtonStyle.Primary)
                .setDisabled(true);

            let btn2 = new Discord.ButtonBuilder()
                .setCustomId('forward_button')
                .setEmoji('➡️')
                .setStyle(Discord.ButtonStyle.Primary)
                .setDisabled(true);

            if (currentIndex !== 0) btn1.setDisabled(false);
            if (currentIndex + 10 < lb.length) btn2.setDisabled(false);

            let row2 = new Discord.ActionRowBuilder()
                .addComponents(btn1, btn2);

            msg.edit({ embeds: [await client.generateEmbed(currentIndex, currentIndex, lb, title, interaction)], components: [row2] });
            btn.deferUpdate();
        }
    })

    collector.on('end', async (btn) => {
        let btn1Disable = new Discord.ButtonBuilder()
            .setCustomId('back_button')
            .setEmoji('⬅️')
            .setStyle(Discord.ButtonStyle.Primary)
            .setDisabled(true);

        let btn2Disable = new Discord.ButtonBuilder()
            .setCustomId('forward_button')
            .setEmoji('➡️')
            .setStyle(Discord.ButtonStyle.Primary)
            .setDisabled(true);

        let rowDisable = new Discord.ActionRowBuilder()
            .addComponents(btn1Disable, btn2Disable);

        msg.edit({ embeds: [await client.generateEmbed(currentIndex, currentIndex, lb, title, interaction)], components: [rowDisable] });
    })
})

} else { 
if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
return message.followUp({ ephemeral: true,
  embeds: [
    {
      color: 0x2f3136,
      author: {
        name: `${interaction.user.tag}`,
        icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

      },
      // footer: { icon_url: client.user.displayAvatarURL() },
      footer: {
        text: `${client.user.username}`,
        icon_url: `${client.user.displayAvatarURL()}`,
      },

      description: `${emoji.error} You're missing the \`ADMINISTRATOR\` permission`,
      timestamp: new Date(),
    },
  ],
})

                    if (interaction.options.getSubcommand() === "create-reward") {
                      const Schema = require("../../database/guildData/levelrewards");
                      let level = interaction.options.getNumber('level');
                      let role = interaction.options.getRole('role');

                      let embed = new MessageEmbed()
   

.setColor(`${Color}`)
    
        Schema.findOne({ Guild: interaction.guild.id, Level: level }, async (err, data) => {
        if (data) {
          embed.setDescription(`${emoji.error} level already has a reward set on it.`)
          interaction.followUp({ embeds: [embed]})
        }
        else {
            new Schema({
                Guild: interaction.guild.id,
                Level: level,
                Role: role.id
            }).save();
            embed.setDescription(`${emoji.success} users will be rewarded ${role} when they reach **Level ${level}**.`)
interaction.followUp({ embeds: [embed]})
        }
    })
                }
                if (interaction.options.getSubcommand() === "delete-reward") {
                  const Schema = require("../../database/guildData/levelrewards");
                  let level = interaction.options.getNumber('level');
                  let role = interaction.options.getRole('role');

                  let embed = new MessageEmbed()


.setColor(`${Color}`)

    Schema.findOne({ Guild: interaction.guild.id, Level: level }, async (err, data) => {
    if (data) {
      Schema.findOneAndDelete({ Guild: interaction.guild.id, Level: level }).then(() => {
      embed.setDescription(`${emoji.error} level already has a reward set on it.`)
      interaction.followUp({ embeds: [embed]})
      })
     } else {
       
        embed.setDescription(`${emoji.error} no level reward was found for **Level ${level}**`)
interaction.followUp({ embeds: [embed]})
    }
  })
                }
                if (interaction.options.getSubcommand() === "rewards-list") {
                  const Schema = require("../../database/guildData/levelrewards");
                  function top(index) {
                    return index === 1 ? '🥇' : index === 2 ? '🥈' : index === 3 ? '🥉' : index < 10 ? String(`0${index}`) : index;
                  }

                  let embed = new MessageEmbed()
.setColor(`${Color}`)
let msg;
const backId = 'back'
const forwardId = 'forward'
const backButton = new ButtonBuilder({
style: ButtonStyle.Primary,
label: 'Back',

customId: backId
})
const forwardButton = new ButtonBuilder({
style: ButtonStyle.Primary,
label: 'Forward',

customId: forwardId
});

let Database = await Schema.find({ 
GuildID: message.guild.id })
.exec(async (err, res) => {
let g = interaction.guild;
//if database not found
if (!res || !res.length) { 


return interaction.followUp(`${emoji.error} No reward roles were found.`)

} 

let array = [];


for (i = 0; i < res.length; i++) {
array.push(`\`${top(i + 1)}. \` Level: ${res[i].Level} • <@&${res[i].Role}>.`);


}
const interval = 10;



const range = (array.length == 1) ? '[1]' : `[1 - ${array.length}]`;
let guilds = array;
const generateEmbed = async start => {
const current = array.slice(start, start + 10)

// You can of course customise this embed however you want
return new EmbedBuilder({
author: { 
name: `${g.name}`,
iconURL: g?.iconURL({dyanmic: true}),
},
thumbnail: {
url: g?.iconURL({ size: 4096, dyanmic: true}),

},
title: `Reward Roles ${start + 1}-${start + current.length} out of ${
guilds.length
}`,
description: `${current.join(`\n`)}`,

color: 0x2e3135,
})
};

// Send the embed with the first 10 guilds
const canFitOnOnePage = guilds.length <= 10
const embedMessage = await interaction.followUp({
embeds: [await generateEmbed(0)],
components: canFitOnOnePage
? []
: [new MessageActionRow({components: [forwardButton]})]
})
// Exit if there is only one page of guilds (no need for all of this)
if (canFitOnOnePage) return;

// Collect button interactions (when a user clicks a button),
// but only when the button as clicked by the original message author
const collector = embedMessage.createMessageComponentCollector({
filter: ({user}) => user.id === interaction.user.id
})

let currentIndex = 0
collector.on('collect', async interaction => {
// Increase/decrease index
interaction.customId === backId ? (currentIndex -= 10) : (currentIndex += 10)
// Respond to interaction by updating message with new embed
await interaction.update({
embeds: [await generateEmbed(currentIndex)],
components: [
new MessageActionRow({
components: [
// back button if it isn't the start
...(currentIndex ? [backButton] : []),
// forward button if it isn't the end
...(currentIndex + 10 < guilds.length ? [forwardButton] : [])
]
})
]
})

})
              
})
    
          }
              
           if (interaction.options.getSubcommand() === "toggle") {
            const Schema = require("../../database/guildData/functions");
            let embed = new MessageEmbed()
   

            .setColor(`${Color}`)
            Schema.findOne({ Guild: interaction.guild.id, Levels: true }, async (err, data) => {
              if (data) {
                Schema.findOneAndDelete({ Guild: interaction.guild.id, }).then(() => {
                embed.setDescription(`${emoji.success} disabled the level system.`)
                interaction.followUp({ embeds: [embed]})
                })
               } else {
               new Schema({ 
                Guild: interaction.guild.id,
              Levels: true }).save();
                  embed.setDescription(`${emoji.success} level system has been enabled.`)
          interaction.followUp({ embeds: [embed]})
              }
            })
           }
           if (interaction.options.getSubcommand() === "userdm-toggle") {
            const Schema = require("../../database/guildData/functions");
            let embed = new MessageEmbed()
   

            .setColor(`${Color}`)
            Schema.findOne({ Guild: interaction.guild.id, Levels: true }, async (err, data) => {
              if (!data) {
                embed.setDescription(`${emoji.error} the level system has not been toggled.`)
               return interaction.followUp({ embeds: [embed]})
               } else {
                if(!data.LevelDM || data.LevelDM === false) { 
                  data.LevelDM = true;
                  data.save().catch(err => console.error(err));
                  embed.setDescription(`${emoji.success} **user dm** annoucements have been toggled.`)
          interaction.followUp({ embeds: [embed]})
            } else {
              if(data.LevelDM === true) { 
                data.LevelDM = false;
                data.save().catch(err => console.error(err));
                      embed.setDescription(`${emoji.success} **user dm** annoucements have been toggled off.`)
              interaction.followUp({ embeds: [embed]})
            }
          }
              }
            })
           }
           if (interaction.options.getSubcommand() === "annoucements-toggle") {
            const Schema = require("../../database/guildData/functions");
            let embed = new MessageEmbed()
   

            .setColor(`${Color}`)
            Schema.findOne({ Guild: interaction.guild.id, Levels: true }, async (err, data) => {
              if (!data) {
                embed.setDescription(`${emoji.error} the level system has not been toggled.`)
                interaction.followUp({ embeds: [embed]})
               } else {
                if(!data.LevelAnnouce || data.LevelAnnouce === false) { 
                  data.LevelAnnouce = true;
                  data.save().catch(err => console.error(err));
  
                  embed.setDescription(`${emoji.success}  annoucements have been enabled.`)
          interaction.followUp({ embeds: [embed]})
            } else {
              if(data.LevelAnnouce === true) { 
                data.LevelAnnouce = false;
                  data.save().catch(err => console.error(err));
                      embed.setDescription(`${emoji.success} anoucements has been toggled off.`)
              interaction.followUp({ embeds: [embed]})
            }
          }
              }
            })
           }
           if (interaction.options.getSubcommand() === "help") {
            const Leval = require("../../database/guildData/functions");
           let settings = await Leval.findOne({ Guild: message.guild.id });
            const messageSchema = require("../../database/guildData/levelmessages");
            const levelRewards = require("../../database/guildData/levelrewards");
            const levelLogs = require("../../database/guildData/levelchannels");
            const levelData = await levelLogs.findOne({
              Guild: message.guild.id,
            });
            const messageData = await messageSchema.findOne({
              Guild: message.guild.id,
            });
            let enabled = false;
            if(settings && settings.Levels === true) {
           enabled = true;
            }
            let annoucements = false;
            if(settings && settings.LevelAnnouce === true) {
              annoucements = true;
               }
               let dms = false;
               if(settings && settings.LevelDM === true) {
                 dms = true;
                  }
                  let channel = `Not found`
                  if(levelData && levelData.Channel) {
                    channel = `<#${levelData.Channel}>`;
                     }
              
            if(messageData && messageData.Message && messageData.Message.startsWith("{") && messageData.Message.endsWith("}")){
              let message = false;
              let msg = messageData.Message;
              if(messageData && messageData.Message) {
                message = true;
                msg = msg.replaceAll(
                  "{server_icon}",
                  `${interaction.guild?.iconURL({dynamic:true})}`
                );
            msg = msg.replaceAll(
                  "{member_pfp}",
                  `${interaction.user.displayAvatarURL({dynamic:true})}`
                );
                 }
            let embed = new MessageEmbed()
            .setColor(`${Color}`)
            .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL({})})
            .setTitle('Help Menu for the Level Configuration')
            .setDescription(`**Variables**:
            - **Message Author Variables** 
            {member_mention} = Message Author

            {member_id} = Message Authors ID

            {member_username} = Message Authors username

            {member_discriminator} = Message Authors discrim (if they have one due to the L update)

            {member_level} = Message Author's new level

            {member_xp} = Message Author's total xp

            {member_tag} = Message Authors Tag

            {member_pfp} = Message Author profile picture

            - **Server Variables**
            
            {server_icon} = ${interaction.guild.name} icon

            {server_name} = ${interaction.guild.name} server name

            {server_id} = ${interaction.guild.name} server id


            **Config**: 
            Toggle: ${enabled}
            Level Annoucements: ${annoucements}
            Channel: ${channel}
            User DMs: ${dms}
            Message: (message is a a embed, shown below)
            
            `)
            
            interaction.followUp({ embeds: [embed]})
            let emb = JSON.parse(msg);
            interaction.channel.send(emb);
            } else {
              let message = false;
              if(messageData && messageData.Message) {
                message = true;
                 }
              let embed = new MessageEmbed()
              .setColor(`${Color}`)
              .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL({})})
              .setTitle('Help Menu for the Level Configuration')
              .setDescription(`**Variables**:
              - **Message Author Variables** 

              {member_mention} = Message Author
              {member_id} = Message Authors ID
              {member_username} = Message Authors username
              {member_discriminator} = Message Authors discrim (if they have one due to the L update)
              {member_level} = Message Author's new level
              {member_xp} = Message Author's total xp
              {member_tag} = Message Authors Tag
              {member_pfp} = Message Author profile picture
  
              - **Server Variables**

              {server_icon} = ${interaction.guild.name} icon\n{server_name} = ${interaction.guild.name} server name\n{server_id} = ${interaction.guild.name} server id
  
  
             -  Config: 
              Toggle: ${enabled}
              Level Annoucements: ${annoucements}
              Channel: ${channel}
              User DMs: ${dms}
              Message: ${message}
              
              - Note: JSON embeds are supported, can get the JSON embeds off [https://message.style/app/](https://message.style/app/)
              `)
              
              interaction.followUp({ embeds: [embed]})
       
            }
          } 
           if (interaction.options.getSubcommand() === "annoucement-channel") {
            const Schema = require("../../database/guildData/levelchannels");
            let embed = new MessageEmbed()
            .setColor(`${Color}`)
            let find = await  Schema.findOne({ 
              Guild: interaction.guild.id,
           });
if(find) { 

            await  Schema.findOneAndUpdate({ 
              Guild: interaction.guild.id,
            Channel: interaction.options.getChannel('channel').id,
           }).then(() => {
            embed.setDescription(`${emoji.success} the level annoucements have been updated to ${interaction.options.getChannel('channel')}.`)
            interaction.followUp({ embeds: [embed]})
           })
          } else {
           new Schema({ 
              Guild: interaction.guild.id,
            Channel: interaction.options.getChannel('channel').id,
           }).save();
           embed.setDescription(`${emoji.success} the level annoucements have been set to ${interaction.options.getChannel('channel')}.`)
           interaction.followUp({ embeds: [embed]})
          }
           }
           if (interaction.options.getSubcommand() === "resetall") {
            const levels = require("../../database/guildData/levels");
            const r1 = new ActionRowBuilder().addComponents(
              new MessageButton()
              .setLabel("Yes")
   
              .setStyle(ButtonStyle.Success)
              .setCustomId("yes"),
              new MessageButton()
              .setLabel("No")
            
              .setStyle(ButtonStyle.Danger)
              .setCustomId("no")
          );
  
    const e1 = new EmbedBuilder()
  
          .setDescription(`Are sure to about this action, we can not recover data after removing?`)
          .setColor(Color)
            interaction.followUp({
              embeds: [e1],
              components: [r1],
          });
                             
  const filter = i => i.user.id === interaction.user.id;
          const collector = interaction.channel.createMessageComponentCollector({
               filter, 
               time: 60000 
              });
          collector.on("collect", async i => {
              if(i.customId === "yes") {
                
               interaction.editReply({ content: `${emoji.success} data has been cleared and is non-restoreable.`, embeds:[], components: [], })

return  await   levels.deleteMany({ guildID: interaction.guild.id, });
              }
            if(i.customId == `no`) {
         return     i.message.delete();
            }
          })
           }
           if (interaction.options.getSubcommand() === "reset") {
            const levels = require("../../database/guildData/levels");
            let user = interaction.options.getMember('user');

            const r1 = new ActionRowBuilder().addComponents(
              new MessageButton()
              .setLabel("Yes")
   
              .setStyle(ButtonStyle.Success)
              .setCustomId("yes"),
              new MessageButton()
              .setLabel("No")
            
              .setStyle(ButtonStyle.Danger)
              .setCustomId("no")
          );
  
    const e1 = new EmbedBuilder()
  
          .setDescription(`Are sure to about this action, we can not recover data after removing ${user} data?`)
          .setColor(Color)
            interaction.followUp({
              embeds: [e1],
              components: [r1],
          });
                             
  const filter = i => i.user.id === interaction.user.id;
          const collector = interaction.channel.createMessageComponentCollector({
               filter, 
               time: 60000 
              });
          collector.on("collect", async i => {
              if(i.customId === "yes") {
                
                interaction.editReply({ content: `${emoji.success}  ${user}'s level data has been deleted.`, embeds:[], components: [], })

return  await   levels.deleteMany(
        { guildID: message.guild.id,
          userID: user.id,
        }
      );
              }
            if(i.customId == `no`) {
         return     i.message.delete();
            }
          })
           }
           if (interaction.options.getSubcommand() === "annoucement-message") {
            const Schema = require("../../database/guildData/levelmessages");
            let msg = interaction.options.getString('message');
            let embed = new MessageEmbed()
            .setColor(`${Color}`)
            let find = await  Schema.findOne({ 
              Guild: interaction.guild.id,
           });
if(find) { 
            await  Schema.findOneAndUpdate({ 
              Guild: interaction.guild.id,
            Message: interaction.options.getString('message'),
           }).then(() => {
            if(msg.startsWith("{") && msg.endsWith("}")){
              msg = msg.replaceAll(
                    "{server_icon}",
                    `${interaction.guild?.iconURL({dynamic:true})}`
                  );
              msg = msg.replaceAll(
                    "{member_pfp}",
                    `${interaction.user.displayAvatarURL({dynamic:true})}`
                  );
             let e = JSON.parse(msg)
              interaction.channel.send(e);
             }

            embed.setDescription(`${emoji.success} edited the annoucement message.`)
            interaction.followUp({ embeds: [embed]})
           })
          } else {
            new Schema({ 
              Guild: interaction.guild.id,
            Message: interaction.options.getString('message'),
           }).save();
           embed.setDescription(`${emoji.success} the annoucement message has been set.`)
           interaction.followUp({ embeds: [embed]})
          }
           }
              }
      
            }
}
