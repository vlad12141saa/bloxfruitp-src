const { ApplicationCommandType, PermissionsBitField, ApplicationCommandOptionType, ActionRowBuilder, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const Discord = require("discord.js")
const { QuickDB } = require("quick.db");
const db = new QuickDB();
const ms = require("ms");
const { truncate } = require("fs");
const emoji = require("../../emoji.json") 
    const Topgg = require("@top-gg/sdk")
const api = new 
  Topgg.Api('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjkxODM2MTE0NDUzNDYzODYxMyIsImJvdCI6dHJ1ZSwiaWF0IjoxNjQ1NzQ5NjczfQ._imsUSXfNNTHEYD5j3yhQOanaIXRRQa7CN7VIgzklfA') 
    const wait = require('util').promisify(setTimeout);
    const { Color } = require("../../config.json");
    const greet = require(`../../database/guildData/greet.js`)
module.exports = {
	name: 'pingonjoin',
	aliases: ["a-con"],
type: ApplicationCommandType.ChatInput,
	category: "Anti-alt",
	description: "Config ping on join.",
	usage: "alt-config",
    options: [
        {
            name: 'toggle',
          
            description: 'Add a channel to the ping on join.',
         type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'channel',
                      required: false,
                    description: 'Channel to add to the ping on join.',
                   type: ApplicationCommandOptionType.Channel,
                }
            ],
        },
        {
            name: 'webhook',
            description: 'Set a custom webhook name and avatar for the ping on join.',
             type: ApplicationCommandOptionType.Subcommand,
           
        },
   {
            name: 'list',
            description: 'View all the multi ping on join channels.',
               type: ApplicationCommandOptionType.Subcommand,
           
        },
       {
            name: 'message',
            description: 'Config message for multi ping on join.',
           type: ApplicationCommandOptionType.Subcommand,          
        },
       {
            name: 'deletion',
            description: 'Config second(s) of deletions for ping on join greetings.',
            type: ApplicationCommandOptionType.Subcommand,
           
           options: [
                {
                    name: 'seconds',
                      required: true,
                    description: 'Seconds after I delete a ping on join',
                   type: ApplicationCommandOptionType.Number,
                }
        
            ],
        },
    ],
	run: async (client, interaction, args) => {
    let message = interaction;
let member = interaction;
      const emed1 = new MessageEmbed()
   
      .setDescription(`${emoji.error} You're missing the **MANAGE_GUILD** permission.`)
         .setColor(Color)
   .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })

            
             .setTimestamp();
         if (interaction.options.getSubcommand() === "list") {
          		if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
			return    interaction.reply({
        ephemeral: true, embeds:[emed1]
      })
           await interaction.deferReply()
        let array = []
	message.guild.channels.cache.forEach(async (channel) => {
if(await greet.findOne({
  GuildID: message.guild.id,
  ChannelID: channel.id
})) {
array.push(`${channel}`)
}

  });

    await wait(2000)
  
    let embed = new MessageEmbed()

     .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })
     .setColor(Color)
     .setThumbnail(interaction.guild.iconURL({dynamic:true} || null))

     embed.setDescription(`**ping-on-join Channels**: ${array.join(" , ")}\n**Amount**: Currently ${array.length} ping-on-join channels.`)

      
      embed.setTimestamp();
        interaction.followUp({embeds: [embed] })

         }
        if (interaction.options.getSubcommand() === "message") {
          if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels))
    return message.reply({ 
        ephemeral: true,
      embeds: [
        {
  color: 0x2f3136,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `You're missing the \`MANAGE_CHANNELS\` permission`,
          timestamp: new Date(),
        },
      ],
    })
     
    const messageRaw = interaction.options.getString('message') 

    let embed = new MessageEmbed()
       
         .setAuthor({ name: `${interaction.user.tag}}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })

    .setDescription('**Greet custom message**\nThese variables will be replaced in the message.\n**Default Message**\n> Welcome {member_mention} to \`{server}\`. \n**Variables\n**`{server_name}`\n `{member_mention}`\n `{server_id}`\n `{server_count}`  ')
 .setColor(Color)
    .setTimestamp();
         const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
        .setCustomId("greet-message")
					.setLabel('Greet Message')
					.setStyle(ButtonStyle.Danger),
                  new MessageButton()
        .setCustomId("resetgreet-message")
					.setLabel('Default Greet Message')
					.setStyle(ButtonStyle.Primary),)
    if (!messageRaw)
interaction.reply({ components: [row], content: `**${interaction.user}**.`, embeds: [embed] })
   let msg = await message.fetchReply();
       let filter = (m) => m.user.id === interaction.user.id;
          let collector = msg.createMessageComponentCollector({
            filter,
            type: "BUTTON",
            time: 60000
          });

          collector.on("collect", async (button) => {
            const b = button;
            if (button.customId && button.customId === "greet-message") {
          b.deferUpdate()
              b.channel.send({ content: `${emoji.success} ${interaction.user}: Please provide the message to add?`})
                 let filter = (m) => interaction.user.id === m.author.id;
              let dd = button.channel.createMessageCollector({
                filter,
                time: 30000,
                max: 1
              });
              
              dd.on("collect", async (m) => {
                msg.edit({  embeds:[new EmbedBuilder()
                  .setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })
                .setColor(Color)
                .setThumbnail(interaction.guild.iconURL({dynamic:true} || null))
                .setDescription(`**Message**:\n${m.content}`)
              ]})
               await db.set(
      `WM-${interaction.guild.id}`, m.content
    );

              })

            }
                     if (button.customId && button.customId === "resetgreet-message") {
              b.deferUpdate()
    
               await db.set(
      `WM-${interaction.guild.id}`, `Welcome {member_mention} to \`{server}\``
    );
              msg.edit({ content: `${emoji.success} Reseted the greet message to default`})

            }
          })


    if (messageRaw.length > 1000)
      return interaction.reply({
      embeds: [
        {
  color: 0x2f3136,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} That message is way to long, please shorten it.`,
          timestamp: new Date(),
        },
      ],
      })

  
    await db.set(
      `WM-${interaction.guild.id}`,
      messageRaw
    );
//   .setAuthor(`${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
  interaction.reply({
    content: `${emoji.success} **ping-on-join** message set.`,
      embeds: [
        {
  color: 0x2f3136,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${messageRaw}`,
          timestamp: new Date(),
        },
      ],
    })
        }
    
      if (interaction.options.getSubcommand() === "deletion") {
    let timedel = interaction.options.getNumber('seconds');
        
     if (timedel == '0' ) {  
      
       let embed1 = new MessageEmbed()
.setColor(Color)
 .setAuthor({ name: `${interaction.user.tag}}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })
     .setDescription(`You can not set the greet deletion to 0 seconds :skull:`)
      .setTimestamp();
  return interaction.reply({ embeds: [embed1] });
      
     
// db.set(`time_${interaction.guild.id}`, `wtf`)
     }
  let tick = timedel * 1000

    let embed = new MessageEmbed()
.setColor(Color)
  .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })
     .setDescription(`${emoji.success} Greet messages will be deleted after **${timedel}**  seconds!`)
      .setTimestamp();
  interaction.reply({ embeds: [embed] });
  // db.get(`time_${member.guild.id}`);
 await db.set(`time_${interaction.guild.id}`, `${tick}`);

      }
      if (interaction.options.getSubcommand() === "toggle") {
          		if (!message.member.permissions.has('MANAGE_GUILD'))
			return    interaction.reply({
        ephemeral: true, embeds:[emed1]
      })
    const channel = interaction.options.getChannel('channel') || interaction.channel;
           let find = await greet.findOne({
     GuildID: interaction.guild.id,
     ChannelID: channel.id,
   });
 

    if(find) { 
        let embed2 = new MessageEmbed()
   .setColor(Color)
     .setDescription(`${emoji.error} ping-on-join is now removed from <#${find.ChannelID}>`)
.setAuthor({ name: `${interaction.user.username}`, iconURL: `${interaction.user?.displayAvatarURL({dynamic: true})}` })

    	
		    interaction.reply({ embeds: [embed2] }); 
            return   await greet.findOneAndRemove({
                GuildID: interaction.guild.id,
                 ChannelID: channel.id,
            });
      
    }
    
    
            let eee = new greet({
     GuildID: interaction.guild.id,
     ChannelID: channel.id
   }).save();
  
     const r = new MessageActionRow()
			.addComponents(new MessageButton()
          .setCustomId(`view`)
                     .setLabel(`ping-on-join channel(s)`)
          .setStyle(ButtonStyle.Secondary));
   interaction.reply({ components: [r], embeds: [new MessageEmbed()

                 .setColor(Color)
.setDescription(
`${emoji.success} will now ping-on-join on \`${channel.name}\``)
], 
  
          })
       let array = []

 let msg = await interaction.fetchReply()
    let filter = (m) => m.user.id === interaction.user.id
					let collector = msg.createMessageComponentCollector({
						filter,
            type: `BUTTON`,
						time: 260000
					})
    	message.guild.channels.cache.forEach(async (channel) => {
if(await greet.findOne({
     GuildID: interaction.guild.id,
     ChannelID: channel.id,
   })) {
array.push(`${channel}`)
}

  });
    
	collector.on('collect', async (button) => {
    let b = button;

      if (button.customId === "view") {
b.deferUpdate()
        let emb = new MessageEmbed()
        .setTitle(`ping-on-join channel(s)`)
        .setDescription(`${array.join(`, `)}`)
        .setColor(Color)
        button.message.edit({ embeds: [emb]})
      }
  })

      }
        if (interaction.options.getSubcommand() === "webhook") {
          		if (!message.member.permissions.has('MANAGE_GUILD'))
			return    interaction.reply({
        ephemeral: true, embeds:[emed1]
      })
await interaction.deferReply();
	    let one = new MessageButton()
	.setCustomId("e")
					.setLabel(`Set name of ping-on-join webhook`)
					.setStyle(ButtonStyle.Primary)
        let two = new MessageButton()
	.setCustomId("e2")
					.setLabel(`Set Avatar of ping-on-join webhook`)
					.setStyle(ButtonStyle.Primary)
            let th = new MessageButton()
	.setCustomId("e3")
					.setLabel(`Normal Mode`)
					.setStyle(ButtonStyle.Primary)
          const ee = new MessageEmbed()
          
          .setTitle(`Webhook Mode`)
          .setDescription(`Setup a custom webhook to use when ${client.user.username} ping-on-join in your server.`)
.setColor(Color)
          .setTimestamp()
         // .setThumbnail(`${interaction.guild.iconURL({dyanamic:true})}`)
      interaction.followUp({ embeds: [ee], components: [new MessageActionRow().addComponents(one, two, th)]})
  let msg = await message.fetchReply()
					let filter = (m) => m.user.id === interaction.user.id
					let collector = msg.createMessageComponentCollector({
						filter,
            type: `BUTTON`,
						time: 100000,
					})
         collector.on("end", async () => {
        await interaction.editReply({ components: [new MessageActionRow().addComponents(one.setDisabled(true), two.setDisabled(true))] }).catch(() => {});
     });
	collector.on('collect', async (button) => {
    let b = button;
      if (button.customId === "e") {
  b.deferUpdate()
 let ee = await b.channel.send(`What should the name of the webhook be?`)
        let filter = (m) =>
								(interaction ? interaction.user : message.author).id ===
								m.author.id
        	let c3 = button.channel.createMessageCollector({
										filter,
										time: 300000,
										max: 1
									})						
            c3.on('collect', async (m) => {
await db.set(`webhook${button.guild.id}`, m.content)
                            m.reply(`${emoji.success}`)
                            
                          })
        
      }
   if (button.customId === "disable") {

  await db.set(`antiraidon${message.guild.id}`, message.guild.id)
  b.reply(`${emoji.success} Updated configuration.`)
      }
  if (button.customId === "e3") {
 b.deferUpdate()

              
await db.delete(`webhook${button.guild.id}`)
await db.delete(`webhook-name${button.guild.id}`)
                           button.channel.send(`${emoji.success}`)
                            
                          
   }
   if (button.customId === "e2") {
 b.deferUpdate()
 let ee = await b.channel.send(`What should the **avatar** of the webhook be?`)
        let filter = (m) =>
								(interaction ? interaction.user : message.author).id ===
								m.author.id
        	let c3 = button.channel.createMessageCollector({
										filter,
										time: 300000,
										max: 1
									})						
            c3.on('collect', async (m) => {
              let isthumb =
									m.content.match(
										/^http[^\?]*.(jpg|jpeg|gif|png|tiff|bmp)(\?(.*))?$/gim
									) != null 
								if (!isthumb)
									return m.reply({
										content:
										`${emoji.error} This is not a valid image that I can use.`,
										ephemeral: true
									})
              
await db.set(`webhook-name${button.guild.id}`, m.content)
                            m.reply(`${emoji.success}`)
                            
                          })
   }


  })

        }	
             
              
    }
  }
    