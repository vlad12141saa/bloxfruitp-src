const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { post } = require("node-superfetch");
const { Color } = require(`../../config.json`)
const { inspect } = require("util");
module.exports = {
  name: "eval",
  description: "Eval Code",
  default_member_permissions: [],
  ownerOnly: true,
  options: [
    {
      name: "code",
      description: "Private command to evaluate a code.",
      required: true,
      type: ApplicationCommandOptionType.String,
    },
  ],

  run: async (client, interaction, prefix) => {
     let message = interaction;
let msg = interaction;
      let blacklist = [`1102905025421918251`, ``]; // Basically can blacklist users from getting a dm.
       if(!blacklist.includes(interaction.user.id)) return interaction.reply(`NO LOLLLL`) 
    const script = interaction.options.getString("code");

        let evaled;
        let hrDiff;
        try {
            const hrTime = process.hrtime();
         // evaled = await eval(`async () => { ${script} } `)()
evaled = await eval(script)
            hrDiff = process.hrtime(hrTime);
          
            await message.reply(
                `Executed in \`${hrDiff[1] / 1000000}\` ms.\n\`\`\`js\n${evaled}\n\`\`\``
            );
        } catch (error) {
            console.log(error);
            message.reply(`Error Occurred:\n\`\`\`js\n${error}\n\`\`\``);
        }
  }
}