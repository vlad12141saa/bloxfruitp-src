const Discord = module.require("discord.js");
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const { version: discordjsVersion } = require('discord.js');
const warnings = require("../../database/guildData/warnings")
const emoji = require(`../../emoji.json`);
const { Color } = require("../../config.json");
module.exports = {
  name: "warn",
type: ApplicationCommandType.ChatInput,
  category: "Moderation",
  description: "Warn a user",
  userPermissions: ["MANAGE_MESSAGES"],
     options: [
        {
            name: 'target',
            description: 'The user you want to warn',
         required: true,
             type: ApplicationCommandOptionType.User,
          
        },
        {
            name: 'reason',
            description: 'Reason for the warn',
            required: true,
           type: ApplicationCommandOptionType.String,
          
            
        }
    ],
  run: async (client, interaction, ) => {
 const db = require("quick.db")
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) 
                return interaction.reply({
      embeds: [
        {
  color: Color,
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.member.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `You're missing the \`MANAGE_MESSAGES\` permission`,
          timestamp: new Date(),
        },
      ],
          })
  
     const user = interaction.options.getMember('target');
          
 const reason = interaction.options.getString('reason') || 'n/a';

 
 let embed = new Discord.EmbedBuilder()
.setColor(`${Color}`)
     .setDescription(`I have warned ${user} for ${reason}`)
      .setTimestamp();
       let emb = new Discord.EmbedBuilder()
 .setColor(`${Color}`)
      
     .setDescription(`${user} you have been warned in ${interaction.guild.name} by ${interaction.member.user.tag} for ${reason}`)
.setTimestamp();
 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL(emoji.link)
					.setLabel('Support')
					.setStyle(ButtonStyle.Link), new MessageButton()
           	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite')
					.setStyle(ButtonStyle.Link))
user.send({ embeds: [emb], components: [row] })
      interaction.reply({   embeds: [embed] })
      new warnings({
   action: `WARN`,
userId:  user.id,
guildId:  interaction.guild.id,
moderatorId:  interaction.user.id,
reason,
timestamp: new Date(),

// msg.channel.send(``<t:${parseInt(message.timestamp / 1000 )}:F>``)


 }).save();
       let kickMember = user;
       let message = interaction;
            const embedb = new MessageEmbed()
              
                .setColor("#ff0000")
                .setThumbnail(kickMember.user.displayAvatarURL({ dynamic: true }))
                .setFooter(interaction.guild.name, interaction.guild.iconURL())
             
                          .setTimestamp();
 let channel = db.get(`modlog_${interaction.guild.id}`)
            if (!channel) return;

            var sChannel = interaction.guild.channels.cache.get(channel)
            if (!sChannel) return;
            sChannel.send({
              embeds: [embedb]
              })

  }
  
}
