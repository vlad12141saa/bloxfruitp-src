
const { Color } = require("../../config.json");

const emoji = require("../../emoji.json");
const moment = require('moment')
const db = require("quick.db")
const { ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, PermissionsBitField, SelectMenuBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require('discord.js');
let MessageActionRow = ActionRowBuilder;
let MessageEmbed = EmbedBuilder;
let MessageButton = ButtonBuilder;

const warnings = require("../../database/guildData/warnings")
module.exports = {
name: "unban",
category: "Moderation",
description: "unban a user",
cooldown: 5,
type: ApplicationCommandType.ChatInput,
userPerms: ["KICK_MEMBERS"],
clientPerms: ["KICK_MEMBERS"],  
 options: [
                {
                    name: 'user',
                      required: true,
                    description: 'Who are you unbanning a ghost?',
               type:  ApplicationCommandOptionType.String, 
                },
                 
            ],
        
  run: async (client, interaction, args) => {
    let message = interaction;
    await interaction.deferReply();
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers))
    return interaction.followUp({ ephemeral: true,
    embeds: [
    {
    color: 0x6787e7,
    author: {
    name: `${interaction.user.tag}`,
    icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,
    
    },
    // footer: { icon_url: client.user.displayAvatarURL() },
    footer: {
    text: `${client.user.username}`,
    icon_url: `${client.user.displayAvatarURL()}`,
    },
    
    description: `You're missing the \`BanMembers\` permission`,
    timestamp: new Date(),
    },
    ],
    })
          
          
   const msg = interaction;
            const userid = interaction.options.getString("user");
        const e1 = new MessageEmbed()
    
            .setDescription(`You fr (for real) want to **unban** <@${userid}> from this server?`)
         
       
            const r1 = new MessageActionRow().addComponents(
                new MessageButton()
                .setLabel("Yes")
           
                .setStyle(ButtonStyle.Primary)
                .setCustomId("yes"),
                new MessageButton()
                .setLabel("No")
             
                .setStyle(ButtonStyle.Danger)
                .setCustomId("no")
            );
            interaction.followUp({
                embeds: [e1],
                components: [r1],
            });
            const filter = i => i.user.id === interaction.user.id;
            const collector = interaction.channel.createMessageComponentCollector({
                 filter, 
                 time: 60000 
                });
            collector.on("collect", async i => {
                if(i.customId === "no") {
                    const r2 = new MessageActionRow().addComponents(
                        new MessageButton()
                        .setLabel("Yes")
                    
                    .setStyle(ButtonStyle.Primary)
                        .setCustomId("yes")
                        .setDisabled(true),
                        new MessageButton()
                        .setLabel("No")
           
                      .setStyle(ButtonStyle.Danger)
                        .setCustomId("no")
                        .setDisabled(true)
                    );
                    i.update({
                        components: [r2]
                    });
                }
                if(i.customId === "yes") {
            interaction.guild.members.unban(userid).then((user) => {
                const e2 = new MessageEmbed()
            .setDescription(`${emoji.success} <@${userid}> has been unbanned from the server.`)
            .setColor(Color)
                       i.update({
                embeds: [e2],
                components: []
            });
            }).catch((e) => {
                const errlol = new MessageEmbed()
           
            .setDescription(`An error has occured while trying to unban that user.\n${e}`)
           .setColor(Color)
           
                i.update({
                    embeds: [errlol],
                    components: []
                });
            });
                }
            });
           
  }
}
