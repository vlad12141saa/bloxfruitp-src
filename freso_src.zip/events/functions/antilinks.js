const antilinkData = require("../../database/guildData/antilink");
const ms = require('ms')
const emoji = require("../../emoji.json") 
const { MessageActionRow, MessageEmbed, MessageSelectMenu, MessageButton } = require('discord.js');
module.exports = async (message) => {
  if(!message.guild) return;
  const antilink = await antilinkData.findOne({
    GuildID: message.guild.id,
  });
  if(!antilink) return;
  if (antilink) {
 
    if(!message.channel.permissionsFor(message.member).has("MANAGE_MESSAGES")) return;
    if (
  
      message.content.match("discord.gg/") 
    ) {
        let emb = new MessageEmbed()
 
    .setAuthor(`${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
             
     .setDescription(`${emoji.error} Links are not allowed!`)
     
.setTimestamp();
 const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL('https://discord.gg/glyphic')
					.setLabel('Support')
					.setStyle('LINK'),
)
message.channel.send({ embeds: [emb] })
  message.delete()
    
    }
  }
};