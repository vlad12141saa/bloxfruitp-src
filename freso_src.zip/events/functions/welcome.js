const welcomeData = require("../../database/guildData/welcome");
// const welcomemsg = require("../../database/guildData/joinmsg");
const { MessageEmbed } = require('discord.js')

module.exports = async (member) => {

 const data = await welcomeData.findOne({
   GuildID: member.guild.id,
 });
if(!data) return 
  let channels = [];
  if (Array.isArray(data.Welcome)) channels = data.Welcome;
  else channels.push(data.Weclome);

    //Check that every ID is a valid channelID
    for (let channelID of channels) {
      const ch = member.guild.channels.cache.get(channelID);
      if (!ch) return;
     let embed2 = new MessageEmbed
     .setTitle("**Welcome**")
      .setDescription(
        `${member}, Welcome to **${member.guild.name}**!\nEnjoy Your Stay!`
      )
      .setFooter(`We are now ${member.guild.memberCount} members`)
      .setColor("5865f2");
     
     let channel = data.Welcome

    ch.send({ embeds: [embed2] });
   }
  }
 