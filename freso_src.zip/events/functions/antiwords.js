const antiwordsData = require('../../database/guildData/antiwords')
const emoji = require("../../emoji.json");
//const ms = require(`moment`);
  module.exports = async (message) => {
    if(!message.guild) return;
    const antiwords = await antiwordsData.findOne({
      GuildID: message.guild.id,
    })
    if(!antiwords) return;
    if (antiwords) {
      
    if(!message.channel.permissionsFor(message.member).has("MANAGE_MESSAGES")) return;
      if (message.content.match("bitch") || message.content.match("hoe") || message.content.match("slut") || message.content.match("nigga") || message.content.match("nigg") || message.content.match("dick") || message.content.match("cunt") || message.content.match("shit") || message.content.match("nigger") || message.content.match("whore") || message.content.match("fuck")) {
        message.delete();
        message.reply(`${emoji.error} Please refrain from swearing in this server.`).then(msg => {
          let time = '4s'
          setTimeout(function () {
            msg.delete();
          }, 20000);
        })
      } else {
        return;
      }
    } else if (!antiwords) {
      return;
    }
  }
  