const { IntegrationApplication } = require("discord.js");
const emoji = require("../../emoji.json") 
const db = require("quick.db");
module.exports = async(interaction, client) => {
        if (!interaction.isButton()) return;
 
    let msg = await interaction.channel.messages.fetch(interaction.message.id)

     if (interaction.customId == "greet2") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission.`,
          timestamp: new Date(),
        },
      ],
          })
          
        await interaction.deferUpdate()
        
        const data = db.fetch(`greet2${interaction.guild.id}`)

        if (!data) {
            await msg.edit(`${emoji.dot} Please send the **Channel ID** to complete the setup process for 2nd greeting channel.`)

            const filter = (m) => m.author.id === interaction.user.id

            let channelID;

            const collector = await interaction.channel.createMessageCollector({ filter, time: 60000 })

            collector.on('collect', async(collected, returnValue) => {
                channelID = collected.content

                let channel = interaction.guild.channels.cache.get(channelID)

                if (!channel) return msg.edit(`${emoji.error} Couldn't find that channel!`)

                db.set(`greet2${interaction.guild.id}`, channelID)

                await collector.stop()
    
                return msg.edit(`${emoji.success} Greetings will be logged in ${interaction.guild.channels.cache.get(channelID)}`)
            })

            collector.on('end', async(collected, returnValue) => {
                console.log("Collector Stopped!")
            })

        } else if (data) {
                db.delete(`greet2${interaction.guild.id}`)

            return msg.edit(`${emoji.success} Greeting logs has been paused!`)
        }
    }
}