const welcomeData = require("../../database/guildData/boost");
const welcomemsg = require("../../database/guildData/boostmsg");
const { MessageEmbed } = require('discord.js')
const emoji = require("../../emoji.json") 
module.exports = async (member) => {

 const data = await welcomeData.findOne({
   GuildID: member.guild.id,
 });
 if (data) {
   const data2 = await welcomemsg.findOne({
     GuildID: member.guild.id,
   });
   if (data2) {
     var joinmessage = data2.JoinMsg;

     joinmessage = joinmessage.replace("{member_mention}", `${member}`);
     joinmessage = joinmessage.replace("{member_tag}", `${member.user.tag}`);
      joinmessage = joinmessage.replace("{member_id}", `${member.id}`);
            joinmessage = joinmessage.replace("{user_id}", `${member.id}`);
      joinmessage = joinmessage.replace("{user_mention}", `${member.user}`);
      joinmessage = joinmessage.replace("{user_tag}", `${member.user.tag}`);
          joinmessage = joinmessage.replace("{server_id}", `${member.guild.id}`);
     joinmessage = joinmessage.replace("{server_boosts}", `${member.guild.premiumSubscriptionCount}`);
     joinmessage = joinmessage.replace("{member_name}", `${member.user.username}`);
     joinmessage = joinmessage.replace("{server}", `${member.guild.name}`);
          joinmessage = joinmessage.replace("{guild}", `${member.guild.name}`);
     joinmessage = joinmessage.replace(
       "{server_count}",
       `${member.guild.memberCount}`
     );

     let embed = new MessageEmbed()
       .setDescription(joinmessage)
       .setColor("#2f3136")
      
  .setFooter(`${member.user.tag}`, member.user.displayAvatarURL({ dynamic: true }))

     let channel = data.Boost

     member.guild.channels.cache.get(channel).send({embeds: [embed]});
     
   } else if (!data2) {
     let embed2 = new MessageEmbed()
     .setTitle(`**${emoji.boost} __Boost Detected__**`)
      .setDescription(
        `Thanks for boosting this server ${member.user}`
      )
      .setFooter(`Thanks for boosting ${member.guild.name}`)
    .setTimestamp()
       .setColor("#2f3136")
      
     let channel = data.Boost

    member.guild.channels.cache.get(channel).send({ embeds: [embed2] });
   }
 }
};