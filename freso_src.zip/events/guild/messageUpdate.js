const messageData = require("../../database/guildData/messagelogs")
const { MessageEmbed } = require("discord.js")
const emoji = require("../../emoji.json") 
module.exports = async(oldMessage, newMessage) => {
    const data = await messageData.findOne({
        GuildID: newMessage.guild.id
    })

    if (!data) return;

    const channel = data.ChannelID

    const embed = new MessageEmbed()
    .setTitle(`${emoji.success} **Message Content Edited**`)
    .setDescription(`${emoji.dot} ${newMessage.author} edited their message in ${newMessage.channel}.`)
    .addField('Jump to Message', `[Press here](https://discord.com/channels/${newMessage.guild.id}/${newMessage.channel.id}/${newMessage.id})`)
    .addField(`**${emoji.dot} Old Message**`, `\`${oldMessage.content}\``, true)
    .addField(`${emoji.dot} **New Message**`, `\`${newMessage.content}\``, true)
    .setColor('5865f2')
    .setTimestamp()

    newMessage.guild.channels.cache.get(data.ChannelID).send({ embeds: [embed] })
}