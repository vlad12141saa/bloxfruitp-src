// ma
// wtf how  magic :\/ // why sad
// xd now do the commands folder  alr all of the cmds right?  yes but they are outdated this was a old old backkup of zara  
// make sure to fork this when we are done just in case repl ban again okay okay // //done its getting the folder :yeaS:
const memberData = require('../../database/guildData/memberupdates')
const { MessageEmbed } = require('discord.js')
const emoji = require("../../emoji.json") 

module.exports = async(member) => {
    const data = await memberData.findOne({
        GuildID: member.guild.id
    })

    if (!data) return;

    const embed = new MessageEmbed()
    .setTitle('**Member Banned**')
    .setDescription(`${emoji.dot} User: ${member.user.tag} (${member.user})\n${emoji.dot} User ID: ${member.id}\n${emoji.dot} Account Created On: ${member.user.createdAt}`)
    .setColor("5865f2")
    .setTimestamp()

    member.guild.channels.cache.get(data.ChannelID).send({ embeds: [embed] })
}