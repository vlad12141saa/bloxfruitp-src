const channelData = require('../../database/guildData/channelupdates')
const { MessageEmbed } = require('discord.js')
const emoji = require("../../emoji.json") 
module.exports = async(oldChannel, newChannel) => {
    const data = await channelData.findOne({
        GuildID: newChannel.guild.id,
    })

    if (!data) return;

    if (oldChannel.name !== newChannel.name) {
        const nameEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Channel Updated**`)
        .addField(`${emoji.dot} **Channel Name Changed**`, `${oldChannel.name} -> ${newChannel.name}`)
        .setColor("5865f2")
        .setTimestamp()

        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [nameEmbed] })

    } else if (oldChannel.topic !== newChannel.topic) {
        const topicEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Channel updated!**`)
        .addField(`${emoji.dot} **Channel topic changed**`, `${oldChannel.topic} -> ${newChannel.topic}`)
        .setColor("5865f2")
        .setTimestamp()

        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [topicEmbed] })

    } else if (oldChannel.position !== newChannel.position) {
        const positionEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Channel Updated!**`)
        .addField(`${emoji.dot} **Channel position changed.**`, `${oldChannel.position} -> ${newChannel.position}`)
        .setColor("5865f2")
        .setTimestamp()

        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [positionEmbed] })

    } else if (oldChannel.type !== newChannel.type) {
        const typeEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Channel Updated!**`)
        .addField(`${emoji.dot} **Channel type changed.**`, `${oldChannel.type} -> ${newChannel.type}`)
        .setColor("5865f2")
        .setTimestamp()

        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [typeEmbed] })

    } else if (oldChannel.nsfw !== newChannel.nsfw) {
        const nsfwEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Channel Updated!**`)
        .addField(`${emoji.dot} **Nsfw Channel changed.**`, `${oldChannel.nsfw} -> ${newChannel.nsfw}`)
        .setColor("5865f2")
        .setTimestamp()

        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [nsfwEmbed] })

    } else if (oldChannel.bitrate !== newChannel.bitrate) {
        const bitrateEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} Channel Updated`)
        .addField('5865f2')
        .setTimestamp()

        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [bitrateEmbed] })

    } else if (oldChannel.userLimit !== newChannel.userLimit) {
        const userLimitEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Channel Updated!**`)
        .addField(`${emoji.dot} **Channel userlimit changed.**`, `${oldChannel.nsfw} -> ${newChannel.nsfw}`)
        .setColor("5865f2")
        .setTimestamp()

        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [userLimitEmbed] })

    } else if  (oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser) {
        const rateLimitPerUserEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Channel Updated!**`)
        .addField(`${emoji.dot} **Channel cooldown updated.**`, `${oldChannel.rateLimitPerUser} -> ${newChannel.rateLimitPerUser}`)
        .setColor("5865f2")
        .setTimestamp()
        newChannel.guild.channels.cache.get(data.ChannelID).send({ embeds: [rateLimitPerUserEmbed] })

    } else {
        return;
    }
}