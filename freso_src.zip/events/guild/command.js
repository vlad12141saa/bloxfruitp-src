const prefixModel = require("../../database/guildData/prefix");
const db = require("quick.db");
const { DEFAULT_PREFIX } = ("f!")
const emoji = require("../../emoji.json") 
const {  WebhookClient } = require("discord.js");
const { Client, Intents } = require("discord.js");
const discord = require("discord.js");
const Discord = require("discord.js");
 const Topgg = require("@top-gg/sdk")
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');
const api = new Topgg.Api('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjkxODM2MTE0NDUzNDYzODYxMyIsImJvdCI6dHJ1ZSwiaWF0IjoxNjQ1NzQ5NjczfQ._imsUSXfNNTHEYD5j3yhQOanaIXRRQa7CN7VIgzklfA') 

//https://discord.com/api/webhooks/914166473960873994/PWowJLue5gW0Ynrj2wALj4RlSWvEwUsgAVz0ILuLwTXNIvqG0Yw5PvQA3q6mcGFlJAAg
//https://discord.com/api/webhooks/938652388833755197/gBUPg0e9G9jB8KJOXyRnjD_FAgOBf17IYqqvuQQQUU5XVWJud1zsUdH5faN9MgRZHbf6
const hook = new WebhookClient({ url: `https://discord.com/api/webhooks/967620321073049721/VDAkJ_nieG77o-urtLwnNYuqkyg5h5bfYbKOYIcZRZ1pIuueznBEZaBAytTQLUYgPTJG` });
// https://discord.com/api/webhooks/912674861699203072/TDwCTLuhuW-NcyuHWtJhYLgIyIQ747-Zk31UneuFhzirI7x36g0wtPvNrJ8AQC2N0fKL
const { get } = require('../../data.js')
const { Collection } = require("discord.js")
module.exports = async ( message, cooldowns) => {
  let client = message.client;

let prefix = db.fetch(`Prefix${message.guild.id}`) 
 if(!prefix) prefix = ("$")

  const prefixMention = new RegExp(`^<@!?${client.user.id}> `);
    prefix = message.content.match(prefixMention)
    ? message.content.match(prefixMention)[0]
    : prefix;

  if (message.content.indexOf(prefix) !== 0) return;
  if (message.author.bot) return;
  if (!message.guild){

              const r = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL(`${emoji.link}`)
					.setLabel('Support')
					.setEmoji('913454217597964388')
					.setStyle('LINK'),
           new MessageButton()
	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite Me')
					.setEmoji('949581412309286972')
					.setStyle('LINK'))
return message.channel.send({ content: `Hey, commands do not work in dms!\nCheckout my server: https://discord.gg/glyphic`, components: [r]})
}
  if (!message.content.startsWith(prefix)) return;
  if (message.channel.name.includes(`mudae`)) return;
 if (message.channel.name.includes(`muda`)) return;
 
if (!message.member)
    message.member = message.guild.fetchMember(message);
const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setCustomId('invite')
        .setLabel('Invite me')
      .setEmoji(`<:join_blurple:946583111620247632>`)
        .setStyle('SECONDARY'),
      new MessageButton()
      .setCustomId('vote')
        .setLabel('Vote here')
      .setEmoji(`<:join_blurple:946583111620247632>`)
        .setStyle('SECONDARY'),
      new MessageButton()
       .setCustomId('Support')
        .setLabel('Support here')
        .setStyle('PRIMARY')
    .setEmoji(`<:BlurpleTwinkle:946583374905106473>`))
    let em = new Discord.MessageEmbed()
     .setDescription(`${emoji.error} ${client.user.username} doesn't work in normal commands, please use slash commands to use the bot properly.\n**Example**\n\`/help\``)
  .setAuthor(`${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
   .setColor("#5865f2")
             .setFooter(`${client.user.username}`,client.user.displayAvatarURL())
      .setTimestamp();
    
  const args = message.content
    .slice(prefix.length)
    .trim()
    .split(/ +/g);
  const cmd = args.shift().toLowerCase();

  if (cmd.length === 0) return;

  let command = client.commands.get(cmd) || client.commands.get(client.aliases.get(cmd))
let interaction = message;
 if(!command) return;
 
 if (command.voteReq) { 
   let owner = ['932731757462192179']

        if (!owner.includes(interaction.author.id)) {
   const e = await api.hasVoted(`${message.author.id}`)
   if(!e) { 
           const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setCustomId('vote')
        .setLabel('Vote here')
      .setEmoji(`<:join_blurple:946583111620247632>`)
        .setStyle('SECONDARY'),
      new MessageButton()
       .setCustomId('Support')
        .setLabel('Support here')
        .setStyle('PRIMARY')
    .setEmoji(`<:BlurpleTwinkle:946583374905106473>`))

     const vote = new MessageEmbed()
     
 .setDescription(`${emoji.error} You are required to vote for **Glyphic**\n> Click the button below to vote for me.`)   
           .setColor(`BLURPLE`)
           .setFooter(`Glyphic`)
  message.reply({ components: [row], embeds: [vote]})
      const e = new Discord.MessageEmbed()
    .setTitle("Vote Failed Command Used")
    .setDescription(`<:slash:888176234217996308> **Command-Ran**\nName: \`/${command.name}\`\nChannel: ${interaction.channel.name}\nExecuted by: \`${interaction.user.tag}\`\nGuild: ${interaction.guild.name} - ${interaction.guild.id}`)
    .setTimestamp()
     .setThumbnail(`${interaction.guild.iconURL({ dyanamic: true })}`)
    .setAuthor(message.author.tag, `${message.author.displayAvatarURL({ dynamic: true })}`)
    .setColor("#36393E")

   return hook.send({ embeds: [e] })
   
}
}

}

   //const { onCoolDown } = require("../utils/function");
//if (onCoolDown(message, command)) {
   //   let cool = new MessageEmbed()
     // .setDescription(`❌ Please wait ${onCoolDown(message, command)} more Second(s) before reusing the ${command.name} command.`)
    //  return message.channel.send({embeds : [cool]})
    // }


    
   
       let data = await get(message, message.guild)
  command.run(client, message, args, data);
 if(command) { 
    const embed = new Discord.MessageEmbed()
    .setTitle(`${emoji.success} Command Used`)
    .setDescription(`**Command-Ran**\nName: \`${command.name}\`\nChannel: ${message.channel.name}\nExecuted by: \`${message.author.tag}\`\nGuild: ${message.guild.name}`)
.addField(`Info`, `**Mention**: ${message.author}\n**ID**: ${message.author.id}\n**Tag**: ${message.author.tag}\n**Guild ID**: ${message.guild.id}`)
     .setThumbnail(`${message.guild.iconURL({ dyanamic: true })}`)
    .setAuthor(message.author.tag, `${message.author.displayAvatarURL({ dynamic: true })}`)
    .setColor("WHITE")
    .setTimestamp()
    
  const db = require("quick.db")
    db.add(`cmd${command.name}`, 1)
 hook.send({ embeds: [embed] })
 }
  }   


