const channelData = require('../../database/guildData/channelupdates')
const { MessageEmbed } = require('discord.js')
const emoji = require("../../emoji.json") 
module.exports = async(channel) => {
    const data = await channelData.findOne({
        GuildID: channel.guild.id,
    })

    if (!data) return;

    const embed = new MessageEmbed()
    .setTitle(`${emoji.error} **Channel Deleted**`)
    .setDescription(`${emoji.dot} Channel Name: ${channel.name}\n${emoji.dot} Channel ID: ${channel.id}\n${emoji.dot} Channel Type: ${channel.type}`)
    .setColor("BLURPLE")
    .setTimestamp()

    channel.guild.channels.cache.get(data.ChannelID).send({ embeds: [embed] })
}