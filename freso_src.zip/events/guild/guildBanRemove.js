const memberData = require('../../database/guildData/memberupdates')
const { MessageEmbed } = require('discord.js')

module.exports = async(member) => {
    const data = await memberData.findOne({
        GuildID: member.guild.id
    })

    if (!data) return;

    const embed = new MessageEmbed()
    .setTitle(`${emoji.success} **Member Unbanned**`)
    .setDescription(`${emoji.dot} User: ${member.user.tag} (${member})\n${emoji.dot} User ID: ${member.id}\n${emoji.dot} Account Created On: ${member.user.createdAt}`)
    .setColor("5865f2")
    .setTimestamp()

    member.guild.channels.cache.get(data.ChannelID).send({ embeds: [embed] })
}