const voiceData = require("../../database/guildData/voiceupdates")
const { MessageEmbed } = require("discord.js")
const emoji = require("../../emoji.json") 
module.exports = async(oldState, newState) => {
    const data = await voiceData.findOne({
        GuildID: newState.guild.id
    })

    if (!data) return;

    let oldUser = oldState.member
    let newUser = newState.member

    if (oldUser.voice.channelId !== newUser.voice.channelId && newUser.voice.channelId !==  null || undefined) {

        let joinEmbed = new MessageEmbed()
        .setTitle(`**Voice State Updated**`)
        .setDescription(`${emoji.dot} ${newUser} joined to the voice channel <#${newUser.voice.channelId}>`)
        .setColor("5865f2")
        .setTimestamp()

        newState.guild.channels.cache.get(data.ChannelID).send({ embeds: [joinEmbed] })

    } else if (oldUser.voice.channelId !== newUser.voice.channelId && newUser.voice.channelId ===  null || undefined) {

        let leaveEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Voice State Updated**`)
        .setDescription(`${emoji.dot} ${newUser} left the voice channel <#${oldUser.voice.channelId}>.`)
        .setColor("5865f2")
        .setTimestamp()

        newState.guild.channels.cache.get(data.ChannelID).send({ embeds: [leaveEmbed] })

    } else if (oldState.mute !== newState.mute) {

        let muteEmbed = new MessageEmbed()
        .setTitle(`${emoji.success} **Voice State Updated**`)
        .setDescription(`${newUser} was ${newState.mute ? "muted" : "unmuted"}`)
        .setColor("5865f2")
        .setTimestamp()

  
      newState.guild.channels.cache.get(data.ChannelID).send({ embeds: [muteEmbed] })

    } else if (oldState.deaf !== newState.deaf) {

        let deafEmbed = new MessageEmbed()
 .setTitle(`**Voice State Updated**`)
        .setDescription(`${emoji.dot} ${newUser} was ${newState.deaf ? "deafened" : "undeafened"}`)
        .setColor("5865f2")
        .setTimestamp()
        newState.guild.channels.cache.get(data.ChannelID).send({ embeds: [deafEmbed] })

    }
}