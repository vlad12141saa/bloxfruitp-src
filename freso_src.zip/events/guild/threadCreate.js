const { MessageEmbed } = require('discord.js');
const channelData = require("../../database/guildData/channelupdates")
const emoji = require("../../emoji.json") 
module.exports = async(thread) => {
    const data = await channelData.findOne({
        GuildID: thread.guild.id
    })

    if (!data) return;

    const embed = new MessageEmbed()
    .setTitle(`${emoji.success} **Thread Created**`)
    .setDescription(`
Name: ${thread.name}
ID: ${thread.id}
Created By: ${thread.guild.members.cache.get(thread.ownerId)}
Parent Channel: ${thread.parent.name}`)
    .setColor("5185f2")
    .setTimestamp()

    thread.guild.channels.cache.get(data.ChannelID).send({ embeds: [embed] })
}