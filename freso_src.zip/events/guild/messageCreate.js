const db = require("quick.db")

const ms = require('ms')

module.exports = async (message) => {
  const search = db.get(`mentions_${message.guild.id}`)
  if(!search) return;
const mentions = message.mention.members;
if(mentions.size < 5) return message.reply(`Please stop mass mentioning.`)
}