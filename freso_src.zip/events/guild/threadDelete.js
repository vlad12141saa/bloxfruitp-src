const { MessageEmbed } = require('discord.js');
const channelData = require("../../database/guildData/channelupdates")
const emoji = require("../../emoji.json") 
module.exports = async(thread) => {
    const data = await channelData.findOne({
        GuildID: thread.guild.id
    })

    if (!data) return;

    const embed = new MessageEmbed()
    .setTitle(`${emoji.delete} **Thread Deleted**`)
    .setDescription(`
Name: ${thread.name}
ID: ${thread.id}
Owner: <@!${thread.ownerId}>
Member Count: ${thread.memberCount}
Messages Sent: ${thread.messages.cache.size}
Parent Channel: ${thread.parent.name}`)
    .setColor("5186f2")
    .setTimestamp()

    thread.guild.channels.cache.get(data.ChannelID).send({ embeds: [embed] })
}