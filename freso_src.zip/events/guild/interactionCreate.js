const Discord = require("discord.js");
const { InteractionType,PermissionsBitField, WebhookClient, Collection } = require("discord.js");
const emoji = require("../../emoji.json") 
const { Color } = require("../../config.json");

 const Topgg = require("@top-gg/sdk")
const api = new Topgg.Api('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjkxODM2MTE0NDUzNDYzODYxMyIsImJvdCI6dHJ1ZSwiaWF0IjoxNjQ1NzQ5NjczfQ._imsUSXfNNTHEYD5j3yhQOanaIXRRQa7CN7VIgzklfA') 
//https://discord.com/api/webhooks/963237948256563200/BAR1AZ1aRNe1nn8h15Qo9sShUuSgGnEYyqaIVKC6QWUsxsGs4Us0kfBO17O3RvR-q50u
const {  MessageActionRow, MessageAttachment, MessageButton, MessageEmbed } = require('discord.js');
const customCommandModel = require("../../database/guildData/customComands");
//https://discord.com/api/webhooks/963237948256563200/BAR1AZ1aRNe1nn8h15Qo9sShUuSgGnEYyqaIVKC6QWUsxsGs4Us0kfBO17O3RvR-q50u
//https://discord.com/api/webhooks/963237948256563200/BAR1AZ1aRNe1nn8h15Qo9sShUuSgGnEYyqaIVKC6QWUsxsGs4Us0kfBO17O3RvR-q50u
const hook = new WebhookClient({ url: 'https://discord.com/api/webhooks/1127759747156815912/fHFUKIaXjYrm36h6I4cqINtVGMg3ct2Ilk6Gy08VxX7BxzjecDgp7_jzlpbvB89KtWZx'  });
module.exports = async(interaction, client, cooldowns) => {
  let int = interaction;
  // https://discord.com/api/webhooks/907822879188607087/3x8msVb-nB_xqDpkBUqp5u9Sv-aIF4NyLXPF6ZEahiYZy6Dlq58YHOVUcFbihB-rOkKI
// https://discord.com/api/webhooks/905924902178132009/M_WKzhRa7N_ed4jW1DZ1CpvTEvn6SESEmtwKwgVxCoGtlVKVl8VMedB-USJNBvIK5Qar
//https://discord.com/api/webhooks/963237948256563200/BAR1AZ1aRNe1nn8h15Qo9sShUuSgGnEYyqaIVKC6QWUsxsGs4Us0kfBO17O3RvR-q50u

//https://discord.com/api/webhooks/963253413045485600/TSYyPtyjp5ZPVxDOqy3iSTvWKGJNOe1SjkTJllo9eYmWQ_0UNE5FVx8A8KDC9dwyF0ab
       if(interaction.type === InteractionType.ApplicationCommand) {
         console.log(`s`)
        const command = client.slash.get(interaction.commandName);

        if (!command) return;
        let owner = ['1102905025421918251', '']

             
const cmddata = require(`../../database/guildData/cmd`)
    const disabled = await cmddata.findOne({ 
      GuildID: interaction.guild.id,
      Command: command.name,
    })
  if(disabled) {
    await interaction.deferReply()
    const dis = new Discord.EmbedBuilder()
    .setColor(Color)
    .setAuthor({ name: `${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({dynamic: true}) })
    .setDescription(`${emoji.error} This command has been **disabled** by ${disabled.Author || 'n/a'}\n**Date**:${disabled.Date}`)

    return interaction.followUp({ embeds: [dis] })
  
}

        const args = [];
    if (command.sm) { 
    await interaction.guild.members.fetch()
}
  if (command.voteReq) { 
   let owner = ['1102905025421918251', '']

        if (!owner.includes(interaction.user.id)) {
   const e = await api.hasVoted(`${interaction.user.id}`)
   if(!e) { 
           const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setCustomId('vote')
        .setLabel('Vote here')
      .setEmoji(`<:join_blurple:946583111620247632>`)
        .setStyle('SECONDARY'),
      new MessageButton()
       .setCustomId('Support')
        .setLabel('Support here')
        .setStyle('PRIMARY')
    .setEmoji(`<:BlurpleTwinkle:946583374905106473>`))

     const vote = new MessageEmbed()
     
.setAuthor(`${interaction.user.tag}`,interaction.user.displayAvatarURL({ dynamic: true, }))
 .setDescription(`${emoji.error} Only voters can access this command.`)   
           .setColor(`#2f3136`)
           .setFooter(`Glyphic`)
       if(!interaction.user.username.includes(`Conflict`)) { 
  interaction.reply({ components: [row], embeds: [vote]})
      const e = new Discord.MessageEmbed()
    .setTitle("Vote Failed Command Used")
    .setDescription(`<:slash:888176234217996308> **Command-Ran**\nName: \`/${command.name}\`\nChannel: ${interaction.channel.name}\nExecuted by: \`${interaction.user.tag} ${interaction.user.id}\`\nGuild: ${interaction.guild.name} ${interaction.guild.id}`)
    .setTimestamp()
     .setThumbnail(`${interaction.guild.iconURL({ dyanamic: true })}`)
    .setAuthor(interaction.user.tag, `${interaction.member.user.displayAvatarURL({ dynamic: true })}`)
    .setColor("#2f3136")

   return hook.send({ embeds: [e] })
   }
}
}
}

        
let message = interaction;
        for (let option of interaction.options.data) {
            if (option.type === 'SUB_COMMAND') {
                if (option.name) args.push(option.name);
                option.options?.forEach(x =>  {
                    if (x.value) args.push(x.value);
                });
            } else if (option.value) args.push(option.value);
        }
  if (!cooldowns.has(command.name)) {
    cooldowns.set(command.name, new Collection());
  }

  const now = Date.now();
  const timestamps = cooldowns.get(command.name);
  let cooldownAmount = (command.cooldown || 3.0) * 1000;
if(command.name.includes('antinuke')) cooldownAmount = 10 * 1000;
  if (timestamps.has(message.user.id)) {
    const expirationTime = timestamps.get(interaction.user.id) + cooldownAmount;

    if (now < expirationTime) {
      const timeLeft = (expirationTime - now) / 1000;
      return message.reply(
        `**${interaction.user.tag}** Cool down (**${timeLeft.toFixed(
          1
        )} seconds** left)`
      );
    }
  }

  timestamps.set(message.user.id, now);
  setTimeout(() => timestamps.delete(message.user.id), cooldownAmount);
  if(!interaction.channel.permissionsFor(interaction.guild.members.me).has([PermissionsBitField.Flags.SendMessages])) return message.author.send({content: `${emoji.error}| I am missing the Permission to \`SendMessages\` in ${message.channel}`,});
  if(!interaction.channel.permissionsFor(interaction.guild.members.me).has([PermissionsBitField.Flags.UseExternalEmojis]))  return message.reply({content: `${emoji.error}| I am missing the Permission to \`UseExternalEmojis\` in ${message.channel}`});
  if(!interaction.channel.permissionsFor(interaction.guild.members.me).has([PermissionsBitField.Flags.EmbedLinks])) return message.reply({ content: `${emoji.error} I am missing the Permission to \`EmbedLinks\` in ${message.channel}` });
  
  
    //   let data = await get(interaction, interaction.guild) 
  
            command.run(client, interaction, args)

            if(command) {  
              const e = new Discord.EmbedBuilder()
  
              .setDescription(`**Command-Ran**\nName: \`/${command.name}\`\nChannel: ${interaction.channel.name}\nExecuted by: \`${interaction.user.tag} ${interaction.user.id}\`\nGuild: ${interaction.guild.name} ${interaction.guild.id}`)
              .setTimestamp()
              
              .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.member.user.displayAvatarURL({ dynamic: true }) || null}`})
              .setColor("#2f3136")
              if(interaction.guild.iconURL({ dyanamic: true })) {
            
                e.setThumbnail(`${interaction.guild.iconURL({ dyanamic: true }) || null}`)
               }
             return hook.send({ embeds: [e] })
            }
    

    }
}
        
