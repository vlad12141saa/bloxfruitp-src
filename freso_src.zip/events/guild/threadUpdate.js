const { MessageEmbed } = require('discord.js')
const channelData = require('../../database/guildData/channelupdates')
const emoji = require("../../emoji.json") 
module.exports = async(oldThreadMembers, newThreadMembers) => {
    const data = await channelData.findOne({
        GuildID: newThreadMembers.guild.id,
    })
    if (!data) return;

    if (oldThreadMembers.size < newThreadMembers.size) {
        const memberJoinEmbed = new MessageEmbed()
        .setTitle(`${oldThreadMembers.thread.name}`)
        .addField(`${emoji.dot} Thread members updated!`,`${oldThreadMembers.size} => ${newThreadMembers.size}`)
        .setColor("5865f2")
        .setTimestamp()

        newThread.guild.channels.cache.get(data.ChannelID).send({embeds: [memberJoinEmbed]})

    } else if (oldThreadMembers.size > newThreadMembers.size) {
        let memberLeftEmbed = new MessageEmbed()
        .setTitle(`${oldThreadMembers.thread.name}`)
        .addField(`${emoji.dot} Thread members updated!`,`${oldThreadMembers.size} => ${newThreadMembers.size}`)
        .setColor("5865f2")
        .setTimestamp()
        newThread.guild.channels.cache.get(data.ChannelID).send({embeds: [memberLeftEmbed]})
    }

}