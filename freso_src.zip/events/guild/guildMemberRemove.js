const memberData = require("../../database/guildData/memberupdates")
const { MessageEmbed } = require("discord.js")
const emoji = require("../../emoji.json") 
module.exports = async (member) => {
    const data = await memberData.findOne({
        GuildID: member.guild.id,
    })

    if (!data) return;

    const embed = new MessageEmbed()
    .setTitle(`${emoji.error} **Member Left**'`)
    .setDescription(`${emoji.dot} User: ${member.user.tag} (${member})\n${emoji.dot} User ID: ${member.id}\n${emoji.dot} Account creation date: ${member.user.createdAt}\n${emoji.dot} Server member Count: ${member.guild.memberCount}`)
    .setColor("5865f2")
    .setTimestamp()
    .setThumbnail(`${member.user.avatarURL}`)

    member.guild.channels.cache.get(data.ChannelID).send({ embeds: [embed]})
}