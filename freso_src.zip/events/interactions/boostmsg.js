const JoinMsg = require('../../database/guildData/boostmsg')
const emoji = require("../../emoji.json") 
module.exports = async(interaction, client)=>{
    if (!interaction.isSelectMenu()) return;

    let msg = await interaction.channel.messages.fetch(interaction.message.id)

    if (interaction.values[0] === "boost_message") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const data = await JoinMsg.findOne({
            GuildID: interaction.guild.id
        })

        if (!data) {
            await msg.edit(`${emoji.dot} Please send the **boost message** to be setup as the boost message.`)
            
            const filter = (m) => m.author.id === interaction.member.id

            const collector = await interaction.channel.createMessageCollector({ filter, time: 60000 })

            collector.on("collect", async(collected) => {

                let joinMsg = collected.content

            let newData = new JoinMsg({
                JoinMsg: joinMsg,
                GuildID: interaction.guild.id
            })

            newData.save()

            await collector.stop()
            return msg.edit(`**Success**\n${emoji.dot} Boost message has been set to:\n${joinMsg}`)
        })

       
        } else if (data) {
            await JoinMsg.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msg.edit(`${emoji.error} Boost Message has been removed!`)
        }
    }
}