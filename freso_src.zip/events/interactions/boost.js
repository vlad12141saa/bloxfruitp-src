const { IntegrationApplication } = require("discord.js");
const welcomeData = require("../../database/guildData/boost")
const JoinMsg = require('../../database/guildData/boostmsg')
const emoji = require("../../emoji.json") 
module.exports = async(interaction, client) => {
    if (!interaction.isSelectMenu()) return;

    let msg = await interaction.channel.messages.fetch(interaction.message.id)

    if (interaction.values[0] === "boost_channel") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission.`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const data = await welcomeData.findOne({
            GuildID: interaction.guild.id
        })

        if (!data) {
            msg.edit(`${emoji.boost} To complete the boost logging, please send the **Channel ID**.`)

            const filter = (m) => m.author.id === interaction.member.id

            let channelID;

            const collector = await interaction.channel.createMessageCollector({ filter, time: 60000 })

            collector.on('collect', async(collected, returnValue) => {
                channelID = collected.content

                let channel = interaction.guild.channels.cache.get(channelID)

                if (!channel) return msg.edit("Couldn't find that channel!")

                let newData = new welcomeData({
                    Boost: channelID,
                    GuildID: interaction.guild.id
                })
    
                newData.save()

                await collector.stop()
    
                return msg.edit(`${emoji.boost} Boost channel is successfuly set to ${interaction.guild.channels.cache.get(channelID)}`)
            })

        
        } else if (data) {
            await welcomeData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

             msg.edit(`${emoji.error} Boost channel has been removed!`)
        }
    }
            let msg1 = await interaction.channel.messages.fetch(interaction.message.id)

    if (interaction.values[0] === "boost_message") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const data1 = await JoinMsg.findOne({
            GuildID: interaction.guild.id
        })

        if (!data1) {
            await msg1.edit(`${emoji.boost} To complete the boost logging, please send the **Boost Message**.`)
            
            const filter1 = (m) => m.author.id === interaction.member.id

            const collector1 = await interaction.channel.createMessageCollector({ filter1, time: 60000 })

            collector1.on("collect", async(collected) => {

                let joinMsg = collected.content

            let newData = new JoinMsg({
                JoinMsg: joinMsg,
                GuildID: interaction.guild.id
            })

            newData.save()

            await collector1.stop()
            return msg1.edit(`**Success**\n${emoji.dot} Boost message has been set to:\n${joinMsg}`)
        })

       
        } else if (data1) {
            await JoinMsg.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msg1.edit(`${emoji.error} Boost message has been removed!`)
        }
    }
         let msg2 = await interaction.channel.messages.fetch(interaction.message.id)

    if (interaction.values[0] === "variables") {
      if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission.`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()

        return msg2.edit((`\`\`\`
        {user_mention} - Mentions the User who boosted the server.
        {user_name} - The Username of the User who boosted the server.
        {server} - The Name of the Server.
        {user_tag} - The user's tag who boosted the server.
        {server_boosts} The new amount of boosts the server has.
        {server_count} - The member count of the server.
        \`\`\`
        `))
    }
    }
        
    
