
         const { IntegrationApplication } = require("discord.js");
const messageData = require("../../database/guildData/messagelogs")
const serverData = require("../../database/guildData/serverupdates")
const memberData = require("../../database/guildData/memberupdates")
const db = require("quick.db")

const voiceStateData = require("../../database/guildData/voiceupdates")
const roleData = require("../../database/guildData/roleupdates")
const emoji = require("../../emoji.json") 
module.exports = async(interaction, client) => {
    if (!interaction.isSelectMenu()) return;
let member = interaction;
  return;
    }
    }
    
    
