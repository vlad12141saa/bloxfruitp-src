const { IntegrationApplication } = require("discord.js");
const serverData = require("../../database/guildData/serverupdates")
const emoji = require("../../emoji.json") 
module.exports = async(interaction, client) => {
    if (!interaction.isSelectMenu()) return;
    let msg = await interaction.channel.messages.fetch(interaction.message.id)
    if (interaction.values[0] === "server_updates") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const data = await serverData.findOne({
            GuildID: interaction.guild.id
        })

        if (!data) {
            await msg.edit("Please send the **Channel ID** to complete the setup for Server Update Logs.")

            const filter = (m) => m.author.id === interaction.member.id

            let channelID;

            const collector = await interaction.channel.createMessageCollector({ filter, time: 60000 })

            collector.on('collect', async(collected, returnValue) => {
                channelID = collected.content

                let channel = interaction.guild.channels.cache.get(channelID)

                if (!channel) return msg.edit("Couldn't find that channel!")

                let newData = new serverData({
                    ChannelID: channelID,
                    GuildID: interaction.guild.id
                })
    
                newData.save()

                await collector.stop()
    
                return msg.edit(`Server updates will be logged in ${interaction.guild.channels.cache.get(channelID)}`)
            })

            collector.on('end', async(collected, returnValue) => {
                console.log("Collector Stopped!")
            })

        } else if (data) {
            await serverData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msg.edit(`${emoji.error} Server Updates Logging has been stopped!`)
        }
    }
}