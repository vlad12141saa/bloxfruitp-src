const autoroleData = require("../../database/guildData/autorole")
const emoji = require("../../emoji.json") 
module.exports = async(interaction, client) => {
    if (!interaction.isSelectMenu()) return;
    let msg = await interaction.channel.messages.fetch(interaction.message.id)
    if (interaction.values[0] === "autorole") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission.`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()

        const data = await autoroleData.findOne({
            GuildID: interaction.guild.id
        })

        if (!data) {

            msg.edit({embeds: [
        {
  color: "#5865f2",
  author: {
	name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.dot} Please send the **Role ID** to complete the setup process.`,
          timestamp: new Date(),
        },
      ],
            })
            const filter = (m) => m.author.id == interaction.message.author.id

            var RoleMsg = await interaction.channel.awaitMessages({ time: 60000, max: 1, errors: ['time'] })
            
            let role = RoleMsg.first().content

                let newData = new autoroleData({
                    Role: role,
                    GuildID: interaction.guild.id
                })
    
                newData.save();
            return msg.edit({embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.success} Auto role has been successfully set to ${interaction.guild.roles.cache.get(role)}.`,
          timestamp: new Date(),
        },
      ],
            })

        } else if (data) {
            
            await autoroleData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

           return msg.edit({embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${message.user.tag}`,
		icon_url: `${message.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.success} Autorole has been successfuly disabled.`,
          timestamp: new Date(),
        },
      ],
            })
        }
    }
}