const { MessageEmbed } = require("discord.js")

module.exports = async(interaction, client) => {
    if (!interaction.isSelectMenu()) return;

    let msg = await interaction.channel.messages.fetch(interaction.message.id)

    if (interaction.values[0] === "variables") {
      if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return;
        await interaction.deferUpdate()

        return msg.edit((`\`\`\`
        {user_mention} - Mentions the User who boosted the server.
        {user_name} - The Username of the User who boosted the server.
        {server} - The Name of the Server.
        {user_tag} - The user's tag who boosted the server.
        {server_boosts} The new amount of boosts the server has.
        {server_count} - The member count of the server.
        \`\`\`
        `))
    }
}