const antilinkData = require("../../database/guildData/antilink")
const emoji = require("../../emoji.json") 
module.exports = async(interaction, client) => {
    if (!interaction.isSelectMenu()) return;
    let msg = await interaction.channel.messages.fetch(interaction.message.id)
    if (interaction.values[0] === "antilink") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()

        const data = await antilinkData.findOne({
            GuildID: interaction.guild.id
        })

        if (!data) {
            let newData = new antilinkData({
                GuildID: interaction.guild.id
            })

            newData.save();

            return msg.edit({embeds: [
        {
  color: "#5865f2",
  author: {
	name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.success} Anti link System has been enabled!`,
          timestamp: new Date(),
        },
      ],
            })
        } else if (data) {
            
            await antilinkData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msg.edit({embeds: [
        {
  color: "#5865f2",
  author: {
	name: `${interaction.member.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

       description: `${emoji.success} Anti link System has been disabled!`,
          timestamp: new Date(),
        },
      ],
            })
        }
    }
}