const { IntegrationApplication } = require("discord.js");
const channelData = require("../../database/guildData/channelupdates")
const messageData = require("../../database/guildData/messagelogs")
const serverData = require("../../database/guildData/serverupdates")

const roleData = require("../../database/guildData/roleupdates")
const emoji = require("../../emoji.json") 
module.exports = async(interaction, client) => {
    if (!interaction.isSelectMenu()) return;


    let msg = await interaction.channel.messages.fetch(interaction.message.id)

    if (interaction.values[0] === "channel_logs") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.dot} You're missing the \`MANAGE_GUILD\` permission.`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const data = await messageData.findOne({
            GuildID: interaction.guild.id
        })

        if (!data) {
            await msg.edit("Please send the **Channel ID** to complete the setup of Channel Updates log.")

            const filter = (m) => m.author.id === interaction.member.id

            let channelID;

            const collector = await interaction.channel.createMessageCollector({ filter, time: 60000 })

            collector.on('collect', async(collected, returnValue) => {
                channelID = collected.content

                let channel = interaction.guild.channels.cache.get(channelID) 

                if (!channel) return msg.edit("Couldn't find that channel!")

                let newData = new channelData({
                    ChannelID: channelID,
                    GuildID: interaction.guild.id
                })
    
                newData.save()

                await collector.stop()
    
                return msg.edit(`Channel updates will be logged in: ${interaction.guild.channels.cache.get(channelID)}`)
            })

            collector.on('end', async(collected, returnValue) => {
                console.log("Collector Stopped!")
            })

        } else if (data) {
            await channelData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msg.edit(`${emoji.error} Channel Updates Logging has been stopped!`)
        }
    }
     let msg1  = await interaction.channel.messages.fetch(interaction.message.id)
    
    if (interaction.values[0] === "message_logs") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.dot} You're missing the \`MANAGE_GUILD\` permission`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const data1 = await messageData.findOne({
            GuildID: interaction.guild.id
        })

        if (!data1) {
            await msg.edit("Please send the **Channel ID** to complete the setup for Message Update Logs.")

            const filter1 = (m) => m.author.id === interaction.member.id

            let channelID;

            const collector1 = await interaction.channel.createMessageCollector({ filter1, time: 60000 })

            collector1.on('collect', async(collected, returnValue) => {
                channelID = collected.content

                let channel = interaction.guild.channels.cache.get(channelID)

                if (!channel) return msg.edit("Couldn't find that channel!")

                let newData = new messageData({
                    ChannelID: channelID,
                    GuildID: interaction.guild.id
                })
    
                newData.save()

                await collector1.stop()
    
                return msg1.edit(`Message updates will be logged in: ${interaction.guild.channels.cache.get(channelID)}`)
            })

            collector1.on('end', async(collected, returnValue) => {
                console.log("Collector Stopped!")
            })

        } else if (data1) {
            await messageData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msg1.edit(`Message Updates Logging has been stopped!`)
        }
          let msg2 = await interaction.channel.messages.fetch(interaction.message.id)

    if (interaction.values[0] === "role_updates") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.error} You're missing the \`MANAGE_GUILD\` permission`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const data2 = await roleData.findOne({
            GuildID: interaction.guild.id
        })

        if (!data2) {
            await msg2.edit("Please send the **Channel ID** to complete the setup for Server Update Logs.")

            const filter2 = (m) => m.author.id === interaction.member.id

            let channelID;

            const collector = await interaction.channel.createMessageCollector({ filter2, time: 60000 })

            collector.on('collect', async(collected, returnValue) => {
                channelID = collected.content

                let channel = interaction.guild.channels.cache.get(channelID)

                if (!channel) return msg2.edit("Couldn't find that channel!")

                let newData = new roleData({
                    ChannelID: channelID,
                    GuildID: interaction.guild.id
                })
    
                newData.save()

                await collector2.stop()
    
                return msg2.edit(`Role updates will be logged in: ${interaction.guild.channels.cache.get(channelID)}`)
            })

            collector2.on('end', async(collected, returnValue) => {
                console.log("Collector Stopped!")
            })

        } else if (data2) {
            await roleData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msg2.edit(`${emoji.dot} Role Updates Logging has been stopped!`)
        }
         let msgs = await interaction.channel.messages.fetch(interaction.message.id)
    if (interaction.values[0] === "server_updates") {
if (!interaction.member.permissions.has("MANAGE_GUILD"))
    return interaction.reply({ ephemeral: true ,
      embeds: [
        {
  color: "#5865f2",
  author: {
		name: `${interaction.user.tag}`,
		icon_url: `${interaction.user.displayAvatarURL({ dynamic: true })}`,

	},
         // footer: { icon_url: client.user.displayAvatarURL() },
          	footer: {
		text: `${client.user.username}`,
		icon_url: `${client.user.displayAvatarURL()}`,
	},

          description: `${emoji.dot} You're missing the \`MANAGE_GUILD\` permission`,
          timestamp: new Date(),
        },
      ],
          })
        await interaction.deferUpdate()
        
        const datas = await serverData.findOne({
            GuildID: interaction.guild.id
        })

        if (!datas) {
            await msgs.edit("Please send the **Channel ID** to complete the setup for Server Update Logs.")

            const filters = (m) => m.author.id === interaction.member.id

            let channelID;

            const collectors = await interaction.channel.createMessageCollector({ filters, time: 60000 })

            collectors.on('collect', async(collected, returnValue) => {
                channelID = collected.content

                let channels = interaction.guild.channels.cache.get(channelID)

                if (!channels) return msgs.edit("Couldn't find that channel!")

                let newData = new serverData({
                    ChannelID: channelID,
                    GuildID: interaction.guild.id
                })
    
                newData.save()

                await collectors.stop()
    
                return msgs.edit(`Server updates will be logged in: ${interaction.guild.channels.cache.get(channelID)}`)
            })

            collectors.on('end', async(collected, returnValue) => {
                console.log("Collector Stopped!")
            })

        } else if (datas) {
            await serverData.findOneAndRemove({
                GuildID: interaction.guild.id
            })

            return msgs.edit(`${emoji.dot} Server Updates Logging has been stopped!`)
        }
    }
    }
    }
}