const Discord = require("discord.js")

const { MessageActionRow, MessageEmbed, MessageSelectMenu, MessageButton } = require('discord.js');
const emoji = require("../../emoji.json") 
module.exports = {
  async execute(giveaway, reactor, messageReaction) {
     let client = messageReaction.message.client
         const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
	.setURL(`${emoji.link}`)
					.setLabel('Support')
					.setStyle('LINK'),
           new MessageButton()
	.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
					.setLabel('Invite Me')
					.setStyle('LINK'),     new MessageButton()
	.setURL(`https://top.gg/bot/${client.user.id}/vote`)
					.setLabel('Extra Entries')
					.setStyle('LINK'))
               const row2 = new MessageActionRow()
			.addComponents(
        new MessageButton()
        .setCustomId(`dhbadhbshdbhd`)
					.setLabel(`Giveaway from: ${reactor.guild.name} `)
					.setStyle('LINK')
          .setDisabled(true))
    let approved =  new Discord.MessageEmbed()
    .setTimestamp()
    .setTitle(`${emoji.success} Entry Approved!`)
    .setDescription(
      `${emoji.dot} Your entry to [this giveaway](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId}) has been approved!`)

.setColor(`RANDOM`)
    .setFooter(`By entering the giveaway you agreed to being DMed`)
    .setTimestamp()
   let denied =  new Discord.MessageEmbed()
    .setTimestamp()
    .setDescription(
      `${emoji.error} Your entry to [this giveaway](https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${giveaway.messageId}) has been denied, please review the requirements to the giveaway properly.`
    )

.setColor(`RANDOM`)
    .setFooter(`By entering the giveaway you agreed to being DMed`)
   
    if (reactor.user.bot) return;

      if (giveaway.extraData.role !== "null" && !reactor.roles.cache.get(giveaway.extraData.role)){ 
        messageReaction.users.remove(reactor.user);
        return reactor.send({ content:`${emoji.link} join for help`,
          embeds: [denied],components: [row]
        }).catch(e => {})
      }

      return reactor.send({ content: `**${client.user.username}'s Support server**: ${emoji.link}`,
        embeds: [approved], components: [row]
      }).catch(e => {})
    }
    
  }