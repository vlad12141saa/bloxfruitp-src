
const { mongoPass } = require("../../config.json");
const mongoose = require("mongoose") 
module.exports = async (client) => {

console.log(`${client.user.username} is online and working.`)

	 
};
