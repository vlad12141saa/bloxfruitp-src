const Discord = require("discord.js");
  module.exports = {
 
    
    giveaway: ":tada: **GIVEAWAY** :tada:",
    giveawayEnded: ":tada: **GIVEAWAY ENDED** :tada:",
    inviteToParticipate: "React with <:CM_giveaway:1013121968058417283> to participate!",
    dropMessage: "React with :tada:!",
    drawing: 'Ends: {timestamp}',
   
  embedFooter: '{this.winnerCount} winner(s)',
    noWinner: "Giveaway cancelled, no valid participations.",
    hostedBy: "Hosted by: {this.hostedBy}",
    winners: "winner(s)",
    endedAt: "Ended at",
 winMessage: { content: '{winners} Congratulations! You won \`{this.prize}\`! ??'
  
}
  }